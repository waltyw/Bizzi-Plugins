(function(){
'use strict';
document.addEventListener('DOMContentLoaded',function(){
document.querySelectorAll('.bizzi-read-more-link').forEach(function(link){
link.addEventListener('click',function(e){
e.preventDefault();
var card=this.closest('.bizzi-review-content');
if(card){card.style.maxHeight='none';var more=card.querySelector('.bizzi-read-more');if(more)more.style.display='none';}
});});
document.querySelectorAll('.bizzi-badge-close').forEach(function(btn){
btn.addEventListener('click',function(){this.closest('.bizzi-badge-wrap').classList.add('bizzi-badge-hidden');});});
var observer=new IntersectionObserver(function(entries){entries.forEach(function(entry){if(entry.isIntersecting){entry.target.style.animationPlayState='running';observer.unobserve(entry.target);}});},{threshold:0.1});
document.querySelectorAll('.bizzi-animate-in').forEach(function(el){el.style.animationPlayState='paused';observer.observe(el);});
});
})();
