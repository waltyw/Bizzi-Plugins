<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

class Bizzi_Reviews_Shortcodes {

        private $db;
        private $widgets;
        private $schema;

        public function __construct() {
                $this->db      = new Bizzi_Reviews_Database();
                $this->widgets = new Bizzi_Reviews_Widgets();
        }

        public function set_schema( $schema ) {
                $this->schema = $schema;
        }

        public function init() {
                add_shortcode( 'bizzi_reviews', array( $this, 'render_reviews' ) );
                add_shortcode( 'bizzi_rating_badge', array( $this, 'render_badge' ) );
                add_shortcode( 'bizzi_combined_rating', array( $this, 'render_combined' ) );
                add_shortcode( 'bizzi_single_review', array( $this, 'render_single' ) );
        }

        public function render_reviews( $atts ) {
                $style = Bizzi_Reviews_Widgets::style_defaults();
                $atts = shortcode_atts( array(
                        'layout'           => 'carousel',
                        'source'           => '',
                        'limit'            => 20,
                        'min_rating'       => 0,
                        'rating'           => 0,
                        'columns'          => 3,
                        'masonry'          => 'false',
                        'columns_tablet'   => 2,
                        'columns_mobile'   => 1,
                        'show_name'        => 'true',
                        'show_avatar'      => 'true',
                        'show_date'        => 'true',
                        'show_source'      => 'true',
                        'show_rating'      => 'true',
                        'show_text'        => 'true',
                        'max_text_length'  => 200,
                        'date_range'       => '',
                        'keyword'          => '',
                        'primary_color'    => $style['primary_color'],
                        'text_color'       => $style['text_color'],
                        'background_color' => $style['background_color'],
                        'card_border_radius' => $style['card_border_radius'],
                        'card_shadow'      => $style['card_shadow'],
                        'card_padding'     => '24',
                        'star_color'       => $style['star_color'],
                        'font_family'      => $style['font_family'],
                        'font_size'        => '14',
                        'gap'              => '20',
                        'autoplay'         => 'true',
                        'speed'            => 5,
                ), $atts, 'bizzi_reviews' );

                $layout = sanitize_key( $atts['layout'] );

                if ( ! in_array( $layout, Bizzi_Reviews_Widgets::layouts(), true ) ) {
                        $layout = 'carousel';
                }
                if ( 'badge' === $layout ) {
                        return $this->render_badge( is_array( $atts ) ? $atts : array() );
                }

                $min_rating = absint( $atts['rating'] ) > 0 ? absint( $atts['rating'] ) : absint( $atts['min_rating'] );

                $reviews = $this->db->get_reviews( array(
                        'source'     => sanitize_text_field( $atts['source'] ),
                        'status'     => 'approved',
                        'min_rating' => $min_rating,
                        'limit'      => max( 1, min( absint( $atts['limit'] ), 100 ) ),
                        'search'     => sanitize_text_field( $atts['keyword'] ),
                        'date_range' => sanitize_text_field( $atts['date_range'] ),
                ) );

                if ( empty( $reviews ) ) {
                        return '<p class="bizzi-no-reviews">' . esc_html__( 'No reviews found.', 'bizzi-reviews' ) . '</p>';
                }

                if ( $this->schema ) {
                        $this->schema->mark_for_output();
                }

                return $this->widgets->render( $layout, $reviews, $atts );
        }

        public function render_badge( $atts ) {
                if ( ! in_array( 'badge', Bizzi_Reviews_Widgets::layouts(), true ) ) {
                        return '';
                }
                $style = Bizzi_Reviews_Widgets::style_defaults();
                $atts = shortcode_atts( array(
                        'position'         => 'bottom-right',
                        'primary_color'    => $style['primary_color'],
                        'text_color'       => $style['badge_text_color'],
                        'background_color' => $style['badge_background_color'],
                        'star_color'       => $style['star_color'],
                        'font_family'      => $style['font_family'],
                        'dismissible'      => 'true',
                        'link'             => '',
                        'source'           => '',
                ), $atts, 'bizzi_rating_badge' );

                $total  = $this->db->count_reviews( array( 'status' => 'approved' ) );
                $avg    = $this->db->get_average_rating();

                if ( $total === 0 ) {
                        return '';
                }

                if ( $this->schema ) {
                        $this->schema->mark_for_output();
                }

                return $this->widgets->render( 'badge', null, array_merge( $atts, array(
                        'total'      => $total,
                        'avg_rating' => round( $avg, 1 ),
                ) ) );
        }

        public function render_combined( $atts ) {
                $style = Bizzi_Reviews_Widgets::style_defaults();
                $atts = shortcode_atts( array(
                        'primary_color'      => $style['primary_color'],
                        'text_color'         => $style['text_color'],
                        'background_color'   => $style['background_color'],
                        'star_color'         => $style['star_color'],
                        'card_border_radius' => $style['card_border_radius'],
                        'font_family'        => $style['font_family'],
                ), $atts, 'bizzi_combined_rating' );
                foreach ( array( 'primary_color', 'text_color', 'background_color', 'star_color' ) as $key ) {
                        $atts[ $key ] = Bizzi_Reviews_Widgets::sanitize_color( $atts[ $key ], $style[ $key ] );
                }
                $atts['font_family'] = Bizzi_Reviews_Widgets::sanitize_font( $atts['font_family'] );

                $by_source = $this->db->get_reviews_by_source();
                $total     = $this->db->count_reviews( array( 'status' => 'approved' ) );
                $avg       = $this->db->get_average_rating();

                if ( $this->schema ) {
                        $this->schema->mark_for_output();
                }

                ob_start();
                ?>
                <div class="bizzi-combined-rating" style="background:<?php echo esc_attr( $atts['background_color'] ); ?>;color:<?php echo esc_attr( $atts['text_color'] ); ?>;font-family:<?php echo esc_attr( $atts['font_family'] ); ?>;padding:30px;border-radius:<?php echo absint( $atts['card_border_radius'] ); ?>px;text-align:center;">
                        <div style="font-size:48px;font-weight:700;color:<?php echo esc_attr( $atts['primary_color'] ); ?>;"><?php echo esc_html( round( $avg, 1 ) ); ?></div>
                        <div class="bizzi-stars" style="font-size:24px;color:<?php echo esc_attr( $atts['star_color'] ); ?>;margin:8px 0;">
                                <?php echo esc_html( str_repeat( '★', (int) round( $avg ) ) . str_repeat( '☆', 5 - (int) round( $avg ) ) ); ?>
                        </div>
                        <div style="font-size:14px;opacity:0.7;">
                                <?php
                                /* translators: %d: number of reviews */
                                printf( esc_html__( 'Based on %d reviews', 'bizzi-reviews' ), absint( $total ) );
                                ?>
                        </div>
                        <?php if ( ! empty( $by_source ) ) : ?>
                        <div style="display:flex;justify-content:center;gap:20px;margin-top:16px;flex-wrap:wrap;">
                                <?php foreach ( $by_source as $src ) : ?>
                                <div style="text-align:center;">
                                        <div style="font-weight:600;text-transform:capitalize;"><?php echo esc_html( $src->source ); ?></div>
                                        <div style="font-size:20px;font-weight:700;"><?php echo esc_html( round( (float) $src->avg_rating, 1 ) ); ?> <span style="color:<?php echo esc_attr( $atts['star_color'] ); ?>;">★</span></div>
                                        <div style="font-size:12px;opacity:0.6;"><?php echo absint( $src->count ); ?> <?php esc_html_e( 'reviews', 'bizzi-reviews' ); ?></div>
                                </div>
                                <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                </div>
                <?php
                return ob_get_clean();
        }

        public function render_single( $atts ) {
                $style = Bizzi_Reviews_Widgets::style_defaults();
                $atts = shortcode_atts( array(
                        'id'               => 0,
                        'primary_color'    => $style['primary_color'],
                        'text_color'       => $style['text_color'],
                        'background_color' => $style['background_color'],
                        'star_color'       => $style['star_color'],
                        'card_border_radius' => $style['card_border_radius'],
                        'card_shadow'      => $style['card_shadow'],
                        'font_family'      => $style['font_family'],
                        'show_name'        => 'true',
                        'show_avatar'      => 'true',
                        'show_date'        => 'true',
                        'show_source'      => 'true',
                        'show_rating'      => 'true',
                        'show_text'        => 'true',
                ), $atts, 'bizzi_single_review' );

                $id = absint( $atts['id'] );
                if ( $id > 0 ) {
                        $review = $this->db->get_review( $id );
                        // Only approved reviews may ever be shown publicly.
                        if ( ! $review || 'approved' !== $review->status ) {
                                return '';
                        }
                } else {
                        $reviews = $this->db->get_reviews( array( 'status' => 'approved', 'limit' => 1, 'orderby' => 'rating', 'order' => 'DESC' ) );
                        $review = ! empty( $reviews ) ? $reviews[0] : null;
                }

                if ( ! $review ) {
                        return '';
                }

                if ( $this->schema ) {
                        $this->schema->mark_for_output();
                }

                return $this->widgets->render( 'single', array( $review ), $atts );
        }
}
