<?php if ( ! defined( 'ABSPATH' ) ) exit;
$widget = new Bizzi_Reviews_Widgets();
$speed = isset( $atts['speed'] ) ? absint( $atts['speed'] ) * 1000 : 5000;
$autoplay = isset( $atts['autoplay'] ) && $atts['autoplay'] === 'false' ? 'false' : 'true';
$cols_desktop = max( 1, min( 6, absint( isset( $atts['columns'] ) ? $atts['columns'] : 3 ) ) );
$cols_tablet  = max( 1, min( 4, absint( isset( $atts['columns_tablet'] ) ? $atts['columns_tablet'] : 2 ) ) );
$cols_mobile  = max( 1, min( 3, absint( isset( $atts['columns_mobile'] ) ? $atts['columns_mobile'] : 1 ) ) );
$show_arrows  = ! isset( $atts['arrows'] ) || 'false' !== $atts['arrows'];
$show_dots    = ! isset( $atts['dots'] ) || 'false' !== $atts['dots'];
$arrow_style  = isset( $atts['arrow_style'] ) && in_array( $atts['arrow_style'], array( 'chevron', 'arrow', 'caret', 'double' ), true ) ? $atts['arrow_style'] : 'chevron';
$arrow_pos    = isset( $atts['arrow_position'] ) && in_array( $atts['arrow_position'], array( 'inside', 'outside', 'below', 'top' ), true ) ? $atts['arrow_position'] : 'inside';
$wrap_class   = 'bizzi-carousel-wrap' . ( $show_arrows ? ' bizzi-arrows-' . $arrow_pos : ' bizzi-no-arrows' ) . ( $show_dots ? '' : ' bizzi-no-dots' );
?>
<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $wrap_class ); ?>" data-speed="<?php echo esc_attr( $speed ); ?>" data-autoplay="<?php echo esc_attr( $autoplay ); ?>" data-cols-desktop="<?php echo esc_attr( $cols_desktop ); ?>" data-cols-tablet="<?php echo esc_attr( $cols_tablet ); ?>" data-cols-mobile="<?php echo esc_attr( $cols_mobile ); ?>" style="--bizzi-cols-desktop:<?php echo esc_attr( $cols_desktop ); ?>;--bizzi-cols-tablet:<?php echo esc_attr( $cols_tablet ); ?>;--bizzi-cols-mobile:<?php echo esc_attr( $cols_mobile ); ?>;--bizzi-primary:<?php echo esc_attr($atts['primary_color']); ?>;--bizzi-text:<?php echo esc_attr($atts['text_color']); ?>;--bizzi-bg:<?php echo esc_attr($atts['background_color']); ?>;--bizzi-star:<?php echo esc_attr($atts['star_color']); ?>;--bizzi-radius:<?php echo esc_attr($atts['card_border_radius']); ?>px;--bizzi-padding:<?php echo esc_attr($atts['card_padding']); ?>px;">
<div class="bizzi-carousel-viewport">
<div class="bizzi-carousel-track">
<?php foreach ( $reviews as $review ) : ?>
<div class="bizzi-carousel-slide">
<div class="bizzi-review-card<?php echo esc_attr( 'true' === $atts['card_shadow'] ? ' bizzi-shadow' : '' ); ?>">
<?php if ( $atts['show_rating'] === 'true' ) : ?>
<div class="bizzi-review-rating"><?php echo wp_kses( $widget->render_stars( $review->rating, $atts['star_color'] ), Bizzi_Reviews_Widgets::allowed_html() ); ?></div>
<?php endif; ?>
<?php if ( $atts['show_text'] === 'true' && ! empty( $review->content ) ) : ?>
<div class="bizzi-review-content"><?php echo wp_kses( $widget->truncate_text( $review->content, absint( $atts['max_text_length'] ) ), Bizzi_Reviews_Widgets::allowed_html() ); ?></div>
<?php endif; ?>
<div class="bizzi-review-author">
<?php if ( $atts['show_avatar'] === 'true' && ! empty( $review->author_image ) ) : ?>
<img class="bizzi-avatar" src="<?php echo esc_url( $review->author_image ); ?>" alt="<?php echo esc_attr( $review->author_name ); ?>" loading="lazy" width="40" height="40" />
<?php endif; ?>
<div class="bizzi-author-info">
<?php if ( $atts['show_name'] === 'true' ) : ?><span class="bizzi-author-name"><?php echo esc_html( $review->author_name ); ?></span><?php endif; ?>
<?php if ( $atts['show_date'] === 'true' ) : ?><span class="bizzi-review-date"><?php echo esc_html( $review->date_published ); ?></span><?php endif; ?>
<?php if ( $atts['show_source'] === 'true' ) : ?><span class="bizzi-review-source"><?php echo wp_kses( $widget->get_source_icon( $review->source ), Bizzi_Reviews_Widgets::allowed_html() ); ?> <?php echo esc_html( ucfirst( $review->source ) ); ?></span><?php endif; ?>
</div></div></div></div>
<?php endforeach; ?>
</div>
</div>
<?php if ( $show_arrows || $show_dots ) : ?>
<div class="bizzi-carousel-nav">
<?php if ( $show_arrows ) : ?><button type="button" class="bizzi-carousel-prev" aria-label="<?php esc_attr_e( 'Previous', 'bizzi-reviews' ); ?>"><?php echo wp_kses( Bizzi_Reviews_Widgets::arrow_icon( $arrow_style, 'prev' ), Bizzi_Reviews_Widgets::allowed_html() ); ?></button><?php endif; ?>
<?php if ( $show_dots ) : ?><div class="bizzi-carousel-dots"></div><?php endif; ?>
<?php if ( $show_arrows ) : ?><button type="button" class="bizzi-carousel-next" aria-label="<?php esc_attr_e( 'Next', 'bizzi-reviews' ); ?>"><?php echo wp_kses( Bizzi_Reviews_Widgets::arrow_icon( $arrow_style, 'next' ), Bizzi_Reviews_Widgets::allowed_html() ); ?></button><?php endif; ?>
</div>
<?php endif; ?>
</div>
