<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

abstract class Bizzi_Review_Source_Base {

        protected $slug = '';
        protected $name = '';

        abstract public function fetch_reviews();
        abstract public function is_configured();

        public function get_slug() {
                return $this->slug;
        }

        public function get_name() {
                return $this->name;
        }

        protected function make_request( $url, $args = array() ) {
                $defaults = array(
                        'timeout'   => 30,
                        'sslverify' => true,
                );
                $args = wp_parse_args( $args, $defaults );
                $response = wp_remote_get( $url, $args );

                if ( is_wp_error( $response ) ) {
                        throw new Exception( esc_html( $response->get_error_message() ) );
                }

                $code = wp_remote_retrieve_response_code( $response );
                if ( $code !== 200 ) {
                        throw new Exception( esc_html( sprintf( 'API returned status %d', absint( $code ) ) ) );
                }

                $body = wp_remote_retrieve_body( $response );
                $data = json_decode( $body, true );

                if ( json_last_error() !== JSON_ERROR_NONE ) {
                        throw new Exception( 'Invalid JSON response' );
                }

                return $data;
        }

        protected function get_encrypted_option( $key ) {
                $core = new Bizzi_Core();
                $encrypted = get_option( 'bizzi_reviews_' . $key, '' );
                return $core->decrypt_value( $encrypted );
        }

        protected function set_encrypted_option( $key, $value ) {
                $core = new Bizzi_Core();
                update_option( 'bizzi_reviews_' . $key, $core->encrypt_value( $value ) );
        }
}
