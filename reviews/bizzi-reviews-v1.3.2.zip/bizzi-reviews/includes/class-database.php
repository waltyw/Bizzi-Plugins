<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

// Table names are built from $wpdb->prefix in the constructor and never contain user input; all values use placeholders.
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

class Bizzi_Reviews_Database {

        private $reviews_table;
        private $sources_table;
        private $widgets_table;

        public function __construct() {
                global $wpdb;
                $this->reviews_table = $wpdb->prefix . 'bizzi_reviews';
                $this->sources_table = $wpdb->prefix . 'bizzi_review_sources';
                $this->widgets_table = $wpdb->prefix . 'bizzi_widgets';
        }

        public function create_tables() {
                global $wpdb;
                $charset = $wpdb->get_charset_collate();

                $sql_reviews = "CREATE TABLE {$this->reviews_table} (
                        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                        source varchar(50) NOT NULL DEFAULT 'manual',
                        source_id varchar(255) NOT NULL DEFAULT '',
                        author_name varchar(255) NOT NULL DEFAULT '',
                        author_image varchar(500) DEFAULT '',
                        rating tinyint(1) unsigned NOT NULL DEFAULT 5,
                        content longtext DEFAULT NULL,
                        date_published datetime DEFAULT NULL,
                        date_synced datetime DEFAULT CURRENT_TIMESTAMP,
                        status varchar(20) NOT NULL DEFAULT 'pending',
                        metadata longtext DEFAULT NULL,
                        PRIMARY KEY (id),
                        KEY source (source),
                        KEY status (status),
                        KEY rating (rating),
                        KEY source_id (source_id(191)),
                        KEY date_published (date_published)
                ) $charset;";

                $sql_sources = "CREATE TABLE {$this->sources_table} (
                        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                        source_type varchar(50) NOT NULL,
                        config longtext DEFAULT NULL,
                        is_active tinyint(1) NOT NULL DEFAULT 1,
                        last_sync datetime DEFAULT NULL,
                        next_sync datetime DEFAULT NULL,
                        sync_status varchar(20) DEFAULT 'idle',
                        error_message text DEFAULT NULL,
                        PRIMARY KEY (id),
                        KEY source_type (source_type)
                ) $charset;";

                $sql_widgets = "CREATE TABLE {$this->widgets_table} (
                        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                        name varchar(255) NOT NULL,
                        layout varchar(50) NOT NULL DEFAULT 'carousel',
                        config longtext DEFAULT NULL,
                        shortcode text DEFAULT NULL,
                        created_at datetime DEFAULT CURRENT_TIMESTAMP,
                        updated_at datetime DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (id)
                ) $charset;";

                require_once ABSPATH . 'wp-admin/includes/upgrade.php';
                dbDelta( $sql_reviews );
                dbDelta( $sql_sources );
                dbDelta( $sql_widgets );
        }

        public function get_reviews_table() {
                return $this->reviews_table;
        }

        public function get_sources_table() {
                return $this->sources_table;
        }

        public function get_widgets_table() {
                return $this->widgets_table;
        }

        public function insert_review( $data ) {
                global $wpdb;
                $defaults = array(
                        'source'         => 'manual',
                        'source_id'      => '',
                        'author_name'    => '',
                        'author_image'   => '',
                        'rating'         => 5,
                        'content'        => '',
                        'date_published' => current_time( 'mysql' ),
                        'date_synced'    => current_time( 'mysql' ),
                        'status'         => 'pending',
                        'metadata'       => '',
                );
                $data = wp_parse_args( $data, $defaults );
                $wpdb->insert( $this->reviews_table, $data, array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s' ) );
                return $wpdb->insert_id;
        }

        public function update_review( $id, $data ) {
                global $wpdb;
                return $wpdb->update( $this->reviews_table, $data, array( 'id' => absint( $id ) ) );
        }

        public function delete_review( $id ) {
                global $wpdb;
                return $wpdb->delete( $this->reviews_table, array( 'id' => absint( $id ) ), array( '%d' ) );
        }

        public function get_review( $id ) {
                global $wpdb;
                return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->reviews_table} WHERE id = %d", absint( $id ) ) );
        }

        public function get_reviews( $args = array() ) {
                global $wpdb;
                $defaults = array(
                        'source'     => '',
                        'status'     => 'approved',
                        'min_rating' => 0,
                        'limit'      => 20,
                        'offset'     => 0,
                        'orderby'    => 'date_published',
                        'order'      => 'DESC',
                        'search'     => '',
                        'date_range' => '',
                );
                $args = wp_parse_args( $args, $defaults );

                $where = array( '1=1' );
                $values = array();

                if ( ! empty( $args['source'] ) ) {
                        $sources = array_map( 'sanitize_text_field', explode( ',', $args['source'] ) );
                        $placeholders = implode( ', ', array_fill( 0, count( $sources ), '%s' ) );
                        $where[] = "source IN ($placeholders)";
                        $values  = array_merge( $values, $sources );
                }

                if ( ! empty( $args['status'] ) ) {
                        $where[] = 'status = %s';
                        $values[] = sanitize_text_field( $args['status'] );
                }

                if ( $args['min_rating'] > 0 ) {
                        $where[] = 'rating >= %d';
                        $values[] = absint( $args['min_rating'] );
                }

                if ( ! empty( $args['search'] ) ) {
                        $where[] = '(author_name LIKE %s OR content LIKE %s)';
                        $search_term = '%' . $wpdb->esc_like( sanitize_text_field( $args['search'] ) ) . '%';
                        $values[] = $search_term;
                        $values[] = $search_term;
                }

                if ( ! empty( $args['date_range'] ) ) {
                        switch ( $args['date_range'] ) {
                                case 'last_30':
                                        $where[] = 'date_published >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
                                        break;
                                case 'last_90':
                                        $where[] = 'date_published >= DATE_SUB(NOW(), INTERVAL 90 DAY)';
                                        break;
                                case 'last_12m':
                                        $where[] = 'date_published >= DATE_SUB(NOW(), INTERVAL 12 MONTH)';
                                        break;
                                case 'last_2y':
                                        $where[] = 'date_published >= DATE_SUB(NOW(), INTERVAL 2 YEAR)';
                                        break;
                        }
                }

                $allowed_orderby = array( 'date_published', 'rating', 'author_name', 'date_synced', 'id' );
                $orderby = in_array( $args['orderby'], $allowed_orderby, true ) ? $args['orderby'] : 'date_published';
                $order   = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';

                $where_sql = implode( ' AND ', $where );
                $limit  = absint( $args['limit'] );
                $offset = absint( $args['offset'] );

                $values[] = $limit;
                $values[] = $offset;

                // Table name is $wpdb->prefix based; $where_sql only joins fixed fragments that use placeholders; $orderby/$order are whitelisted above.
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, PluginCheck.Security.DirectDB.UnescapedDBParameter
                return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->reviews_table} WHERE {$where_sql} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d", $values ) );
        }

        public function count_reviews( $args = array() ) {
                global $wpdb;
                $where = array( '1=1' );
                $values = array();

                if ( ! empty( $args['source'] ) ) {
                        $where[] = 'source = %s';
                        $values[] = sanitize_text_field( $args['source'] );
                }
                if ( ! empty( $args['status'] ) ) {
                        $where[] = 'status = %s';
                        $values[] = sanitize_text_field( $args['status'] );
                }

                $where_sql = implode( ' AND ', $where );

                if ( ! empty( $values ) ) {
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- prefixed table name; WHERE built from placeholder fragments.
                        return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->reviews_table} WHERE {$where_sql}", $values ) );
                }
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- prefixed table name, no user input.
                return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->reviews_table}" );
        }

        public function get_average_rating( $source = '' ) {
                global $wpdb;
                if ( ! empty( $source ) ) {
                        return (float) $wpdb->get_var( $wpdb->prepare(
                                "SELECT AVG(rating) FROM {$this->reviews_table} WHERE status = 'approved' AND source = %s",
                                sanitize_text_field( $source )
                        ) );
                }
                return (float) $wpdb->get_var( "SELECT AVG(rating) FROM {$this->reviews_table} WHERE status = 'approved'" );
        }

        public function review_exists( $source, $source_id ) {
                global $wpdb;
                return (bool) $wpdb->get_var( $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$this->reviews_table} WHERE source = %s AND source_id = %s",
                        sanitize_text_field( $source ),
                        sanitize_text_field( $source_id )
                ) );
        }

        public function get_reviews_by_month( $months = 12 ) {
                global $wpdb;
                return $wpdb->get_results( $wpdb->prepare(
                        "SELECT DATE_FORMAT(date_published, '%%Y-%%m') as month, COUNT(*) as count
                         FROM {$this->reviews_table}
                         WHERE date_published >= DATE_SUB(NOW(), INTERVAL %d MONTH)
                         GROUP BY month ORDER BY month ASC",
                        absint( $months )
                ) );
        }

        public function get_reviews_by_source() {
                global $wpdb;
                return $wpdb->get_results(
                        "SELECT source, COUNT(*) as count, AVG(rating) as avg_rating
                         FROM {$this->reviews_table}
                         WHERE status = 'approved'
                         GROUP BY source"
                );
        }

        public function get_rating_distribution() {
                global $wpdb;
                return $wpdb->get_results(
                        "SELECT rating, COUNT(*) as count
                         FROM {$this->reviews_table}
                         WHERE status = 'approved'
                         GROUP BY rating ORDER BY rating DESC"
                );
        }
}
