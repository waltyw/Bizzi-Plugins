<?php if ( ! defined( 'ABSPATH' ) ) exit;
$bizzi_defaults = Bizzi_Reviews_Settings::get_defaults();
$settings = wp_parse_args( (array) get_option( 'bizzi_reviews_settings', array() ), $bizzi_defaults );
$bizzi_palette = array();
if ( function_exists( 'wp_get_global_settings' ) ) {
        $bizzi_pal = wp_get_global_settings( array( 'color', 'palette' ) );
        if ( ! empty( $bizzi_pal['theme'] ) ) {
                $bizzi_palette = $bizzi_pal['theme'];
        } elseif ( ! empty( $bizzi_pal['default'] ) ) {
                $bizzi_palette = $bizzi_pal['default'];
        }
}
$bizzi_color_fields = array(
        'default_primary_color'          => __( 'Accent (links, arrows, dots, quote marks)', 'bizzi-reviews' ),
        'default_star_color'             => __( 'Stars', 'bizzi-reviews' ),
        'default_text_color'             => __( 'Card text', 'bizzi-reviews' ),
        'default_background_color'       => __( 'Card background', 'bizzi-reviews' ),
        'default_badge_background_color' => __( 'Floating badge background', 'bizzi-reviews' ),
        'default_badge_text_color'       => __( 'Floating badge text', 'bizzi-reviews' ),
);
?>
<div class="bizzi-admin-wrap">
<div class="bizzi-admin-header"><h1><?php esc_html_e( 'Settings', 'bizzi-reviews' ); ?></h1></div>
<form id="bizzi-settings-form">
<div class="bizzi-settings-grid">
<div class="bizzi-card"><h3><?php esc_html_e( 'Moderation', 'bizzi-reviews' ); ?></h3>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Auto-Approve', 'bizzi-reviews' ); ?></label><select name="auto_approve" class="bizzi-input"><option value="all" <?php selected( $settings['auto_approve'], 'all' ); ?>>All Reviews</option><option value="min_rating" <?php selected( $settings['auto_approve'], 'min_rating' ); ?>>Minimum Rating</option><option value="manual" <?php selected( $settings['auto_approve'], 'manual' ); ?>>Manual Only</option></select></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Min Rating to Auto-Approve', 'bizzi-reviews' ); ?></label><select name="auto_approve_min_rating" class="bizzi-input"><?php for($i=1;$i<=5;$i++): ?><option value="<?php echo esc_attr( $i ); ?>" <?php selected( $settings['auto_approve_min_rating'], $i ); ?>><?php echo esc_html( $i ); ?> Stars</option><?php endfor; ?></select></div>
</div>
<div class="bizzi-card"><h3><?php esc_html_e( 'Display', 'bizzi-reviews' ); ?></h3>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Date Format', 'bizzi-reviews' ); ?></label><select name="date_format" class="bizzi-input"><option value="relative" <?php selected( $settings['date_format'], 'relative' ); ?>>Relative</option><option value="absolute" <?php selected( $settings['date_format'], 'absolute' ); ?>>Absolute</option></select></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Default Layout', 'bizzi-reviews' ); ?></label><select name="default_layout" class="bizzi-input"><?php foreach ( Bizzi_Reviews_Widgets::layouts() as $bizzi_layout ) : ?><option value="<?php echo esc_attr( $bizzi_layout ); ?>" <?php selected( $settings['default_layout'], $bizzi_layout ); ?>><?php echo esc_html( ucfirst( $bizzi_layout ) ); ?></option><?php endforeach; ?></select></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Default Columns', 'bizzi-reviews' ); ?></label><select name="default_columns" class="bizzi-input"><option value="2" <?php selected( $settings['default_columns'], '2' ); ?>>2</option><option value="3" <?php selected( $settings['default_columns'], '3' ); ?>>3</option><option value="4" <?php selected( $settings['default_columns'], '4' ); ?>>4</option></select></div>
</div>
<div class="bizzi-card"><h3><?php esc_html_e( 'SEO', 'bizzi-reviews' ); ?></h3>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Schema Output', 'bizzi-reviews' ); ?></label><select name="schema_output" class="bizzi-input"><option value="yes" <?php selected( $settings['schema_output'], 'yes' ); ?>>Enabled</option><option value="no" <?php selected( $settings['schema_output'], 'no' ); ?>>Disabled</option></select></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Business Name', 'bizzi-reviews' ); ?></label><input type="text" name="business_name" value="<?php echo esc_attr( $settings['business_name'] ); ?>" class="bizzi-input" /></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Business Type', 'bizzi-reviews' ); ?></label><select name="business_type" class="bizzi-input"><?php foreach ( Bizzi_Reviews_Schema::allowed_business_types() as $bt ) : ?><option value="<?php echo esc_attr( $bt ); ?>" <?php selected( $settings['business_type'], $bt ); ?>><?php echo esc_html( $bt ); ?></option><?php endforeach; ?></select></div>
</div>
<div class="bizzi-card bizzi-styling-card"><h3><?php esc_html_e( 'Widget Styling', 'bizzi-reviews' ); ?></h3>
<p class="bizzi-help"><?php esc_html_e( 'Match the widgets to your website. These apply to every shortcode and block, and any single widget can still override them.', 'bizzi-reviews' ); ?></p>
<div class="bizzi-styling-layout">
<div class="bizzi-styling-controls">
<?php if ( ! empty( $bizzi_palette ) ) : ?>
<p class="bizzi-help"><strong><?php esc_html_e( 'Your theme colours:', 'bizzi-reviews' ); ?></strong> <?php esc_html_e( 'pick a field, then click a swatch to use it.', 'bizzi-reviews' ); ?></p>
<div class="bizzi-palette">
<?php foreach ( $bizzi_palette as $bizzi_sw ) : if ( empty( $bizzi_sw['color'] ) ) continue; ?>
<button type="button" class="bizzi-swatch" data-color="<?php echo esc_attr( $bizzi_sw['color'] ); ?>" title="<?php echo esc_attr( isset( $bizzi_sw['name'] ) ? $bizzi_sw['name'] : $bizzi_sw['color'] ); ?>" style="background:<?php echo esc_attr( $bizzi_sw['color'] ); ?>;"></button>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php foreach ( $bizzi_color_fields as $bizzi_key => $bizzi_label ) : ?>
<div class="bizzi-form-group bizzi-color-row"><label for="<?php echo esc_attr( $bizzi_key ); ?>"><?php echo esc_html( $bizzi_label ); ?></label>
<input type="color" class="bizzi-color-input" id="<?php echo esc_attr( $bizzi_key ); ?>" name="<?php echo esc_attr( $bizzi_key ); ?>" value="<?php echo esc_attr( $settings[ $bizzi_key ] ); ?>" data-default="<?php echo esc_attr( $bizzi_defaults[ $bizzi_key ] ); ?>" /></div>
<?php endforeach; ?>
<div class="bizzi-form-group"><label for="default_card_border_radius"><?php esc_html_e( 'Card corner radius (px)', 'bizzi-reviews' ); ?></label><input type="number" min="0" max="40" class="bizzi-input" id="default_card_border_radius" name="default_card_border_radius" value="<?php echo esc_attr( $settings['default_card_border_radius'] ); ?>" /></div>
<div class="bizzi-form-group"><label for="default_font_family"><?php esc_html_e( 'Font', 'bizzi-reviews' ); ?></label><input type="text" class="bizzi-input" id="default_font_family" name="default_font_family" value="<?php echo esc_attr( $settings['default_font_family'] ); ?>" placeholder="inherit" />
<p class="bizzi-help"><?php esc_html_e( 'Leave as "inherit" to use your theme font, or enter a font name such as Poppins, sans-serif.', 'bizzi-reviews' ); ?></p></div>
<div class="bizzi-form-group"><label><input type="checkbox" id="default_card_shadow" name="default_card_shadow" value="true" <?php checked( $settings['default_card_shadow'], 'true' ); ?> /> <?php esc_html_e( 'Card shadow', 'bizzi-reviews' ); ?></label></div>
<button type="button" class="bizzi-btn" id="bizzi-reset-styling"><?php esc_html_e( 'Reset to defaults', 'bizzi-reviews' ); ?></button>
</div>
<div class="bizzi-styling-preview-wrap">
<p class="bizzi-help"><strong><?php esc_html_e( 'Live preview', 'bizzi-reviews' ); ?></strong></p>
<div class="bizzi-styling-preview" id="bizzi-styling-preview">
<div class="bizzi-pv-card"><div class="bizzi-pv-stars">★★★★★</div><p class="bizzi-pv-text"><?php esc_html_e( 'Fantastic service from start to finish. Would recommend to anyone!', 'bizzi-reviews' ); ?> <a href="#" class="bizzi-pv-link" onclick="return false;"><?php esc_html_e( 'Read more', 'bizzi-reviews' ); ?></a></p><div class="bizzi-pv-author"><span class="bizzi-pv-avatar">S</span><strong>Sarah M.</strong></div></div>
<div class="bizzi-pv-dots"><span class="bizzi-pv-dot active"></span><span class="bizzi-pv-dot"></span><span class="bizzi-pv-dot"></span></div>
<div class="bizzi-pv-badge"><span class="bizzi-pv-stars">★★★★★</span> <strong>4.9</strong> | <?php esc_html_e( 'Based on 253 Reviews', 'bizzi-reviews' ); ?></div>
</div>
</div>
</div>
</div>
</div>
<button type="submit" class="bizzi-btn bizzi-btn-primary"><?php esc_html_e( 'Save Settings', 'bizzi-reviews' ); ?></button>
</form></div>
