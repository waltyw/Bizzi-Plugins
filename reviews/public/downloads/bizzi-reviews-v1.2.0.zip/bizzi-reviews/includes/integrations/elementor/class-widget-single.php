<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

use Elementor\Controls_Manager;

/** Highlights one review: a chosen one, or your best-rated review. */
class Bizzi_Reviews_Elementor_Single_Widget extends Bizzi_Reviews_Elementor_Widget_Base {

        public function get_name() {
                return 'bizzi-single-review';
        }

        public function get_title() {
                return __( 'Bizzi Single Review', 'bizzi-reviews' );
        }

        public function get_icon() {
                return 'eicon-testimonial bizzi-el-icon';
        }

        public function get_keywords() {
                return array( 'review', 'testimonial', 'quote', 'single', 'bizzi' );
        }

        /** Latest approved reviews, so the user can pick one without looking up IDs. */
        protected function review_options() {
                $options = array( '0' => __( 'My best-rated review (automatic)', 'bizzi-reviews' ) );
                if ( ! class_exists( 'Bizzi_Reviews_Database' ) ) {
                        return $options;
                }
                $db      = new Bizzi_Reviews_Database();
                $reviews = $db->get_reviews( array( 'status' => 'approved', 'limit' => 100 ) );
                foreach ( (array) $reviews as $review ) {
                        $excerpt = wp_html_excerpt( wp_strip_all_tags( (string) $review->content ), 40, '…' );
                        $options[ (string) $review->id ] = sprintf( '%s (%d★) %s', $review->author_name, (int) $review->rating, $excerpt );
                }
                return $options;
        }

        protected function register_controls() {
                $this->start_controls_section( 'section_review', array(
                        'label' => __( 'Review', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_CONTENT,
                ) );
                $this->add_control( 'review_id', array(
                        'label'       => __( 'Review to show', 'bizzi-reviews' ),
                        'type'        => Controls_Manager::SELECT2,
                        'options'     => $this->review_options(),
                        'default'     => '0',
                        'label_block' => true,
                ) );
                $this->register_display_controls();
                $this->end_controls_section();

                $this->register_style_controls();
        }

        protected function render() {
                $renderer = $this->renderer();
                if ( ! $renderer ) {
                        return;
                }
                $s    = $this->get_settings_for_display();
                $atts = array_merge(
                        array( 'id' => isset( $s['review_id'] ) ? absint( $s['review_id'] ) : 0 ),
                        $this->style_atts( $s )
                );
                $this->output(
                        $renderer->render_single( $atts ),
                        __( 'This review is not available. Pick another review, or add and approve some reviews first.', 'bizzi-reviews' )
                );
        }
}
