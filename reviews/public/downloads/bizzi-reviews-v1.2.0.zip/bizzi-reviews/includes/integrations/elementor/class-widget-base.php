<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

use Elementor\Controls_Manager;

/**
 * Shared helpers for the Bizzi Reviews Elementor widgets: the Style tab controls,
 * settings-to-attribute mapping and the editor placeholder.
 */
abstract class Bizzi_Reviews_Elementor_Widget_Base extends \Elementor\Widget_Base {

        public function get_categories() {
                return array( 'bizzi-reviews' );
        }

        public function get_style_depends() {
                return array( 'bizzi-reviews-frontend' );
        }

        public function get_script_depends() {
                return array( 'bizzi-reviews-frontend', 'bizzi-reviews-elementor' );
        }

        public function get_custom_help_url() {
                return BIZZI_REVIEWS_SITE_URL . '/help/elementor';
        }

        /** @return Bizzi_Reviews_Shortcodes|null */
        protected function renderer() {
                $plugin = Bizzi_Reviews::instance();
                return $plugin ? $plugin->get_shortcodes() : null;
        }

        protected function is_edit_mode() {
                return class_exists( '\Elementor\Plugin' )
                        && isset( \Elementor\Plugin::$instance->editor )
                        && \Elementor\Plugin::$instance->editor->is_edit_mode();
        }

        /** The review sources that are switched on (Google, Manual, plus any Pro sources). */
        protected function source_options() {
                $options = array( '' => __( 'All sources', 'bizzi-reviews' ) );
                $plugin  = Bizzi_Reviews::instance();
                if ( $plugin && $plugin->get_sync() ) {
                        foreach ( $plugin->get_sync()->get_sources() as $slug => $source ) {
                                $options[ $slug ] = $source->get_name() ? $source->get_name() : ucfirst( $slug );
                        }
                }
                return $options;
        }

        /** Colour, card and typography controls shared by every widget. */
        protected function register_style_controls( $args = array() ) {
                $args = wp_parse_args( $args, array( 'card' => true, 'text_selector' => '.bizzi-review-content' ) );

                $this->start_controls_section( 'section_style_colours', array(
                        'label' => __( 'Colours', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_STYLE,
                ) );
                $this->add_control( 'style_note', array(
                        'type'            => Controls_Manager::RAW_HTML,
                        'raw'             => esc_html__( 'Leave a colour empty to use your site-wide styling from Bizzi Reviews › Settings.', 'bizzi-reviews' ),
                        'content_classes' => 'elementor-descriptor',
                ) );
                $colours = array(
                        'primary_color'    => __( 'Accent colour', 'bizzi-reviews' ),
                        'text_color'       => __( 'Text colour', 'bizzi-reviews' ),
                        'background_color' => __( 'Card background', 'bizzi-reviews' ),
                        'star_color'       => __( 'Star colour', 'bizzi-reviews' ),
                );
                foreach ( $colours as $key => $label ) {
                        $this->add_control( $key, array(
                                'label'   => $label,
                                'type'    => Controls_Manager::COLOR,
                                'default' => '',
                        ) );
                }
                $this->end_controls_section();

                if ( $args['card'] ) {
                        $this->start_controls_section( 'section_style_card', array(
                                'label' => __( 'Card', 'bizzi-reviews' ),
                                'tab'   => Controls_Manager::TAB_STYLE,
                        ) );
                        $this->add_control( 'card_border_radius', array(
                                'label'       => __( 'Corner radius (px)', 'bizzi-reviews' ),
                                'type'        => Controls_Manager::NUMBER,
                                'min'         => 0,
                                'max'         => 40,
                                'placeholder' => __( 'Site default', 'bizzi-reviews' ),
                        ) );
                        $this->add_control( 'card_padding', array(
                                'label'   => __( 'Padding (px)', 'bizzi-reviews' ),
                                'type'    => Controls_Manager::NUMBER,
                                'min'     => 0,
                                'max'     => 80,
                                'default' => 24,
                        ) );
                        $this->add_control( 'card_shadow', array(
                                'label'        => __( 'Shadow', 'bizzi-reviews' ),
                                'type'         => Controls_Manager::SWITCHER,
                                'return_value' => 'yes',
                                'default'      => 'yes',
                        ) );
                        $this->end_controls_section();
                }

                $this->start_controls_section( 'section_style_typography', array(
                        'label' => __( 'Typography', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_STYLE,
                ) );
                $this->add_control( 'font_family', array(
                        'label'     => __( 'Font family', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::FONT,
                        'default'   => '',
                        'selectors' => array(
                                '{{WRAPPER}} .bizzi-reviews-root, {{WRAPPER}} .bizzi-combined-rating' => 'font-family: "{{VALUE}}", sans-serif !important;',
                        ),
                ) );
                if ( $args['text_selector'] ) {
                        $this->add_responsive_control( 'font_size', array(
                                'label'      => __( 'Review text size', 'bizzi-reviews' ),
                                'type'       => Controls_Manager::SLIDER,
                                'size_units' => array( 'px', 'em', 'rem' ),
                                'range'      => array( 'px' => array( 'min' => 10, 'max' => 32 ) ),
                                'selectors'  => array(
                                        '{{WRAPPER}} ' . $args['text_selector'] => 'font-size: {{SIZE}}{{UNIT}};',
                                ),
                        ) );
                }
                $this->end_controls_section();
        }

        /** Show / hide switchers shared by the review widgets. */
        protected function register_display_controls( $condition = array() ) {
                $toggles = array(
                        'show_rating' => __( 'Show stars', 'bizzi-reviews' ),
                        'show_text'   => __( 'Show review text', 'bizzi-reviews' ),
                        'show_name'   => __( 'Show name', 'bizzi-reviews' ),
                        'show_avatar' => __( 'Show photo', 'bizzi-reviews' ),
                        'show_date'   => __( 'Show date', 'bizzi-reviews' ),
                        'show_source' => __( 'Show source', 'bizzi-reviews' ),
                );
                foreach ( $toggles as $key => $label ) {
                        $control = array(
                                'label'        => $label,
                                'type'         => Controls_Manager::SWITCHER,
                                'return_value' => 'yes',
                                'default'      => 'yes',
                        );
                        if ( $condition ) {
                                $control['condition'] = $condition;
                        }
                        $this->add_control( $key, $control );
                }
        }

        /** Converts the shared Elementor settings into shortcode-style attributes. */
        protected function style_atts( $settings ) {
                $atts = array();
                foreach ( array( 'primary_color', 'text_color', 'background_color', 'star_color' ) as $key ) {
                        if ( ! empty( $settings[ $key ] ) && is_string( $settings[ $key ] ) ) {
                                $atts[ $key ] = $settings[ $key ];
                        }
                }
                if ( isset( $settings['card_border_radius'] ) && '' !== $settings['card_border_radius'] && null !== $settings['card_border_radius'] ) {
                        $atts['card_border_radius'] = (string) max( 0, min( 40, (int) $settings['card_border_radius'] ) );
                }
                if ( isset( $settings['card_padding'] ) && '' !== $settings['card_padding'] && null !== $settings['card_padding'] ) {
                        $atts['card_padding'] = (string) max( 0, min( 80, (int) $settings['card_padding'] ) );
                }
                if ( array_key_exists( 'card_shadow', $settings ) ) {
                        $atts['card_shadow'] = 'yes' === $settings['card_shadow'] ? 'true' : 'false';
                }
                foreach ( array( 'show_rating', 'show_text', 'show_name', 'show_avatar', 'show_date', 'show_source' ) as $key ) {
                        if ( array_key_exists( $key, $settings ) ) {
                                $atts[ $key ] = 'yes' === $settings[ $key ] ? 'true' : 'false';
                        }
                }
                return $atts;
        }

        /** Prints the widget HTML, or a helpful note inside the editor when there is nothing to show. */
        protected function output( $html, $empty_message ) {
                $is_empty = '' === trim( (string) $html ) || false !== strpos( (string) $html, 'bizzi-no-reviews' );
                if ( $is_empty && $this->is_edit_mode() ) {
                        echo '<div class="bizzi-el-placeholder" style="padding:24px;border:2px dashed #ffb000;border-radius:12px;background:linear-gradient(180deg,#fff4dc 0%,#ffffff 100%);color:#000;text-align:center;font-family:inherit;">'
                                . '<strong style="display:block;margin-bottom:6px;">' . esc_html__( 'Bizzi Reviews', 'bizzi-reviews' ) . '</strong>'
                                . esc_html( $empty_message ) . ' '
                                . '<a href="' . esc_url( admin_url( 'admin.php?page=bizzi-reviews-list' ) ) . '" target="_blank" rel="noopener" style="color:#000;font-weight:600;text-decoration:underline;">' . esc_html__( 'Manage reviews', 'bizzi-reviews' ) . '</a>'
                                . '</div>';
                        return;
                }
                // The HTML comes from the plugin's own templates, which escape every value.
                echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
}
