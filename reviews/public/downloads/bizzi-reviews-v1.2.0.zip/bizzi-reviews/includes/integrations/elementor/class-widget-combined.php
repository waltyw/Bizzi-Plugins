<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

use Elementor\Controls_Manager;

/** Your overall star rating and review count across every source. */
class Bizzi_Reviews_Elementor_Combined_Widget extends Bizzi_Reviews_Elementor_Widget_Base {

        public function get_name() {
                return 'bizzi-combined-rating';
        }

        public function get_title() {
                return __( 'Bizzi Combined Rating', 'bizzi-reviews' );
        }

        public function get_icon() {
                return 'eicon-rating bizzi-el-icon';
        }

        public function get_keywords() {
                return array( 'rating', 'stars', 'score', 'average', 'reviews', 'bizzi' );
        }

        protected function register_controls() {
                $this->start_controls_section( 'section_info', array(
                        'label' => __( 'Combined rating', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_CONTENT,
                ) );
                $this->add_control( 'info', array(
                        'type'            => Controls_Manager::RAW_HTML,
                        'raw'             => esc_html__( 'Shows your average star rating and total number of approved reviews from all sources. It updates automatically.', 'bizzi-reviews' ),
                        'content_classes' => 'elementor-descriptor',
                ) );
                $this->end_controls_section();

                $this->register_style_controls( array( 'text_selector' => '' ) );
        }

        protected function render() {
                $renderer = $this->renderer();
                if ( ! $renderer ) {
                        return;
                }
                $atts = $this->style_atts( $this->get_settings_for_display() );
                unset( $atts['card_padding'], $atts['card_shadow'] );
                $this->output(
                        $renderer->render_combined( $atts ),
                        __( 'Your combined rating appears here once you have approved reviews.', 'bizzi-reviews' )
                );
        }
}
