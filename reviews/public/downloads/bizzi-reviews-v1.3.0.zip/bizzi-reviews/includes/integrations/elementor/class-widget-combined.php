<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

use Elementor\Controls_Manager;

/** Your overall star rating and review count across every source. */
class Bizzi_Reviews_Elementor_Combined_Widget extends Bizzi_Reviews_Elementor_Widget_Base {

        public function get_name() {
                return 'bizzi-combined-rating';
        }

        public function get_title() {
                return __( 'Bizzi Combined Rating', 'bizzi-reviews' );
        }

        public function get_icon() {
                return 'eicon-rating bizzi-el-icon';
        }

        public function get_keywords() {
                return array( 'rating', 'stars', 'score', 'average', 'reviews', 'bizzi' );
        }

        protected function register_controls() {
                $this->start_controls_section( 'section_info', array(
                        'label' => __( 'Combined rating', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_CONTENT,
                ) );
                $this->add_control( 'info', array(
                        'type'            => Controls_Manager::RAW_HTML,
                        'raw'             => esc_html__( 'Shows your average star rating and total number of approved reviews from all sources. It updates automatically.', 'bizzi-reviews' ),
                        'content_classes' => 'elementor-descriptor',
                ) );
                $this->add_control( 'show_count', array(
                        'label'        => __( 'Show "Based on X reviews"', 'bizzi-reviews' ),
                        'type'         => Controls_Manager::SWITCHER,
                        'return_value' => 'yes',
                        'default'      => 'yes',
                ) );
                $this->add_control( 'show_sources', array(
                        'label'        => __( 'Show per-source breakdown', 'bizzi-reviews' ),
                        'type'         => Controls_Manager::SWITCHER,
                        'return_value' => 'yes',
                        'default'      => 'yes',
                ) );
                $this->end_controls_section();

                $this->register_style_controls( array( 'text_selector' => '' ) );
                $this->register_typography_controls();
        }

        /** Font sizes, weights and alignment for each part of the combined rating. */
        protected function register_typography_controls() {
                $this->start_controls_section( 'section_style_combined_text', array(
                        'label' => __( 'Sizes & layout', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_STYLE,
                ) );

                $this->add_responsive_control( 'combined_align', array(
                        'label'     => __( 'Alignment', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::CHOOSE,
                        'options'   => array(
                                'left'   => array( 'title' => __( 'Left', 'bizzi-reviews' ), 'icon' => 'eicon-text-align-left' ),
                                'center' => array( 'title' => __( 'Centre', 'bizzi-reviews' ), 'icon' => 'eicon-text-align-center' ),
                                'right'  => array( 'title' => __( 'Right', 'bizzi-reviews' ), 'icon' => 'eicon-text-align-right' ),
                        ),
                        'selectors_dictionary' => array(
                                'left'   => 'text-align:left;--bizzi-c-justify:flex-start;',
                                'center' => 'text-align:center;--bizzi-c-justify:center;',
                                'right'  => 'text-align:right;--bizzi-c-justify:flex-end;',
                        ),
                        'selectors' => array( '{{WRAPPER}} .bizzi-combined-rating' => '{{VALUE}}' ),
                ) );

                $this->add_responsive_control( 'combined_padding', array(
                        'label'      => __( 'Padding', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => array( 'px', 'em', '%' ),
                        'selectors'  => array( '{{WRAPPER}} .bizzi-combined-rating' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
                ) );

                $sizes = array(
                        'score_size'        => array( __( 'Score size', 'bizzi-reviews' ), '.bizzi-combined-score', 48, 160, array() ),
                        'stars_size'        => array( __( 'Stars size', 'bizzi-reviews' ), '.bizzi-combined-rating .bizzi-combined-stars', 24, 100, array() ),
                        'count_size'        => array( __( '"Based on" text size', 'bizzi-reviews' ), '.bizzi-combined-count', 14, 60, array( 'show_count' => 'yes' ) ),
                        'source_name_size'  => array( __( 'Source name size', 'bizzi-reviews' ), '.bizzi-combined-source-name', 16, 60, array( 'show_sources' => 'yes' ) ),
                        'source_score_size' => array( __( 'Source score size', 'bizzi-reviews' ), '.bizzi-combined-source-score', 20, 80, array( 'show_sources' => 'yes' ) ),
                        'source_count_size' => array( __( 'Source count size', 'bizzi-reviews' ), '.bizzi-combined-source-count', 12, 60, array( 'show_sources' => 'yes' ) ),
                );
                foreach ( $sizes as $key => $s ) {
                        $this->add_responsive_control( $key, array(
                                'label'       => $s[0],
                                'type'        => Controls_Manager::SLIDER,
                                'size_units'  => array( 'px', 'em', 'rem' ),
                                'range'       => array( 'px' => array( 'min' => 8, 'max' => $s[3] ), 'em' => array( 'min' => 0.5, 'max' => 10, 'step' => 0.1 ), 'rem' => array( 'min' => 0.5, 'max' => 10, 'step' => 0.1 ) ),
                                'placeholder' => $s[2],
                                'condition'   => $s[4],
                                'selectors'   => array( '{{WRAPPER}} ' . $s[1] => 'font-size: {{SIZE}}{{UNIT}};' ),
                        ) );
                }

                $this->add_control( 'score_weight', array(
                        'label'     => __( 'Score weight', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::SELECT,
                        'default'   => '',
                        'options'   => array( '' => __( 'Default', 'bizzi-reviews' ), '300' => '300', '400' => '400', '500' => '500', '600' => '600', '700' => '700', '800' => '800', '900' => '900' ),
                        'selectors' => array( '{{WRAPPER}} .bizzi-combined-score' => 'font-weight: {{VALUE}};' ),
                ) );

                $this->add_responsive_control( 'stars_spacing', array(
                        'label'      => __( 'Space around stars', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
                        'selectors'  => array( '{{WRAPPER}} .bizzi-combined-rating .bizzi-combined-stars' => 'margin: {{SIZE}}{{UNIT}} 0;' ),
                ) );

                $this->add_responsive_control( 'sources_gap', array(
                        'label'      => __( 'Gap between sources', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
                        'condition'  => array( 'show_sources' => 'yes' ),
                        'selectors'  => array( '{{WRAPPER}} .bizzi-combined-sources' => 'gap: {{SIZE}}{{UNIT}};' ),
                ) );

                $this->end_controls_section();
        }

        protected function render() {
                $renderer = $this->renderer();
                if ( ! $renderer ) {
                        return;
                }
                $settings = $this->get_settings_for_display();
                $atts     = $this->style_atts( $settings );
                unset( $atts['card_padding'], $atts['card_shadow'] );
                $atts['show_count']   = ( isset( $settings['show_count'] ) && 'yes' !== $settings['show_count'] ) ? 'false' : 'true';
                $atts['show_sources'] = ( isset( $settings['show_sources'] ) && 'yes' !== $settings['show_sources'] ) ? 'false' : 'true';
                $this->output(
                        $renderer->render_combined( $atts ),
                        __( 'Your combined rating appears here once you have approved reviews.', 'bizzi-reviews' )
                );
        }
}
