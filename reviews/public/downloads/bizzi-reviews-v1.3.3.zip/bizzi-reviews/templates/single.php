<?php if ( ! defined( 'ABSPATH' ) ) exit;
$bizzi_widget = new Bizzi_Reviews_Widgets();
$bizzi_review = $reviews[0];
?>
<div id="<?php echo esc_attr( $id ); ?>" class="bizzi-single-wrap" style="--bizzi-primary:<?php echo esc_attr($atts['primary_color']); ?>;--bizzi-text:<?php echo esc_attr($atts['text_color']); ?>;--bizzi-bg:<?php echo esc_attr($atts['background_color']); ?>;--bizzi-star:<?php echo esc_attr($atts['star_color']); ?>;--bizzi-radius:<?php echo esc_attr($atts['card_border_radius']); ?>px;">
<div class="bizzi-review-card<?php echo esc_attr( 'true' === $atts['card_shadow'] ? ' bizzi-shadow' : '' ); ?> bizzi-single-card">
<?php if ( empty( $atts['quote_style'] ) ) : ?><div class="bizzi-single-quote">“</div><?php endif; ?>
<?php if ( $atts['show_text'] === 'true' && ! empty( $bizzi_review->content ) ) : ?><div class="bizzi-review-content bizzi-single-text"><?php echo esc_html( wp_strip_all_tags( $bizzi_review->content ) ); ?></div><?php endif; ?>
<?php if ( $atts['show_rating'] === 'true' ) : ?><div class="bizzi-review-rating"><?php echo wp_kses( $bizzi_widget->render_stars( $bizzi_review->rating, $atts['star_color'] ), Bizzi_Reviews_Widgets::allowed_html() ); ?></div><?php endif; ?>
<div class="bizzi-review-author bizzi-single-author">
<?php if ( $atts['show_avatar'] === 'true' && ! empty( $bizzi_review->author_image ) ) : ?><img class="bizzi-avatar bizzi-avatar-lg" src="<?php echo esc_url( $bizzi_review->author_image ); ?>" alt="<?php echo esc_attr( $bizzi_review->author_name ); ?>" loading="lazy" width="56" height="56" /><?php endif; ?>
<div class="bizzi-author-info">
<?php if ( $atts['show_name'] === 'true' ) : ?><span class="bizzi-author-name"><?php echo esc_html( $bizzi_review->author_name ); ?></span><?php endif; ?>
<?php if ( $atts['show_source'] === 'true' ) : ?><span class="bizzi-review-source"><?php echo wp_kses( $bizzi_widget->get_source_icon( $bizzi_review->source ), Bizzi_Reviews_Widgets::allowed_html() ); ?> <?php echo esc_html( ucfirst( $bizzi_review->source ) ); ?></span><?php endif; ?>
</div></div></div></div>
