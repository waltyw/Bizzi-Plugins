<?php if ( ! defined( 'ABSPATH' ) ) exit;
$bizzi_widget       = new Bizzi_Reviews_Widgets();
$bizzi_speed        = isset( $atts['speed'] ) ? absint( $atts['speed'] ) * 1000 : 5000;
$bizzi_autoplay     = isset( $atts['autoplay'] ) && $atts['autoplay'] === 'false' ? 'false' : 'true';
$bizzi_cols_desktop = max( 1, min( 6, absint( isset( $atts['columns'] ) ? $atts['columns'] : 3 ) ) );
$bizzi_cols_tablet  = max( 1, min( 4, absint( isset( $atts['columns_tablet'] ) ? $atts['columns_tablet'] : 2 ) ) );
$bizzi_cols_mobile  = max( 1, min( 3, absint( isset( $atts['columns_mobile'] ) ? $atts['columns_mobile'] : 1 ) ) );
$bizzi_show_arrows  = ! isset( $atts['arrows'] ) || 'false' !== $atts['arrows'];
$bizzi_show_dots    = ! isset( $atts['dots'] ) || 'false' !== $atts['dots'];
$bizzi_arrow_style  = isset( $atts['arrow_style'] ) && in_array( $atts['arrow_style'], array( 'chevron', 'arrow', 'caret', 'double' ), true ) ? $atts['arrow_style'] : 'chevron';
$bizzi_arrow_pos    = isset( $atts['arrow_position'] ) && in_array( $atts['arrow_position'], array( 'inside', 'outside', 'below', 'top' ), true ) ? $atts['arrow_position'] : 'inside';
$bizzi_wrap_class   = 'bizzi-carousel-wrap' . ( $bizzi_show_arrows ? ' bizzi-arrows-' . $bizzi_arrow_pos : ' bizzi-no-arrows' ) . ( $bizzi_show_dots ? '' : ' bizzi-no-dots' );
?>
<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $bizzi_wrap_class ); ?>" data-speed="<?php echo esc_attr( $bizzi_speed ); ?>" data-autoplay="<?php echo esc_attr( $bizzi_autoplay ); ?>" data-cols-desktop="<?php echo esc_attr( $bizzi_cols_desktop ); ?>" data-cols-tablet="<?php echo esc_attr( $bizzi_cols_tablet ); ?>" data-cols-mobile="<?php echo esc_attr( $bizzi_cols_mobile ); ?>" style="--bizzi-cols-desktop:<?php echo esc_attr( $bizzi_cols_desktop ); ?>;--bizzi-cols-tablet:<?php echo esc_attr( $bizzi_cols_tablet ); ?>;--bizzi-cols-mobile:<?php echo esc_attr( $bizzi_cols_mobile ); ?>;--bizzi-primary:<?php echo esc_attr($atts['primary_color']); ?>;--bizzi-text:<?php echo esc_attr($atts['text_color']); ?>;--bizzi-bg:<?php echo esc_attr($atts['background_color']); ?>;--bizzi-star:<?php echo esc_attr($atts['star_color']); ?>;--bizzi-radius:<?php echo esc_attr($atts['card_border_radius']); ?>px;--bizzi-padding:<?php echo esc_attr($atts['card_padding']); ?>px;">
<div class="bizzi-carousel-viewport">
<div class="bizzi-carousel-track">
<?php foreach ( $reviews as $bizzi_review ) : ?>
<div class="bizzi-carousel-slide">
<div class="bizzi-review-card<?php echo esc_attr( 'true' === $atts['card_shadow'] ? ' bizzi-shadow' : '' ); ?>">
<?php if ( $atts['show_rating'] === 'true' ) : ?>
<div class="bizzi-review-rating"><?php echo wp_kses( $bizzi_widget->render_stars( $bizzi_review->rating, $atts['star_color'] ), Bizzi_Reviews_Widgets::allowed_html() ); ?></div>
<?php endif; ?>
<?php if ( $atts['show_text'] === 'true' && ! empty( $bizzi_review->content ) ) : ?>
<div class="bizzi-review-content"><?php echo wp_kses( $bizzi_widget->truncate_text( $bizzi_review->content, absint( $atts['max_text_length'] ) ), Bizzi_Reviews_Widgets::allowed_html() ); ?></div>
<?php endif; ?>
<div class="bizzi-review-author">
<?php if ( $atts['show_avatar'] === 'true' && ! empty( $bizzi_review->author_image ) ) : ?>
<img class="bizzi-avatar" src="<?php echo esc_url( $bizzi_review->author_image ); ?>" alt="<?php echo esc_attr( $bizzi_review->author_name ); ?>" loading="lazy" width="40" height="40" />
<?php endif; ?>
<div class="bizzi-author-info">
<?php if ( $atts['show_name'] === 'true' ) : ?><span class="bizzi-author-name"><?php echo esc_html( $bizzi_review->author_name ); ?></span><?php endif; ?>
<?php if ( $atts['show_date'] === 'true' ) : ?><span class="bizzi-review-date"><?php echo esc_html( $bizzi_review->date_published ); ?></span><?php endif; ?>
<?php if ( $atts['show_source'] === 'true' ) : ?><span class="bizzi-review-source"><?php echo wp_kses( $bizzi_widget->get_source_icon( $bizzi_review->source ), Bizzi_Reviews_Widgets::allowed_html() ); ?> <?php echo esc_html( ucfirst( $bizzi_review->source ) ); ?></span><?php endif; ?>
</div></div></div></div>
<?php endforeach; ?>
</div>
</div>
<?php if ( $bizzi_show_arrows || $bizzi_show_dots ) : ?>
<div class="bizzi-carousel-nav">
<?php if ( $bizzi_show_arrows ) : ?><button type="button" class="bizzi-carousel-prev" aria-label="<?php esc_attr_e( 'Previous', 'bizzi-reviews' ); ?>"><?php echo wp_kses( Bizzi_Reviews_Widgets::arrow_icon( $bizzi_arrow_style, 'prev' ), Bizzi_Reviews_Widgets::allowed_html() ); ?></button><?php endif; ?>
<?php if ( $bizzi_show_dots ) : ?><div class="bizzi-carousel-dots"></div><?php endif; ?>
<?php if ( $bizzi_show_arrows ) : ?><button type="button" class="bizzi-carousel-next" aria-label="<?php esc_attr_e( 'Next', 'bizzi-reviews' ); ?>"><?php echo wp_kses( Bizzi_Reviews_Widgets::arrow_icon( $bizzi_arrow_style, 'next' ), Bizzi_Reviews_Widgets::allowed_html() ); ?></button><?php endif; ?>
</div>
<?php endif; ?>
</div>
