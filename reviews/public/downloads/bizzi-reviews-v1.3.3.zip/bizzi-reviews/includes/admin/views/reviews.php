<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="bizzi-admin-wrap">
<div class="bizzi-admin-header"><h1><?php
if ( isset( $bizzi_view ) && 'add' === $bizzi_view ) {
        esc_html_e( 'Add Manual Review', 'bizzi-reviews' );
} else {
        esc_html_e( 'All Reviews', 'bizzi-reviews' );
}
?></h1></div>
<?php if ( isset( $bizzi_view ) && 'add' === $bizzi_view ) : ?>
<div class="bizzi-card">
<form id="bizzi-add-review-form">
<div class="bizzi-form-grid">
<div class="bizzi-form-group"><label><?php esc_html_e( 'Name', 'bizzi-reviews' ); ?></label><input type="text" name="author_name" required class="bizzi-input" /></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Avatar URL', 'bizzi-reviews' ); ?></label><input type="url" name="author_image" class="bizzi-input" /></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Rating', 'bizzi-reviews' ); ?></label><select name="rating" class="bizzi-input"><option value="5">5 Stars</option><option value="4">4 Stars</option><option value="3">3 Stars</option><option value="2">2 Stars</option><option value="1">1 Star</option></select></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Date', 'bizzi-reviews' ); ?></label><input type="date" name="date_published" class="bizzi-input" /></div>
<div class="bizzi-form-group bizzi-full-width"><label><?php esc_html_e( 'Review Text', 'bizzi-reviews' ); ?></label><textarea name="content" rows="4" required class="bizzi-input"></textarea></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Source Label', 'bizzi-reviews' ); ?></label><input type="text" name="source_label" class="bizzi-input" placeholder="e.g. Yelp" /></div>
<div class="bizzi-form-group"><label><?php esc_html_e( 'Profile URL', 'bizzi-reviews' ); ?></label><input type="url" name="profile_url" class="bizzi-input" /></div>
</div>
<button type="submit" class="bizzi-btn bizzi-btn-primary"><?php esc_html_e( 'Add Review', 'bizzi-reviews' ); ?></button>
</form></div>
<?php else : ?>
<div class="bizzi-filters"><form method="get"><input type="hidden" name="page" value="bizzi-reviews-list" />
<select name="status" class="bizzi-input"><option value=""><?php esc_html_e( 'All Statuses', 'bizzi-reviews' ); ?></option><option value="approved" <?php selected( $status, 'approved' ); ?>>Approved</option><option value="pending" <?php selected( $status, 'pending' ); ?>>Pending</option><option value="hidden" <?php selected( $status, 'hidden' ); ?>>Hidden</option><option value="rejected" <?php selected( $status, 'rejected' ); ?>>Rejected</option></select>
<select name="source" class="bizzi-input"><option value=""><?php esc_html_e( 'All Sources', 'bizzi-reviews' ); ?></option><option value="google" <?php selected( $source, 'google' ); ?>>Google</option><option value="facebook" <?php selected( $source, 'facebook' ); ?>>Facebook</option><option value="woocommerce" <?php selected( $source, 'woocommerce' ); ?>>WooCommerce</option><option value="manual" <?php selected( $source, 'manual' ); ?>>Manual</option></select>
<input type="text" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search...', 'bizzi-reviews' ); ?>" class="bizzi-input" />
<button type="submit" class="bizzi-btn bizzi-btn-primary"><?php esc_html_e( 'Filter', 'bizzi-reviews' ); ?></button></form></div>
<div class="bizzi-card"><table class="bizzi-table"><thead><tr><th><input type="checkbox" id="bizzi-select-all" /></th><th><?php esc_html_e( 'Author', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Review', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Rating', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Source', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Status', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Date', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Actions', 'bizzi-reviews' ); ?></th></tr></thead><tbody>
<?php if ( ! empty( $reviews ) ) : foreach ( $reviews as $bizzi_r ) : ?>
<tr data-id="<?php echo absint( $bizzi_r->id ); ?>"><td><input type="checkbox" class="bizzi-review-check" value="<?php echo absint( $bizzi_r->id ); ?>" /></td><td><?php echo esc_html( $bizzi_r->author_name ); ?></td><td><?php echo esc_html( wp_trim_words( $bizzi_r->content, 15 ) ); ?></td><td><?php echo esc_html( str_repeat( '★', absint( $bizzi_r->rating ) ) ); ?></td><td><span class="bizzi-badge"><?php echo esc_html( ucfirst( $bizzi_r->source ) ); ?></span></td><td><span class="bizzi-status-<?php echo esc_attr( $bizzi_r->status ); ?>"><?php echo esc_html( ucfirst( $bizzi_r->status ) ); ?></span></td><td><?php echo esc_html( $bizzi_r->date_published ); ?></td><td class="bizzi-actions"><button class="bizzi-btn-xs bizzi-moderate" data-action="approve">✓</button><button class="bizzi-btn-xs bizzi-moderate" data-action="hide">👁</button><button class="bizzi-btn-xs bizzi-moderate" data-action="reject">✗</button><button class="bizzi-btn-xs bizzi-delete">🗑</button></td></tr>
<?php endforeach; else : ?>
<tr><td colspan="8"><?php esc_html_e( 'No reviews found.', 'bizzi-reviews' ); ?></td></tr>
<?php endif; ?>
</tbody></table>
<?php if ( $total > $per_page ) : ?>
<div class="bizzi-pagination"><?php
        for ( $bizzi_i = 1; $bizzi_i <= ceil( $total / $per_page ); $bizzi_i++ ) {
                printf( '<a href="%1$s" class="%2$s">%3$d</a> ', esc_url( add_query_arg( 'paged', $bizzi_i ) ), esc_attr( $bizzi_i === $paged ? 'active' : '' ), absint( $bizzi_i ) );
        }
?></div>
<?php endif; ?>
</div>
<?php endif; ?>
</div>
