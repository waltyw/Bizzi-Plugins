<?php if ( ! defined( 'ABSPATH' ) ) exit;
$bizzi_buy = BIZZI_REVIEWS_SITE_URL . '/#pricing';
$bizzi_rows = array(
        array( __( 'Google reviews', 'bizzi-reviews' ), true, true ),
        array( __( 'Manual reviews & testimonials', 'bizzi-reviews' ), true, true ),
        array( __( 'Carousel, single review & combined rating widgets', 'bizzi-reviews' ), true, true ),
        array( __( 'Review schema (SEO rich results)', 'bizzi-reviews' ), true, true ),
        array( __( 'Moderation & auto-approve rules', 'bizzi-reviews' ), true, true ),
        array( __( 'Facebook Page reviews', 'bizzi-reviews' ), false, true ),
        array( __( 'WooCommerce product reviews', 'bizzi-reviews' ), false, true ),
        array( __( 'Grid, list, wall & floating badge layouts', 'bizzi-reviews' ), false, true ),
        array( __( 'Priority email support & automatic updates', 'bizzi-reviews' ), false, true ),
);
?>
<div class="bizzi-admin-wrap">
<div class="bizzi-admin-header"><h1><?php esc_html_e( 'Bizzi Reviews Pro', 'bizzi-reviews' ); ?></h1></div>
<div class="bizzi-card">
<p style="font-size:15px;"><?php esc_html_e( 'Bizzi Reviews is free and fully functional. Bizzi Reviews Pro is a separate add-on, sold on our website, that adds more review sources and layouts. Everything you have set up stays in place when you add it.', 'bizzi-reviews' ); ?></p>
<table class="widefat striped" style="max-width:760px;margin:16px 0;">
<thead><tr><th><?php esc_html_e( 'Feature', 'bizzi-reviews' ); ?></th><th style="text-align:center;"><?php esc_html_e( 'Free', 'bizzi-reviews' ); ?></th><th style="text-align:center;"><?php esc_html_e( 'Pro', 'bizzi-reviews' ); ?></th></tr></thead>
<tbody>
<?php foreach ( $bizzi_rows as $bizzi_row ) : ?>
<tr><td><?php echo esc_html( $bizzi_row[0] ); ?></td><td style="text-align:center;"><?php echo $bizzi_row[1] ? '&#10003;' : '&mdash;'; ?></td><td style="text-align:center;">&#10003;</td></tr>
<?php endforeach; ?>
</tbody></table>
<p><?php esc_html_e( 'Pro: 1 website, billed yearly. Agency: unlimited websites, billed yearly. Prices are shown in your currency on our website.', 'bizzi-reviews' ); ?></p>
<a class="bizzi-btn bizzi-btn-primary" href="<?php echo esc_url( $bizzi_buy ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View Pro plans', 'bizzi-reviews' ); ?> &rarr;</a>
</div>
</div>
