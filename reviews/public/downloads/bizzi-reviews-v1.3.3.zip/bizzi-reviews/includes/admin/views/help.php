<?php if ( ! defined( 'ABSPATH' ) ) exit;
$bizzi_docs = BIZZI_REVIEWS_SITE_URL . '/help';
$bizzi_topics = array(
        array( 'getting-started', __( 'Install & first steps', 'bizzi-reviews' ), __( 'Install the plugin, open the dashboard and show your first widget in five minutes.', 'bizzi-reviews' ) ),
        array( 'connect-google', __( 'Connect Google reviews', 'bizzi-reviews' ), __( 'Create a Google Places API key, find your Place ID and run your first sync.', 'bizzi-reviews' ) ),
        array( 'woocommerce-manual', __( 'Manual reviews', 'bizzi-reviews' ), __( 'Add testimonials by hand (WooCommerce import needs Pro).', 'bizzi-reviews' ) ),
        array( 'moderation', __( 'Moderating reviews', 'bizzi-reviews' ), __( 'Approve, hide or reject reviews and set auto-approve rules.', 'bizzi-reviews' ) ),
        array( 'add-widget', __( 'Add a widget to a page', 'bizzi-reviews' ), __( 'Use blocks or shortcodes to place a carousel, single review or combined rating.', 'bizzi-reviews' ) ),
        array( 'elementor', __( 'Elementor widgets', 'bizzi-reviews' ), __( 'Drag the Bizzi Reviews widgets into any Elementor page and style them in the panel.', 'bizzi-reviews' ) ),
        array( 'widget-styling', __( 'Match widgets to your site', 'bizzi-reviews' ), __( 'Set colours, fonts, corners and shadows site-wide or per widget.', 'bizzi-reviews' ) ),
        array( 'shortcodes', __( 'Shortcode reference', 'bizzi-reviews' ), __( 'Every shortcode and attribute in one table.', 'bizzi-reviews' ) ),
        array( 'connect-facebook', __( 'Facebook reviews (Pro)', 'bizzi-reviews' ), __( 'Get a Page ID and a long-lived Page access token.', 'bizzi-reviews' ) ),
        array( 'license-updates', __( 'Pro licence & updates (Pro)', 'bizzi-reviews' ), __( 'Install the Pro add-on, activate your key and get one-click updates.', 'bizzi-reviews' ) ),
        array( 'troubleshooting', __( 'Troubleshooting', 'bizzi-reviews' ), __( 'Fixes for sync errors, missing widgets and caching.', 'bizzi-reviews' ) ),
);
?>
<div class="bizzi-admin-wrap">
<div class="bizzi-admin-header"><h1><?php esc_html_e( 'Help & Documentation', 'bizzi-reviews' ); ?></h1><span class="bizzi-version">v<?php echo esc_html( BIZZI_REVIEWS_VERSION ); ?></span></div>
<div class="bizzi-card"><h3><?php esc_html_e( 'Quick start', 'bizzi-reviews' ); ?></h3>
<ol style="line-height:1.9;margin-left:18px;">
<li><?php esc_html_e( 'Go to Sources & API and connect Google (or add a review under Add Review).', 'bizzi-reviews' ); ?></li>
<li><?php esc_html_e( 'Click Sync on the Dashboard, then check All Reviews.', 'bizzi-reviews' ); ?></li>
<li><?php esc_html_e( 'Edit a page, add the "Bizzi Reviews Carousel" block, or in Elementor drag in the "Bizzi Reviews" widget, and publish.', 'bizzi-reviews' ); ?></li>
<li><?php esc_html_e( 'Open Settings › Widget Styling to match your brand colours.', 'bizzi-reviews' ); ?></li>
</ol></div>
<div class="bizzi-plans-grid">
<?php foreach ( $bizzi_topics as $bizzi_t ) : ?>
<div class="bizzi-plan-card" style="border-top:4px solid #6C63FF;text-align:left;">
<h4><?php echo esc_html( $bizzi_t[1] ); ?></h4>
<p style="color:#4a5568;min-height:40px;"><?php echo esc_html( $bizzi_t[2] ); ?></p>
<a class="bizzi-btn" href="<?php echo esc_url( $bizzi_docs . '/' . $bizzi_t[0] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Read guide', 'bizzi-reviews' ); ?> &rarr;</a>
</div>
<?php endforeach; ?>
</div>
</div>
