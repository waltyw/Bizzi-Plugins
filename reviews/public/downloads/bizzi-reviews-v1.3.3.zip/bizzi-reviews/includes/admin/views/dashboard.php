<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="bizzi-admin-wrap">
<div class="bizzi-admin-header"><h1><span class="bizzi-logo">★</span> Bizzi Reviews</h1><span class="bizzi-version">v<?php echo esc_html( BIZZI_REVIEWS_VERSION ); ?></span></div>
<?php if ( ! defined( 'BIZZI_REVIEWS_PRO_VERSION' ) ) : ?>
<div class="notice notice-info inline" style="margin:0 0 20px;"><p><?php esc_html_e( 'Want Facebook and WooCommerce reviews, or grid, list, wall and badge layouts? They are available in the optional Pro add-on.', 'bizzi-reviews' ); ?> <a href="<?php echo esc_url( admin_url( 'admin.php?page=bizzi-reviews-upgrade' ) ); ?>"><?php esc_html_e( 'See Bizzi Reviews Pro', 'bizzi-reviews' ); ?></a></p></div>
<?php endif; ?>
<div class="bizzi-stats-grid">
<div class="bizzi-stat-card"><div class="bizzi-stat-icon" style="background:#6C63FF20;color:#6C63FF;">★</div><div class="bizzi-stat-info"><span class="bizzi-stat-number"><?php echo absint( $total ); ?></span><span class="bizzi-stat-label"><?php esc_html_e( 'Total Reviews', 'bizzi-reviews' ); ?></span></div></div>
<div class="bizzi-stat-card"><div class="bizzi-stat-icon" style="background:#FFB80020;color:#FFB800;">★</div><div class="bizzi-stat-info"><span class="bizzi-stat-number"><?php echo esc_html( round( $avg, 1 ) ); ?></span><span class="bizzi-stat-label"><?php esc_html_e( 'Average Rating', 'bizzi-reviews' ); ?></span></div></div>
<div class="bizzi-stat-card"><div class="bizzi-stat-icon" style="background:#FF658420;color:#FF6584;">⏳</div><div class="bizzi-stat-info"><span class="bizzi-stat-number"><?php echo absint( $pending ); ?></span><span class="bizzi-stat-label"><?php esc_html_e( 'Pending', 'bizzi-reviews' ); ?></span></div></div>
<div class="bizzi-stat-card"><div class="bizzi-stat-icon" style="background:#48BB7820;color:#48BB78;">✓</div><div class="bizzi-stat-info"><span class="bizzi-stat-number"><?php echo absint( count( $by_source ) ); ?></span><span class="bizzi-stat-label"><?php esc_html_e( 'Sources', 'bizzi-reviews' ); ?></span></div></div>
</div>
<div class="bizzi-dashboard-grid">
<div class="bizzi-card bizzi-chart-card"><h3><?php esc_html_e( 'Review Growth', 'bizzi-reviews' ); ?></h3>
<?php
$bizzi_max = 1;
foreach ( $by_month as $bizzi_m ) { $bizzi_max = max( $bizzi_max, (int) $bizzi_m->count ); }
?>
<?php if ( empty( $by_month ) ) : ?><p class="bizzi-help"><?php esc_html_e( 'No reviews yet. Connect a source or add a review to see growth here.', 'bizzi-reviews' ); ?></p>
<?php else : ?>
<div class="bizzi-bar-chart" style="display:flex;align-items:flex-end;gap:8px;height:220px;padding-top:10px;">
<?php foreach ( $by_month as $bizzi_m ) : $bizzi_h = max( 4, (int) round( ( (int) $bizzi_m->count / $bizzi_max ) * 180 ) ); ?>
<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;min-width:0;">
<span style="font-size:11px;font-weight:600;margin-bottom:4px;"><?php echo absint( $bizzi_m->count ); ?></span>
<span style="display:block;width:100%;max-width:36px;height:<?php echo absint( $bizzi_h ); ?>px;background:linear-gradient(180deg,#6C63FF,#a5a0ff);border-radius:6px 6px 0 0;"></span>
<span style="font-size:10px;color:#718096;margin-top:6px;white-space:nowrap;"><?php echo esc_html( $bizzi_m->month ); ?></span>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>
<div class="bizzi-card"><h3><?php esc_html_e( 'Sync Status', 'bizzi-reviews' ); ?></h3>
<div class="bizzi-sync-panel">
<?php
$bizzi_source_names = array( 'google' => 'Google', 'facebook' => 'Facebook', 'woocommerce' => 'WooCommerce', 'manual' => 'Manual' );
foreach ( $bizzi_source_names as $bizzi_skey => $bizzi_sname ) :
$bizzi_log_entry = isset( $sync_log[ $bizzi_skey ] ) ? $sync_log[ $bizzi_skey ] : array();
$bizzi_s_status = isset( $bizzi_log_entry['status'] ) ? $bizzi_log_entry['status'] : 'idle';
?>
<div class="bizzi-sync-row"><span class="bizzi-sync-dot <?php echo esc_attr( 'success' === $bizzi_s_status ? 'green' : ( 'error' === $bizzi_s_status ? 'red' : 'gray' ) ); ?>"></span><span><?php echo esc_html( $bizzi_sname ); ?></span><span class="bizzi-sync-time"><?php echo isset( $bizzi_log_entry['time'] ) ? esc_html( $bizzi_log_entry['time'] ) : '-'; ?></span><button class="bizzi-btn-sm bizzi-sync-btn" data-source="<?php echo esc_attr( $bizzi_skey ); ?>"><?php esc_html_e( 'Sync', 'bizzi-reviews' ); ?></button></div>
<?php endforeach; ?>
<button class="bizzi-btn bizzi-btn-primary" id="bizzi-sync-all"><?php esc_html_e( 'Sync All Sources', 'bizzi-reviews' ); ?></button>
</div></div>
</div>
<div class="bizzi-card"><h3><?php esc_html_e( 'Recent Reviews', 'bizzi-reviews' ); ?></h3>
<table class="bizzi-table"><thead><tr><th><?php esc_html_e( 'Author', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Rating', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Source', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Status', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Date', 'bizzi-reviews' ); ?></th><th><?php esc_html_e( 'Actions', 'bizzi-reviews' ); ?></th></tr></thead><tbody>
<?php foreach ( $recent as $bizzi_r ) : ?>
<tr data-id="<?php echo absint( $bizzi_r->id ); ?>"><td><?php echo esc_html( $bizzi_r->author_name ); ?></td><td><?php echo esc_html( str_repeat( '★', absint( $bizzi_r->rating ) ) ); ?></td><td><span class="bizzi-badge bizzi-badge-<?php echo esc_attr( $bizzi_r->source ); ?>"><?php echo esc_html( ucfirst( $bizzi_r->source ) ); ?></span></td><td><span class="bizzi-status-<?php echo esc_attr( $bizzi_r->status ); ?>"><?php echo esc_html( ucfirst( $bizzi_r->status ) ); ?></span></td><td><?php echo esc_html( $bizzi_r->date_published ); ?></td><td class="bizzi-actions"><button class="bizzi-btn-xs bizzi-moderate" data-action="approve" title="Approve">✓</button><button class="bizzi-btn-xs bizzi-moderate" data-action="hide" title="Hide">👁</button><button class="bizzi-btn-xs bizzi-moderate" data-action="reject" title="Reject">✗</button></td></tr>
<?php endforeach; ?>
</tbody></table></div>
</div>
