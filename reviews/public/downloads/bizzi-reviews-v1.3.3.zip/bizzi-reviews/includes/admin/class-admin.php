<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

class Bizzi_Reviews_Admin {

        private $sync;

        public function __construct( $sync = null ) {
                $this->sync = $sync;
        }

        public function init() {
                add_action( 'admin_menu', array( $this, 'register_menus' ) );
                add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
                add_action( 'wp_ajax_bizzi_moderate_review', array( $this, 'ajax_moderate' ) );
                add_action( 'wp_ajax_bizzi_delete_review', array( $this, 'ajax_delete' ) );
                add_action( 'wp_ajax_bizzi_add_manual_review', array( $this, 'ajax_add_manual' ) );
                add_action( 'wp_ajax_bizzi_test_connection', array( $this, 'ajax_test_connection' ) );
                add_action( 'wp_ajax_bizzi_save_source_settings', array( $this, 'ajax_save_source' ) );
                add_action( 'wp_ajax_bizzi_get_dashboard_stats', array( $this, 'ajax_dashboard_stats' ) );
        }

        public function register_menus() {
                add_menu_page( 'Bizzi Reviews', 'Bizzi Reviews', 'manage_options', 'bizzi-reviews', array( $this, 'page_dashboard' ), 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#a0a5aa"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>' ), 25 );
                add_submenu_page( 'bizzi-reviews', 'Dashboard', 'Dashboard', 'manage_options', 'bizzi-reviews', array( $this, 'page_dashboard' ) );
                add_submenu_page( 'bizzi-reviews', 'All Reviews', 'All Reviews', 'manage_options', 'bizzi-reviews-list', array( $this, 'page_reviews' ) );
                add_submenu_page( 'bizzi-reviews', 'Add Review', 'Add Review', 'manage_options', 'bizzi-reviews-add', array( $this, 'page_add_review' ) );
                add_submenu_page( 'bizzi-reviews', 'Sources & API', 'Sources & API', 'manage_options', 'bizzi-reviews-sources', array( $this, 'page_sources' ) );
                add_submenu_page( 'bizzi-reviews', 'Settings', 'Settings', 'manage_options', 'bizzi-reviews-settings', array( $this, 'page_settings' ) );
                add_submenu_page( 'bizzi-reviews', 'Help', 'Help', 'manage_options', 'bizzi-reviews-help', array( $this, 'page_help' ) );
                if ( ! defined( 'BIZZI_REVIEWS_PRO_VERSION' ) ) {
                        add_submenu_page( 'bizzi-reviews', __( 'Upgrade to Pro', 'bizzi-reviews' ), __( 'Upgrade to Pro', 'bizzi-reviews' ), 'manage_options', 'bizzi-reviews-upgrade', array( $this, 'page_upgrade' ) );
                }
        }

        public function page_help() {
                include BIZZI_REVIEWS_PATH . 'includes/admin/views/help.php';
        }

        public function enqueue_assets( $hook ) {
                if ( strpos( $hook, 'bizzi-reviews' ) === false ) {
                        return;
                }
                wp_enqueue_style( 'bizzi-reviews-admin', BIZZI_REVIEWS_URL . 'assets/css/admin.css', array(), BIZZI_REVIEWS_VERSION );
                wp_enqueue_script( 'bizzi-reviews-admin', BIZZI_REVIEWS_URL . 'assets/js/admin.js', array( 'jquery' ), BIZZI_REVIEWS_VERSION, true );
                wp_localize_script( 'bizzi-reviews-admin', 'bizziReviews', array(
                        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                        'nonce'   => wp_create_nonce( 'bizzi_reviews_nonce' ),
                ) );
        }

        public function page_dashboard() {
                $db = new Bizzi_Reviews_Database();
                $total = $db->count_reviews( array( 'status' => 'approved' ) );
                $pending = $db->count_reviews( array( 'status' => 'pending' ) );
                $avg = $db->get_average_rating();
                $by_source = $db->get_reviews_by_source();
                $by_month = $db->get_reviews_by_month( 12 );
                $recent = $db->get_reviews( array( 'status' => '', 'limit' => 10, 'orderby' => 'date_synced' ) );
                $sync_log = get_option( 'bizzi_reviews_sync_log', array() );
                include BIZZI_REVIEWS_PATH . 'includes/admin/views/dashboard.php';
        }

        public function page_reviews() {
                if ( ! current_user_can( 'manage_options' ) ) {
                        return;
                }
                $db = new Bizzi_Reviews_Database();
                // Read-only list filters and pagination from the admin list screen: nothing is saved or changed,
                // the values are sanitised and only used in a prepared SELECT, so a nonce is not required here.
                // phpcs:disable WordPress.Security.NonceVerification.Recommended
                $status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
                $source = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : '';
                $search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
                $paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
                // phpcs:enable WordPress.Security.NonceVerification.Recommended
                $bizzi_view = 'list';
                $per_page = 20;
                $reviews = $db->get_reviews( array( 'status' => $status, 'source' => $source, 'search' => $search, 'limit' => $per_page, 'offset' => ( $paged - 1 ) * $per_page ) );
                $total = $db->count_reviews( array( 'status' => $status, 'source' => $source ) );
                include BIZZI_REVIEWS_PATH . 'includes/admin/views/reviews.php';
        }

        public function page_add_review() {
                $bizzi_view = 'add';
                include BIZZI_REVIEWS_PATH . 'includes/admin/views/reviews.php';
        }

        public function page_sources() {
                $sync_log = get_option( 'bizzi_reviews_sync_log', array() );
                include BIZZI_REVIEWS_PATH . 'includes/admin/views/sources.php';
        }

        public function page_settings() {
                include BIZZI_REVIEWS_PATH . 'includes/admin/views/settings.php';
        }

        public function page_upgrade() {
                include BIZZI_REVIEWS_PATH . 'includes/admin/views/upgrade.php';
        }

        public function ajax_moderate() {
                check_ajax_referer( 'bizzi_reviews_nonce', 'nonce' );
                if ( ! current_user_can( 'manage_options' ) ) {
                        wp_send_json_error( array( 'message' => 'Unauthorized' ) );
                }
                $id = isset( $_POST['review_id'] ) ? absint( $_POST['review_id'] ) : 0;
                $action = isset( $_POST['mod_action'] ) ? sanitize_key( wp_unslash( $_POST['mod_action'] ) ) : '';
                if ( ! $id || ! in_array( $action, array( 'approve', 'reject', 'hide' ), true ) ) {
                        wp_send_json_error( array( 'message' => 'Missing parameters' ) );
                }
                $mod = new Bizzi_Reviews_Moderation();
                switch ( $action ) {
                        case 'approve': $mod->approve( $id ); break;
                        case 'reject': $mod->reject( $id ); break;
                        case 'hide': $mod->hide( $id ); break;
                }
                wp_send_json_success();
        }

        public function ajax_delete() {
                check_ajax_referer( 'bizzi_reviews_nonce', 'nonce' );
                if ( ! current_user_can( 'manage_options' ) ) {
                        wp_send_json_error( array( 'message' => 'Unauthorized' ) );
                }
                $id = isset( $_POST['review_id'] ) ? absint( $_POST['review_id'] ) : 0;
                if ( ! $id ) {
                        wp_send_json_error( array( 'message' => 'Missing ID' ) );
                }
                $db = new Bizzi_Reviews_Database();
                $db->delete_review( $id );
                wp_send_json_success();
        }

        public function ajax_add_manual() {
                check_ajax_referer( 'bizzi_reviews_nonce', 'nonce' );
                if ( ! current_user_can( 'manage_options' ) ) {
                        wp_send_json_error( array( 'message' => 'Unauthorized' ) );
                }
                $author = isset( $_POST['author_name'] ) ? substr( sanitize_text_field( wp_unslash( $_POST['author_name'] ) ), 0, 200 ) : '';
                if ( '' === $author ) {
                        wp_send_json_error( array( 'message' => __( 'Reviewer name is required.', 'bizzi-reviews' ) ) );
                }
                $date_raw = isset( $_POST['date_published'] ) ? sanitize_text_field( wp_unslash( $_POST['date_published'] ) ) : '';
                $date_ts  = $date_raw ? strtotime( $date_raw ) : false;
                $manual = new Bizzi_Review_Source_Manual();
                $id = $manual->add_review( array(
                        'author_name'    => $author,
                        'author_image'   => isset( $_POST['author_image'] ) ? esc_url_raw( wp_unslash( $_POST['author_image'] ), array( 'http', 'https' ) ) : '',
                        'rating'         => isset( $_POST['rating'] ) ? max( 1, min( 5, absint( $_POST['rating'] ) ) ) : 5,
                        'content'        => isset( $_POST['content'] ) ? wp_kses_post( wp_unslash( $_POST['content'] ) ) : '',
                        'date_published' => $date_ts ? gmdate( 'Y-m-d H:i:s', $date_ts ) : current_time( 'mysql' ),
                        'source_label'   => isset( $_POST['source_label'] ) ? sanitize_text_field( wp_unslash( $_POST['source_label'] ) ) : '',
                        'profile_url'    => isset( $_POST['profile_url'] ) ? esc_url_raw( wp_unslash( $_POST['profile_url'] ), array( 'http', 'https' ) ) : '',
                ) );
                wp_send_json_success( array( 'id' => $id ) );
        }

        public function ajax_test_connection() {
                check_ajax_referer( 'bizzi_reviews_nonce', 'nonce' );
                if ( ! current_user_can( 'manage_options' ) ) {
                        wp_send_json_error( array( 'message' => 'Unauthorized' ) );
                }
                $source_type = isset( $_POST['source'] ) ? sanitize_text_field( wp_unslash( $_POST['source'] ) ) : '';
                $sources = apply_filters( 'bizzi_reviews_testable_sources', array( 'google' => 'Bizzi_Review_Source_Google' ) );
                if ( isset( $sources[ $source_type ] ) && ! class_exists( $sources[ $source_type ] ) ) {
                        unset( $sources[ $source_type ] );
                }
                if ( ! isset( $sources[ $source_type ] ) ) {
                        wp_send_json_error( array( 'message' => 'Invalid source' ) );
                }
                $source = new $sources[ $source_type ]();
                $result = $source->test_connection();
                if ( $result['success'] ) {
                        wp_send_json_success( $result );
                } else {
                        wp_send_json_error( $result );
                }
        }

        public function ajax_save_source() {
                check_ajax_referer( 'bizzi_reviews_nonce', 'nonce' );
                if ( ! current_user_can( 'manage_options' ) ) {
                        wp_send_json_error( array( 'message' => 'Unauthorized' ) );
                }
                $source = isset( $_POST['source'] ) ? sanitize_text_field( wp_unslash( $_POST['source'] ) ) : '';
                $core = new Bizzi_Core();
                switch ( $source ) {
                        case 'google':
                                if ( isset( $_POST['api_key'] ) ) {
                                        update_option( 'bizzi_reviews_google_api_key', $core->encrypt_value( sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) ) );
                                }
                                if ( isset( $_POST['place_id'] ) ) {
                                        update_option( 'bizzi_reviews_google_place_id', sanitize_text_field( wp_unslash( $_POST['place_id'] ) ) );
                                }
                                break;
                }
                /** Lets add-ons save settings for their own sources. */
                do_action( 'bizzi_reviews_save_source_settings', $source, $core );
                wp_send_json_success();
        }

        public function ajax_dashboard_stats() {
                check_ajax_referer( 'bizzi_reviews_nonce', 'nonce' );
                if ( ! current_user_can( 'manage_options' ) ) {
                        wp_send_json_error();
                }
                $db = new Bizzi_Reviews_Database();
                wp_send_json_success( array(
                        'total' => $db->count_reviews( array( 'status' => 'approved' ) ),
                        'pending' => $db->count_reviews( array( 'status' => 'pending' ) ),
                        'avg' => round( $db->get_average_rating(), 1 ),
                        'by_source' => $db->get_reviews_by_source(),
                        'by_month' => $db->get_reviews_by_month( 12 ),
                ) );
        }
}
