<?php
/**
 * Plugin Name:       Bizzi Reviews
 * Plugin URI:        https://bizziplugins.co.uk/
 * Description:       Show your Google and manual reviews in a beautiful carousel, single-review highlight and combined rating, with review schema markup, blocks and Elementor widgets.
 * Version:           1.3.3
 * Author:            Bizzi WP Plugins
 * Author URI:        https://bizziplugins.co.uk/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       bizzi-reviews
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

define( 'BIZZI_REVIEWS_VERSION', '1.3.3' );
if ( ! defined( 'BIZZI_REVIEWS_SITE_URL' ) ) {
        // Used for documentation and "Upgrade to Pro" links only. The free plugin never contacts this site.
        define( 'BIZZI_REVIEWS_SITE_URL', 'https://bizziplugins.co.uk' );
}
define( 'BIZZI_REVIEWS_FILE', __FILE__ );
define( 'BIZZI_REVIEWS_PATH', plugin_dir_path( __FILE__ ) );
define( 'BIZZI_REVIEWS_URL', plugin_dir_url( __FILE__ ) );
define( 'BIZZI_REVIEWS_BASENAME', plugin_basename( __FILE__ ) );
define( 'BIZZI_REVIEWS_SLUG', 'bizzi-reviews' );

require_once BIZZI_REVIEWS_PATH . 'includes/class-bizzi-core.php';
require_once BIZZI_REVIEWS_PATH . 'includes/class-database.php';
require_once BIZZI_REVIEWS_PATH . 'includes/class-cache.php';
require_once BIZZI_REVIEWS_PATH . 'includes/class-moderation.php';
require_once BIZZI_REVIEWS_PATH . 'includes/class-schema.php';
require_once BIZZI_REVIEWS_PATH . 'includes/class-sync.php';
require_once BIZZI_REVIEWS_PATH . 'includes/class-shortcodes.php';
require_once BIZZI_REVIEWS_PATH . 'includes/class-widgets.php';
require_once BIZZI_REVIEWS_PATH . 'includes/sources/class-source-base.php';
require_once BIZZI_REVIEWS_PATH . 'includes/sources/class-google.php';
require_once BIZZI_REVIEWS_PATH . 'includes/sources/class-manual.php';
require_once BIZZI_REVIEWS_PATH . 'includes/integrations/class-elementor.php';
require_once BIZZI_REVIEWS_PATH . 'includes/class-bizzi-reviews.php';

if ( is_admin() ) {
        require_once BIZZI_REVIEWS_PATH . 'includes/admin/class-admin.php';
        require_once BIZZI_REVIEWS_PATH . 'includes/admin/class-settings.php';
}

function bizzi_reviews_activate() {
        $db = new Bizzi_Reviews_Database();
        $db->create_tables();
        update_option( 'bizzi_reviews_version', BIZZI_REVIEWS_VERSION );
        if ( ! get_option( 'bizzi_reviews_settings' ) ) {
                update_option( 'bizzi_reviews_settings', Bizzi_Reviews_Settings::get_defaults() );
        }
        if ( ! wp_next_scheduled( 'bizzi_reviews_daily_sync' ) ) {
                wp_schedule_event( time(), 'daily', 'bizzi_reviews_daily_sync' );
        }
}
register_activation_hook( __FILE__, 'bizzi_reviews_activate' );

function bizzi_reviews_deactivate() {
        wp_clear_scheduled_hook( 'bizzi_reviews_daily_sync' );
}
register_deactivation_hook( __FILE__, 'bizzi_reviews_deactivate' );

function bizzi_reviews_init() {
        $plugin = new Bizzi_Reviews();
        $plugin->init();
}
add_action( 'plugins_loaded', 'bizzi_reviews_init' );
