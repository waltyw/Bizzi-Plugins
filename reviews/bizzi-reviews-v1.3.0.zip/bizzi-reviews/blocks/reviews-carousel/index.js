(function(wp){
var el=wp.element.createElement;
var be=wp.blockEditor,c=wp.components;
var SOURCES=[{label:'All',value:''},{label:'Google',value:'google'},{label:'Facebook',value:'facebook'},{label:'WooCommerce',value:'woocommerce'},{label:'Manual',value:'manual'}];
function colourPanel(props){var a=props.attributes;return el(be.PanelColorSettings,{title:'Colours',initialOpen:true,colorSettings:[
{label:'Accent (arrows, dots)',value:a.primaryColor,onChange:function(v){props.setAttributes({primaryColor:v||''});}},
{label:'Stars',value:a.starColor,onChange:function(v){props.setAttributes({starColor:v||''});}},
{label:'Card text',value:a.textColor,onChange:function(v){props.setAttributes({textColor:v||''});}},
{label:'Card background',value:a.backgroundColor,onChange:function(v){props.setAttributes({backgroundColor:v||''});}}]},
el('p',{style:{fontSize:'12px',color:'#757575'}},'Leave a colour empty to use the site-wide style from Bizzi Reviews › Settings.'));}
wp.blocks.registerBlockType('bizzi-reviews/reviews-carousel',{edit:function(props){
var a=props.attributes,set=props.setAttributes,accent=a.primaryColor||'#6C63FF',r=a.cardRadius>=0?a.cardRadius+'px':'12px';
var arrow=function(t){return el('span',{style:{background:accent,color:'#fff',width:'32px',height:'32px',borderRadius:'50%',display:'inline-flex',alignItems:'center',justifyContent:'center',flexShrink:0}},t);};
return el('div',be.useBlockProps?be.useBlockProps():{},
el(be.InspectorControls,{},
el(c.PanelBody,{title:'Settings'},
el(c.SelectControl,{label:'Source',value:a.source,options:SOURCES,onChange:function(v){set({source:v});}}),
el(c.RangeControl,{label:'Limit',value:a.limit,min:1,max:50,onChange:function(v){set({limit:v});}}),
el(c.RangeControl,{label:'Speed (seconds)',value:a.speed,min:1,max:10,onChange:function(v){set({speed:v});}}),
el(c.ToggleControl,{label:'Autoplay',checked:a.autoplay,onChange:function(v){set({autoplay:v});}}),
el(c.RangeControl,{label:'Cards shown on desktop',value:a.cardsDesktop,min:1,max:6,onChange:function(v){set({cardsDesktop:v});}}),
el(c.RangeControl,{label:'Cards shown on tablet',value:a.cardsTablet,min:1,max:4,onChange:function(v){set({cardsTablet:v});}}),
el(c.RangeControl,{label:'Cards shown on mobile',value:a.cardsMobile,min:1,max:3,onChange:function(v){set({cardsMobile:v});}}),
el(c.RangeControl,{label:'Card corner radius (px, -1 = site default)',value:a.cardRadius,min:-1,max:40,onChange:function(v){set({cardRadius:v});}})),
colourPanel(props)),
el('div',{style:{padding:'20px',background:'#f7f8fc',borderRadius:'12px'}},
el('div',{style:{display:'flex',alignItems:'center',gap:'12px'}},arrow('‹'),
el('div',{style:{flex:1,background:a.backgroundColor||'#fff',color:a.textColor||'#333',borderRadius:r,padding:'16px',boxShadow:'0 4px 16px rgba(0,0,0,.08)'}},el('div',{style:{color:a.starColor||'#FFB800',letterSpacing:'2px'}},'★★★★★'),el('p',{style:{fontSize:'13px',margin:'8px 0'}},'Fantastic experience from start to finish.'),el('strong',{style:{fontSize:'13px'}},'Sarah M.')),
arrow('›')),
el('div',{style:{display:'flex',justifyContent:'center',gap:'6px',marginTop:'12px'}},el('span',{style:{width:'8px',height:'8px',borderRadius:'50%',background:accent}}),el('span',{style:{width:'8px',height:'8px',borderRadius:'50%',background:'#ddd'}}),el('span',{style:{width:'8px',height:'8px',borderRadius:'50%',background:'#ddd'}})),
el('p',{style:{color:'#888',fontSize:'12px',textAlign:'center',margin:'8px 0 0'}},'Cards: '+a.cardsDesktop+' desktop / '+a.cardsTablet+' tablet / '+a.cardsMobile+' mobile | Speed: '+a.speed+'s | Autoplay: '+(a.autoplay?'On':'Off'))));
},save:function(){return null;}});
})(window.wp);
