(function(wp){
var el=wp.element.createElement;
var be=wp.blockEditor;
wp.blocks.registerBlockType('bizzi-reviews/combined-rating',{edit:function(props){
var a=props.attributes,set=props.setAttributes;
return el('div',be.useBlockProps?be.useBlockProps():{},
el(be.InspectorControls,{},
el(be.PanelColorSettings,{title:'Colours',initialOpen:true,colorSettings:[
{label:'Rating number',value:a.primaryColor,onChange:function(v){set({primaryColor:v||''});}},
{label:'Stars',value:a.starColor,onChange:function(v){set({starColor:v||''});}},
{label:'Text',value:a.textColor,onChange:function(v){set({textColor:v||''});}},
{label:'Background',value:a.backgroundColor,onChange:function(v){set({backgroundColor:v||''});}}]},
el('p',{style:{fontSize:'12px',color:'#757575'}},'Leave a colour empty to use the site-wide style from Bizzi Reviews › Settings.'))),
el('div',{style:{padding:'30px',background:a.backgroundColor||'#fff',color:a.textColor||'#333',borderRadius:'12px',textAlign:'center',boxShadow:'0 2px 8px rgba(0,0,0,.06)'}},el('div',{style:{fontSize:'48px',fontWeight:'700',color:a.primaryColor||'#6C63FF'}},'4.9'),el('div',{style:{fontSize:'24px',color:a.starColor||'#FFB800',margin:'8px 0'}},'★★★★★'),el('div',{style:{opacity:.7,fontSize:'14px'}},'Based on all reviews (preview)')));
},save:function(){return null;}});
})(window.wp);
