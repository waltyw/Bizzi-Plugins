<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
        exit;
}

global $wpdb;

// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names are fixed; uninstall cleanup.
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}bizzi_reviews" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}bizzi_review_sources" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}bizzi_widgets" );
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_bizzi_reviews_' ) . '%', $wpdb->esc_like( '_transient_timeout_bizzi_reviews_' ) . '%' ) );
// phpcs:enable

delete_option( 'bizzi_reviews_version' );
delete_option( 'bizzi_reviews_settings' );
delete_option( 'bizzi_reviews_sync_log' );
delete_option( 'bizzi_reviews_google_api_key' );
delete_option( 'bizzi_reviews_google_place_id' );

wp_clear_scheduled_hook( 'bizzi_reviews_daily_sync' );
