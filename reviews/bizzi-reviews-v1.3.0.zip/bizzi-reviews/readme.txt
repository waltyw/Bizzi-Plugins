=== Bizzi Reviews ===
Contributors: bizziwp
Tags: reviews, google reviews, testimonials, review widget, review schema
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.3.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Show your Google and manual reviews in a beautiful carousel, single-review spotlight and combined rating, with review schema.

== Description ==

Bizzi Reviews displays your best reviews on your WordPress site to build trust and win more customers.

**Review sources**

* Google Business Profile reviews (via your own Google Places API key)
* Manual reviews and testimonials you add yourself

**Widgets (blocks, Elementor widgets and shortcodes)**

* Reviews carousel with autoplay
* Single review spotlight
* Combined rating summary
* Elementor widgets: Bizzi Reviews, Bizzi Single Review and Bizzi Combined Rating, with live preview and full styling controls

**Features**

* Review structured data (JSON-LD) for AggregateRating and Review
* Moderation with auto-approve rules
* Daily background sync via WP-Cron
* Site-wide widget styling: colours, fonts, corners and shadows
* Reviews are stored in your own database, so no external calls are made on the front end
* No limit on how many reviews you collect or display

**Bizzi Reviews Pro (optional add-on)**

A separate paid add-on, available from our website, adds Facebook and WooCommerce reviews, and grid, list, wall and floating badge layouts. The free plugin is fully functional without it and contains no locked features.

== External services ==

This plugin connects to the **Google Places API** (provided by Google) to fetch your business's public reviews. This only happens if you enter a Google API key and Place ID under Bizzi Reviews > Sources & API.

* What is sent: your Place ID and API key, when you click Test Connection or Sync Now, and once a day during the scheduled sync.
* What is received: your business name, rating and up to five most relevant public reviews (reviewer name, profile photo URL, rating, text and date).
* Google Maps Platform Terms of Service: https://cloud.google.com/maps-platform/terms
* Google Privacy Policy: https://policies.google.com/privacy

No other external services are used. Links to our website (documentation and the Pro add-on) are ordinary links and send no data.

== Installation ==

1. Install from Plugins > Add New, or upload the `bizzi-reviews` folder to `/wp-content/plugins/`.
2. Activate the plugin.
3. Go to Bizzi Reviews > Sources & API to connect Google, or add reviews under Add Review.
4. Add the "Bizzi Reviews Carousel" block to a page, or use the `[bizzi_reviews]` shortcode.

== Frequently Asked Questions ==

= How do I connect Google reviews? =
Create a Google Places API key, find your Place ID, enter both under Bizzi Reviews > Sources & API and click Test Connection.

= Why does Google only return five reviews? =
The Google Places API returns up to five reviews per request. Bizzi Reviews keeps every review it has synced, so your collection grows over time.

= Does this slow my site down? =
No. Reviews are stored locally and widget assets load only on pages that use a widget.

= What does Pro add? =
Facebook and WooCommerce reviews and more layouts. There are no review limits in the free plugin. Pro is an optional add-on installed alongside this plugin.

== Shortcodes ==

* `[bizzi_reviews layout="carousel" limit="10"]`
* `[bizzi_single_review id="12"]`
* `[bizzi_combined_rating]`

== Privacy ==

The plugin stores public review data fetched from Google, and reviews you enter, in your WordPress database. It does not track visitors or set cookies.

== Changelog ==

= 1.3.0 =
* Carousel arrows and dots can each be switched on or off. Choose an arrow icon (chevron, arrow, caret, double) and position (inside, outside, below with the dots, or top right).
* New Elementor Style sections for Arrows (size, icon size, colours, hover, border, shadow, corners, offset, vertical position) and Dots (size, active width, gap, colours, alignment, spacing).
* Speech marks: choose curly, straight, single, heavy, guillemet or low quotes (or none) for review text in the reviews and single review widgets, shown above or inline, with colour, size, font and opacity.
* Combined Rating: every part can be switched on or off (score, stars, count, source breakdown, and each source's name, score, star and count). Each part has its own Style section with text/number colour, size, weight, background, padding, corners and spacing, plus styling for the source boxes.
* Shortcode attributes: arrows, dots, arrow_style, arrow_position, quote_style, quote_position, show_count, show_sources.

= 1.2.0 =
* New: Elementor widgets. Search "Bizzi" in the Elementor panel to add Bizzi Reviews (carousel, plus grid, list and wall with Pro), Bizzi Single Review and Bizzi Combined Rating. With Pro you also get Bizzi Rating Badge.
* Elementor controls for layout, cards per row per device, autoplay, source, number of reviews, minimum stars, date range, keyword, what each card shows, colours, corners, padding, shadow, font and text size.
* The carousel now starts correctly when widgets are added after the page loads (Elementor editor, popups).
* Rating badge: top-left, top-right and inline positions are now styled.

= 1.1.1 =
* Carousel: choose how many cards show on desktop, tablet and mobile (block settings, or shortcode attributes columns, columns_tablet and columns_mobile).

= 1.1.0 =
* Free plugin split from Bizzi Reviews Pro: no licence keys, no locked features.
* Site-wide widget styling settings.
* Security hardening.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.3.0 =
Carousel arrow and dot controls, speech mark choices and Combined Rating font sizes.

= 1.2.0 =
Adds Elementor widgets for your reviews carousel, single review and combined rating.

= 1.1.1 =
You can now choose how many cards the carousel shows on each screen size.

= 1.1.0 =
Bizzi Reviews is now a free plugin. Facebook, WooCommerce and extra layouts move to the optional Pro add-on.
