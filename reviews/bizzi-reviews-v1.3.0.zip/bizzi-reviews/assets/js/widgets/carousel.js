(function(){
'use strict';
function setup(wrap){
if(wrap.bizziCarouselReady)return;
var track=wrap.querySelector('.bizzi-carousel-track');
var slides=wrap.querySelectorAll('.bizzi-carousel-slide');
var dotsContainer=wrap.querySelector('.bizzi-carousel-dots');
if(!track||!slides.length)return;
wrap.bizziCarouselReady=true;
var current=0;
var speed=parseInt(wrap.dataset.speed)||5000;
var autoplay=wrap.dataset.autoplay!=='false';
var total=slides.length;
var perView=1;
var colsDesktop=parseInt(wrap.dataset.colsDesktop)||3,colsTablet=parseInt(wrap.dataset.colsTablet)||2,colsMobile=parseInt(wrap.dataset.colsMobile)||1;
function getPerView(){if(window.innerWidth>=1024)return colsDesktop;if(window.innerWidth>=768)return colsTablet;return colsMobile;}
function update(){perView=getPerView();var maxIdx=Math.max(0,total-perView);if(current>maxIdx)current=maxIdx;track.style.transform='translateX(-'+(current*(100/perView))+'%)';updateDots();}
function buildDots(){if(!dotsContainer)return;dotsContainer.innerHTML='';var maxIdx=Math.max(1,total-getPerView()+1);for(var i=0;i<maxIdx;i++){var dot=document.createElement('button');dot.type='button';dot.className='bizzi-dot'+(i===current?' active':'');dot.setAttribute('aria-label','Slide '+(i+1));dot.dataset.index=i;dot.addEventListener('click',function(){current=parseInt(this.dataset.index);update();});dotsContainer.appendChild(dot);}}
function updateDots(){if(!dotsContainer)return;dotsContainer.querySelectorAll('.bizzi-dot').forEach(function(d,i){d.classList.toggle('active',i===current);});}
buildDots();update();
var prev=wrap.querySelector('.bizzi-carousel-prev'),next=wrap.querySelector('.bizzi-carousel-next');
if(prev)prev.addEventListener('click',function(){current=Math.max(0,current-1);update();});
if(next)next.addEventListener('click',function(){var maxIdx=Math.max(0,total-getPerView());current=current>=maxIdx?0:current+1;update();});
var interval;
function gone(){return !document.documentElement.contains(wrap);}
function stopAuto(){clearInterval(interval);interval=null;}
function startAuto(){stopAuto();if(autoplay)interval=setInterval(function(){if(gone()){cleanup();return;}var maxIdx=Math.max(0,total-getPerView());current=current>=maxIdx?0:current+1;update();},speed);}
function onResize(){if(gone()){cleanup();return;}buildDots();update();}
function cleanup(){stopAuto();window.removeEventListener('resize',onResize);}
startAuto();
wrap.addEventListener('mouseenter',stopAuto);wrap.addEventListener('mouseleave',startAuto);
var touchStartX=0;
wrap.addEventListener('touchstart',function(e){touchStartX=e.touches[0].clientX;stopAuto();},{passive:true});
wrap.addEventListener('touchend',function(e){var diff=touchStartX-e.changedTouches[0].clientX;if(Math.abs(diff)>40){if(diff>0){var maxIdx=Math.max(0,total-getPerView());current=Math.min(maxIdx,current+1);}else{current=Math.max(0,current-1);}update();}startAuto();});
window.addEventListener('resize',onResize);
}
function init(scope){var root=scope&&scope.querySelectorAll?scope:document;if(root.classList&&root.classList.contains('bizzi-carousel-wrap')){setup(root);}root.querySelectorAll('.bizzi-carousel-wrap').forEach(setup);}
window.BizziReviewsCarousel={init:init};
if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',function(){init(document);});}else{init(document);}
})();
