/* Starts Bizzi Reviews widgets that Elementor adds or re-renders (editor preview, popups, AJAX). */
(function($){
'use strict';
function start(el){
if(!el)return;
if(window.BizziReviewsFrontend)window.BizziReviewsFrontend.init(el);
if(window.BizziReviewsCarousel)window.BizziReviewsCarousel.init(el);
// Wall layout (Bizzi Reviews Pro): apply the chosen column count.
el.querySelectorAll('.bizzi-wall-wrap[data-columns]').forEach(function(wall){
var cols=parseInt(wall.dataset.columns)||3;wall.style.columnCount=cols;
wall.querySelectorAll('.bizzi-wall-item').forEach(function(item,i){item.style.animationDelay=(i*0.1)+'s';});
});
}
var widgets=['bizzi-reviews','bizzi-single-review','bizzi-combined-rating','bizzi-rating-badge'];
var hooked=false;
function hook(){
if(hooked||!window.elementorFrontend||!window.elementorFrontend.hooks)return;
hooked=true;
widgets.forEach(function(name){
window.elementorFrontend.hooks.addAction('frontend/element_ready/'+name+'.default',function($scope){start($scope&&$scope[0]);});
});
}
$(window).on('elementor/frontend/init',hook);
hook();
})(jQuery);
