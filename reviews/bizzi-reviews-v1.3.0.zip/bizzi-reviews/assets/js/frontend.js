(function(){
'use strict';
var observer=('IntersectionObserver' in window)?new IntersectionObserver(function(entries){entries.forEach(function(entry){if(entry.isIntersecting){entry.target.style.animationPlayState='running';observer.unobserve(entry.target);}});},{threshold:0.1}):null;
function once(el,key){if(el.dataset[key])return false;el.dataset[key]='1';return true;}
function init(scope){
var root=scope&&scope.querySelectorAll?scope:document;
root.querySelectorAll('.bizzi-read-more-link').forEach(function(link){
if(!once(link,'bizziReady'))return;
link.addEventListener('click',function(e){
e.preventDefault();
var card=this.closest('.bizzi-review-content');
if(card){card.style.maxHeight='none';var more=card.querySelector('.bizzi-read-more');if(more)more.style.display='none';}
});});
root.querySelectorAll('.bizzi-badge-close').forEach(function(btn){
if(!once(btn,'bizziReady'))return;
btn.addEventListener('click',function(){this.closest('.bizzi-badge-wrap').classList.add('bizzi-badge-hidden');});});
if(observer){root.querySelectorAll('.bizzi-animate-in').forEach(function(el){if(!once(el,'bizziAnim'))return;el.style.animationPlayState='paused';observer.observe(el);});}
}
window.BizziReviewsFrontend={init:init};
if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',function(){init(document);});}else{init(document);}
})();
