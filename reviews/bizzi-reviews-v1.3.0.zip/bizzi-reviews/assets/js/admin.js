(function($){
'use strict';
$(function(){
$('.bizzi-moderate').on('click',function(){var btn=$(this),row=btn.closest('tr'),id=row.data('id'),action=btn.data('action');
$.post(bizziReviews.ajaxUrl,{action:'bizzi_moderate_review',nonce:bizziReviews.nonce,review_id:id,mod_action:action},function(r){
if(r.success){row.find('.bizzi-status-approved,.bizzi-status-pending,.bizzi-status-rejected,.bizzi-status-hidden').attr('class','bizzi-status-'+action.replace('approve','approved').replace('reject','rejected').replace('hide','hidden')).text(action.charAt(0).toUpperCase()+action.slice(1).replace('approve','approved').replace('reject','rejected').replace('hide','hidden'));}
});});
$('.bizzi-delete').on('click',function(){if(!confirm('Delete this review?'))return;var row=$(this).closest('tr'),id=row.data('id');
$.post(bizziReviews.ajaxUrl,{action:'bizzi_delete_review',nonce:bizziReviews.nonce,review_id:id},function(r){if(r.success)row.fadeOut(300,function(){row.remove();});});});
$('.bizzi-sync-btn').on('click',function(){var btn=$(this),source=btn.data('source');btn.prop('disabled',true).text('Syncing...');
$.post(bizziReviews.ajaxUrl,{action:'bizzi_sync_source',nonce:bizziReviews.nonce,source:source},function(r){
btn.prop('disabled',false).text('Sync');if(r.success){alert('Sync complete: '+JSON.stringify(r.data));}else{alert('Sync failed: '+(r.data&&r.data.message||'Unknown error'));}});});
$('#bizzi-sync-all').on('click',function(){var btn=$(this);btn.prop('disabled',true).text('Syncing All...');
$.post(bizziReviews.ajaxUrl,{action:'bizzi_sync_all',nonce:bizziReviews.nonce},function(r){
btn.prop('disabled',false).text('Sync All Sources');if(r.success){alert('Sync all complete');location.reload();}});});
$('#bizzi-add-review-form').on('submit',function(e){e.preventDefault();var form=$(this),data=form.serialize();
$.post(bizziReviews.ajaxUrl,data+'&action=bizzi_add_manual_review&nonce='+bizziReviews.nonce,function(r){
if(r.success){alert('Review added!');form[0].reset();}else{alert('Error adding review');}});});
$('.bizzi-source-form').on('submit',function(e){e.preventDefault();var form=$(this),source=form.data('source'),data=form.serialize();
$.post(bizziReviews.ajaxUrl,data+'&action=bizzi_save_source_settings&nonce='+bizziReviews.nonce+'&source='+source,function(r){
if(r.success){form.find('.bizzi-conn-status').html('<span style="color:#48BB78;">Saved!</span>');}});});
$('.bizzi-test-conn').on('click',function(){var btn=$(this),source=btn.data('source'),form=btn.closest('form');
$.post(bizziReviews.ajaxUrl,{action:'bizzi_test_connection',nonce:bizziReviews.nonce,source:source},function(r){
var msg=$('<span/>').css('color',r.success?'#48BB78':'#FC8181').text(r.success?'Connected: '+((r.data&&r.data.name)||'OK'):'Failed: '+((r.data&&r.data.message)||'Error'));
form.find('.bizzi-conn-status').empty().append(msg);});});
$('#bizzi-settings-form').on('submit',function(e){e.preventDefault();
$.post(bizziReviews.ajaxUrl,$(this).serialize()+'&action=bizzi_save_settings&nonce='+bizziReviews.nonce,function(r){
if(r.success)alert('Settings saved!');});});
$('#bizzi-select-all').on('change',function(){$('.bizzi-review-check').prop('checked',this.checked);});
/* Widget Styling: theme swatches, live preview, reset */
var $pv=$('#bizzi-styling-preview');
if($pv.length){
var activeColor=$('#default_primary_color');
function toHex(c){c=String(c||'').trim();if(/^#[0-9a-f]{6}$/i.test(c))return c;if(/^#[0-9a-f]{3}$/i.test(c))return '#'+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];return null;}
function v(id){return $('#'+id).val();}
function refresh(){
var font=$.trim(v('default_font_family'))||'inherit',r=(parseInt(v('default_card_border_radius'),10)||0)+'px';
$pv.css('font-family',font);
$pv.find('.bizzi-pv-card').css({background:v('default_background_color'),color:v('default_text_color'),borderRadius:r,boxShadow:$('#default_card_shadow').is(':checked')?'0 4px 16px rgba(0,0,0,.08)':'none'});
$pv.find('.bizzi-pv-stars').css('color',v('default_star_color'));
$pv.find('.bizzi-pv-link').css('color',v('default_primary_color'));
$pv.find('.bizzi-pv-avatar').css('background',v('default_primary_color'));
$pv.find('.bizzi-pv-dot').css('background','#ddd');$pv.find('.bizzi-pv-dot.active').css('background',v('default_primary_color'));
$pv.find('.bizzi-pv-badge').css({background:v('default_badge_background_color'),color:v('default_badge_text_color')});
}
$('.bizzi-color-input').on('focus click',function(){activeColor=$(this);$('.bizzi-color-row').removeClass('is-active');$(this).closest('.bizzi-color-row').addClass('is-active');});
$('.bizzi-swatch').on('click',function(){var hex=toHex($(this).data('color'));if(hex&&activeColor.length){activeColor.val(hex);refresh();}});
$('#bizzi-reset-styling').on('click',function(){$('.bizzi-color-input').each(function(){$(this).val($(this).data('default'));});$('#default_card_border_radius').val(12);$('#default_font_family').val('inherit');$('#default_card_shadow').prop('checked',true);refresh();});
$('.bizzi-styling-controls').on('input change','input',refresh);
$('#default_primary_color').closest('.bizzi-color-row').addClass('is-active');
refresh();
}
});
})(jQuery);
