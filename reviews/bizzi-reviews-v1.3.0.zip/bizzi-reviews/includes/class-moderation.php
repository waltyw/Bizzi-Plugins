<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Bizzi_Reviews_Moderation {

	private $db;

	public function __construct() {
		$this->db = new Bizzi_Reviews_Database();
	}

	public function determine_status( $rating ) {
		$settings   = get_option( 'bizzi_reviews_settings', array() );
		$auto_mode  = isset( $settings['auto_approve'] ) ? $settings['auto_approve'] : 'all';
		$min_rating = isset( $settings['auto_approve_min_rating'] ) ? absint( $settings['auto_approve_min_rating'] ) : 4;

		switch ( $auto_mode ) {
			case 'all':
				return 'approved';
			case 'min_rating':
				return absint( $rating ) >= $min_rating ? 'approved' : 'pending';
			case 'manual':
			default:
				return 'pending';
		}
	}

	public function approve( $id ) {
		return $this->db->update_review( $id, array( 'status' => 'approved' ) );
	}

	public function reject( $id ) {
		return $this->db->update_review( $id, array( 'status' => 'rejected' ) );
	}

	public function hide( $id ) {
		return $this->db->update_review( $id, array( 'status' => 'hidden' ) );
	}

	public function bulk_action( $ids, $action ) {
		if ( ! is_array( $ids ) || empty( $ids ) ) {
			return false;
		}
		foreach ( $ids as $id ) {
			$id = absint( $id );
			switch ( $action ) {
				case 'approve':
					$this->approve( $id );
					break;
				case 'reject':
					$this->reject( $id );
					break;
				case 'hide':
					$this->hide( $id );
					break;
				case 'delete':
					$this->db->delete_review( $id );
					break;
			}
		}
		return true;
	}
}
