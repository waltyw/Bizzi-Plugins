<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Bizzi_Review_Source_Manual extends Bizzi_Review_Source_Base {

	protected $slug = 'manual';
	protected $name = 'Manual';

	public function is_configured() {
		return true;
	}

	public function fetch_reviews() {
		return array();
	}

	public function add_review( $data ) {
		$db = new Bizzi_Reviews_Database();

		return $db->insert_review( array(
			'source'         => 'manual',
			'source_id'      => 'manual_' . time() . '_' . wp_rand( 100, 999 ),
			'author_name'    => sanitize_text_field( isset( $data['author_name'] ) ? $data['author_name'] : '' ),
			'author_image'   => esc_url_raw( isset( $data['author_image'] ) ? $data['author_image'] : '' ),
			'rating'         => isset( $data['rating'] ) ? absint( $data['rating'] ) : 5,
			'content'        => wp_kses_post( isset( $data['content'] ) ? $data['content'] : '' ),
			'date_published' => sanitize_text_field( isset( $data['date_published'] ) ? $data['date_published'] : current_time( 'mysql' ) ),
			'date_synced'    => current_time( 'mysql' ),
			'status'         => 'approved',
			'metadata'       => wp_json_encode( array(
				'source_label' => sanitize_text_field( isset( $data['source_label'] ) ? $data['source_label'] : '' ),
				'profile_url'  => esc_url_raw( isset( $data['profile_url'] ) ? $data['profile_url'] : '' ),
			) ),
		) );
	}

	public function test_connection() {
		return array( 'success' => true, 'message' => 'Manual source always available' );
	}
}
