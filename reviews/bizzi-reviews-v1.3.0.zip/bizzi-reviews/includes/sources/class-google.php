<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Bizzi_Review_Source_Google extends Bizzi_Review_Source_Base {

	protected $slug = 'google';
	protected $name = 'Google Business';

	public function is_configured() {
		$api_key  = $this->get_encrypted_option( 'google_api_key' );
		$place_id = get_option( 'bizzi_reviews_google_place_id', '' );
		return ! empty( $api_key ) && ! empty( $place_id );
	}

	public function fetch_reviews() {
		$api_key  = $this->get_encrypted_option( 'google_api_key' );
		$place_id = get_option( 'bizzi_reviews_google_place_id', '' );

		if ( empty( $api_key ) || empty( $place_id ) ) {
			throw new Exception( 'Google API key or Place ID not configured' );
		}

		$url = add_query_arg( array(
			'place_id' => urlencode( $place_id ),
			'fields'   => 'reviews',
			'key'      => urlencode( $api_key ),
		), 'https://maps.googleapis.com/maps/api/place/details/json' );

		$data = $this->make_request( $url );

		if ( ! isset( $data['result']['reviews'] ) || ! is_array( $data['result']['reviews'] ) ) {
			return array();
		}

		$reviews = array();

		foreach ( $data['result']['reviews'] as $review ) {
			$reviews[] = array(
				'source_id'      => md5( ( isset( $review['author_name'] ) ? $review['author_name'] : '' ) . ( isset( $review['time'] ) ? $review['time'] : '' ) ),
				'author_name'    => isset( $review['author_name'] ) ? sanitize_text_field( $review['author_name'] ) : '',
				'author_image'   => isset( $review['profile_photo_url'] ) ? esc_url_raw( $review['profile_photo_url'] ) : '',
				'rating'         => isset( $review['rating'] ) ? absint( $review['rating'] ) : 5,
				'content'        => isset( $review['text'] ) ? wp_kses_post( $review['text'] ) : '',
				'date_published' => isset( $review['time'] ) ? gmdate( 'Y-m-d H:i:s', absint( $review['time'] ) ) : current_time( 'mysql' ),
				'metadata'       => array(
					'relative_time' => isset( $review['relative_time_description'] ) ? $review['relative_time_description'] : '',
					'language'      => isset( $review['language'] ) ? $review['language'] : '',
				),
			);
		}

		return $reviews;
	}

	public function test_connection() {
		try {
			$api_key  = $this->get_encrypted_option( 'google_api_key' );
			$place_id = get_option( 'bizzi_reviews_google_place_id', '' );

			$url = add_query_arg( array(
				'place_id' => urlencode( $place_id ),
				'fields'   => 'name',
				'key'      => urlencode( $api_key ),
			), 'https://maps.googleapis.com/maps/api/place/details/json' );

			$data = $this->make_request( $url );

			if ( isset( $data['result']['name'] ) ) {
				return array( 'success' => true, 'name' => $data['result']['name'] );
			}

			return array( 'success' => false, 'message' => 'Place not found' );
		} catch ( Exception $e ) {
			return array( 'success' => false, 'message' => $e->getMessage() );
		}
	}
}
