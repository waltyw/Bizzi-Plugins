<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

class Bizzi_Reviews extends Bizzi_Core {

        private $sync;
        private $schema;
        private $shortcodes;

        /** @var Bizzi_Reviews|null The running plugin instance, for integrations such as Elementor. */
        private static $instance = null;

        public static function instance() {
                return self::$instance;
        }

        public function get_shortcodes() {
                return $this->shortcodes;
        }

        public function get_sync() {
                return $this->sync;
        }

        public function __construct() {
                parent::__construct(
                        'bizzi-reviews',
                        BIZZI_REVIEWS_VERSION,
                        BIZZI_REVIEWS_PATH,
                        BIZZI_REVIEWS_URL
                );
        }

        public function init() {
                self::$instance   = $this;
                $this->sync       = new Bizzi_Reviews_Sync();
                $this->schema     = new Bizzi_Reviews_Schema();
                $this->shortcodes = new Bizzi_Reviews_Shortcodes();

                $this->shortcodes->set_schema( $this->schema );

                /** Review sources. Add-ons (e.g. Bizzi Reviews Pro) can add more via this filter. */
                $sources = apply_filters( 'bizzi_reviews_sources', array(
                        new Bizzi_Review_Source_Google(),
                        new Bizzi_Review_Source_Manual(),
                ) );
                foreach ( (array) $sources as $source ) {
                        $this->sync->register_source( $source );
                }

                $this->sync->init();
                $this->schema->init();
                $this->shortcodes->init();

                add_action( 'wp_enqueue_scripts', array( $this, 'register_frontend_assets' ) );
                add_action( 'init', array( $this, 'register_blocks' ) );

                /** Elementor widgets. Only loads when Elementor is active. */
                $elementor = new Bizzi_Reviews_Elementor();
                $elementor->init();

                if ( is_admin() ) {
                        $admin = new Bizzi_Reviews_Admin( $this->sync );
                        $admin->init();

                        $settings = new Bizzi_Reviews_Settings();
                        $settings->init();
                }

                /** Fires once the free plugin is ready. Add-ons hook in here. */
                do_action( 'bizzi_reviews_loaded', $this );
        }

        public function register_frontend_assets() {
                wp_register_style( 'bizzi-reviews-frontend', BIZZI_REVIEWS_URL . 'assets/css/frontend.css', array(), BIZZI_REVIEWS_VERSION );
                wp_register_script( 'bizzi-reviews-frontend', BIZZI_REVIEWS_URL . 'assets/js/frontend.js', array(), BIZZI_REVIEWS_VERSION, true );

                wp_register_style( 'bizzi-reviews-carousel', BIZZI_REVIEWS_URL . 'assets/css/widgets/carousel.css', array( 'bizzi-reviews-frontend' ), BIZZI_REVIEWS_VERSION );
                wp_register_script( 'bizzi-reviews-carousel', BIZZI_REVIEWS_URL . 'assets/js/widgets/carousel.js', array( 'bizzi-reviews-frontend' ), BIZZI_REVIEWS_VERSION, true );
                wp_register_script( 'bizzi-reviews-elementor', BIZZI_REVIEWS_URL . 'assets/js/elementor-handlers.js', array( 'jquery', 'bizzi-reviews-frontend' ), BIZZI_REVIEWS_VERSION, true );
                /** Add-ons register their own widget assets here. */
                do_action( 'bizzi_reviews_register_assets' );
        }

        public function register_blocks() {
                $blocks = array(
                        'reviews-carousel' => 'render_block_carousel',
                        'combined-rating'  => 'render_block_combined',
                );
                foreach ( $blocks as $block => $callback ) {
                        $block_dir = BIZZI_REVIEWS_PATH . 'blocks/' . $block;
                        if ( file_exists( $block_dir . '/block.json' ) ) {
                                register_block_type( $block_dir, array( 'render_callback' => array( $this, $callback ) ) );
                        }
                }
        }

        /** Maps the shared block colour attributes (camelCase) to shortcode attributes. */
        private function block_style_atts( $attributes ) {
                $atts = array();
                $map  = array(
                        'primaryColor'    => 'primary_color',
                        'textColor'       => 'text_color',
                        'backgroundColor' => 'background_color',
                        'starColor'       => 'star_color',
                );
                foreach ( $map as $from => $to ) {
                        if ( ! empty( $attributes[ $from ] ) && is_string( $attributes[ $from ] ) ) {
                                $atts[ $to ] = $attributes[ $from ];
                        }
                }
                if ( isset( $attributes['cardRadius'] ) && (int) $attributes['cardRadius'] >= 0 ) {
                        $atts['card_border_radius'] = (string) min( 40, (int) $attributes['cardRadius'] );
                }
                return $atts;
        }

        public function render_block_grid( $attributes ) {
                $attributes = is_array( $attributes ) ? $attributes : array();
                return $this->shortcodes->render_reviews( array_merge( array(
                        'layout'     => 'grid',
                        'source'     => isset( $attributes['source'] ) ? sanitize_text_field( $attributes['source'] ) : '',
                        'limit'      => isset( $attributes['limit'] ) ? absint( $attributes['limit'] ) : 12,
                        'columns'    => isset( $attributes['columns'] ) ? absint( $attributes['columns'] ) : 3,
                        'min_rating' => isset( $attributes['minRating'] ) ? absint( $attributes['minRating'] ) : 0,
                ), $this->block_style_atts( $attributes ) ) );
        }

        public function render_block_carousel( $attributes ) {
                $attributes = is_array( $attributes ) ? $attributes : array();
                return $this->shortcodes->render_reviews( array_merge( array(
                        'layout'   => 'carousel',
                        'source'   => isset( $attributes['source'] ) ? sanitize_text_field( $attributes['source'] ) : '',
                        'limit'    => isset( $attributes['limit'] ) ? absint( $attributes['limit'] ) : 10,
                        'speed'    => isset( $attributes['speed'] ) ? max( 1, absint( $attributes['speed'] ) ) : 5,
                        'autoplay' => ( ! isset( $attributes['autoplay'] ) || $attributes['autoplay'] ) ? 'true' : 'false',
                        'columns'        => isset( $attributes['cardsDesktop'] ) ? absint( $attributes['cardsDesktop'] ) : 3,
                        'columns_tablet' => isset( $attributes['cardsTablet'] ) ? absint( $attributes['cardsTablet'] ) : 2,
                        'columns_mobile' => isset( $attributes['cardsMobile'] ) ? absint( $attributes['cardsMobile'] ) : 1,
                ), $this->block_style_atts( $attributes ) ) );
        }

        public function render_block_badge( $attributes ) {
                $attributes = is_array( $attributes ) ? $attributes : array();
                return $this->shortcodes->render_badge( array_merge( array(
                        'position'    => isset( $attributes['position'] ) ? sanitize_key( $attributes['position'] ) : 'bottom-right',
                        'dismissible' => ( ! isset( $attributes['dismissible'] ) || $attributes['dismissible'] ) ? 'true' : 'false',
                ), $this->block_style_atts( $attributes ) ) );
        }

        public function render_block_combined( $attributes ) {
                $attributes = is_array( $attributes ) ? $attributes : array();
                return $this->shortcodes->render_combined( $this->block_style_atts( $attributes ) );
        }
}
