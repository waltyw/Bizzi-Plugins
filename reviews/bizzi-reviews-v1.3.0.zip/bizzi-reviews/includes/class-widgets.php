<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

class Bizzi_Reviews_Widgets {

        /** Layouts available in the free plugin. Add-ons can add more via the bizzi_reviews_layouts filter. */
        public static function layouts() {
                $layouts = apply_filters( 'bizzi_reviews_layouts', array( 'carousel', 'single' ) );
                return is_array( $layouts ) ? array_values( array_map( 'sanitize_key', $layouts ) ) : array( 'carousel', 'single' );
        }

        /**
         * Site-wide widget styling, taken from Bizzi Reviews › Settings › Widget Styling.
         * Every shortcode and block uses these unless it overrides a value itself.
         */
        public static function style_defaults() {
                $settings = get_option( 'bizzi_reviews_settings', array() );
                if ( ! is_array( $settings ) ) {
                        $settings = array();
                }
                $defaults = array(
                        'primary_color'          => '#6C63FF',
                        'text_color'             => '#333333',
                        'background_color'       => '#ffffff',
                        'star_color'             => '#FFB800',
                        'badge_background_color' => '#1A1A2E',
                        'badge_text_color'       => '#ffffff',
                        'card_border_radius'     => '12',
                        'card_shadow'            => 'true',
                        'font_family'            => 'inherit',
                );
                foreach ( $defaults as $key => $value ) {
                        if ( isset( $settings[ 'default_' . $key ] ) && '' !== $settings[ 'default_' . $key ] ) {
                                $defaults[ $key ] = (string) $settings[ 'default_' . $key ];
                        }
                }
                return $defaults;
        }

        /**
         * Accepts hex, rgb()/rgba()/hsl()/hsla(), transparent/inherit/currentColor,
         * or a theme palette variable such as var(--wp--preset--color--primary).
         */
        public static function sanitize_color( $color, $fallback ) {
                $color = trim( (string) $color );
                if ( preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $color ) ) {
                        return $color;
                }
                if ( preg_match( '/^(rgb|rgba|hsl|hsla)\(\s*[0-9.,%\s\/]+\)$/i', $color ) ) {
                        return $color;
                }
                if ( preg_match( '/^var\(--wp--preset--color--[a-z0-9-]+\)$/i', $color ) ) {
                        return $color;
                }
                if ( in_array( strtolower( $color ), array( 'transparent', 'inherit', 'currentcolor' ), true ) ) {
                        return $color;
                }
                return $fallback;
        }

        public static function sanitize_font( $font ) {
                $font = trim( (string) $font );
                if ( '' === $font || ! preg_match( '/^[a-z0-9 ,\'"\-]+$/i', $font ) ) {
                        return 'inherit';
                }
                return $font;
        }

        private function prepare_style_atts( $atts ) {
                $defaults = self::style_defaults();
                foreach ( array( 'primary_color', 'text_color', 'background_color', 'star_color' ) as $key ) {
                        $atts[ $key ] = self::sanitize_color( isset( $atts[ $key ] ) ? $atts[ $key ] : '', $defaults[ $key ] );
                }
                $atts['card_border_radius'] = (string) absint( isset( $atts['card_border_radius'] ) ? $atts['card_border_radius'] : $defaults['card_border_radius'] );
                $atts['card_padding']       = (string) absint( isset( $atts['card_padding'] ) ? $atts['card_padding'] : 24 );
                $atts['card_shadow']        = ( isset( $atts['card_shadow'] ) && 'false' === $atts['card_shadow'] ) ? 'false' : 'true';
                $atts['font_family']        = self::sanitize_font( isset( $atts['font_family'] ) ? $atts['font_family'] : $defaults['font_family'] );
                return $atts;
        }

        public function render( $layout, $reviews, $atts = array() ) {
                if ( ! in_array( $layout, self::layouts(), true ) ) {
                        return '<p>' . esc_html__( 'Invalid widget layout.', 'bizzi-reviews' ) . '</p>';
                }
                /** Lets add-ons (e.g. Bizzi Reviews Pro) supply templates for extra layouts. */
                $template = (string) apply_filters( 'bizzi_reviews_template_path', BIZZI_REVIEWS_PATH . 'templates/' . $layout . '.php', $layout );

                if ( ! file_exists( $template ) ) {
                        return '<p>' . esc_html__( 'Invalid widget layout.', 'bizzi-reviews' ) . '</p>';
                }

                wp_enqueue_style( 'bizzi-reviews-frontend' );
                wp_enqueue_script( 'bizzi-reviews-frontend' );

                switch ( $layout ) {
                        case 'carousel':
                                wp_enqueue_style( 'bizzi-reviews-carousel' );
                                wp_enqueue_script( 'bizzi-reviews-carousel' );
                                break;
                        case 'grid':
                                wp_enqueue_style( 'bizzi-reviews-grid' );
                                break;
                        case 'badge':
                                wp_enqueue_style( 'bizzi-reviews-badge' );
                                break;
                        case 'wall':
                                wp_enqueue_style( 'bizzi-reviews-wall' );
                                wp_enqueue_script( 'bizzi-reviews-wall' );
                                break;
                }

                $id   = 'bizzi-widget-' . wp_rand( 1000, 9999 );
                $atts = $this->prepare_style_atts( $atts );

                ob_start();
                include $template;
                $html = ob_get_clean();

                return '<div class="' . esc_attr( trim( 'bizzi-reviews-root ' . self::quote_classes( $atts ) ) ) . '" style="font-family:' . esc_attr( $atts['font_family'] ) . ';">' . $html . '</div>';
        }

        /** Speech mark styles: slug => label. The characters themselves live in frontend.css. */
        public static function quote_styles() {
                return array(
                        'none'      => __( 'None', 'bizzi-reviews' ),
                        'curly'     => __( '“Curly”', 'bizzi-reviews' ),
                        'straight'  => __( '"Straight"', 'bizzi-reviews' ),
                        'single'    => __( '‘Single’', 'bizzi-reviews' ),
                        'heavy'     => __( '❝Heavy❞', 'bizzi-reviews' ),
                        'guillemet' => __( '«Guillemets»', 'bizzi-reviews' ),
                        'low'       => __( '„Low-high“', 'bizzi-reviews' ),
                );
        }

        /** Classes that switch on speech marks for a widget (empty when the widget did not ask for them). */
        public static function quote_classes( $atts ) {
                $style = isset( $atts['quote_style'] ) ? sanitize_key( $atts['quote_style'] ) : '';
                if ( '' === $style || ! array_key_exists( $style, self::quote_styles() ) ) {
                        return '';
                }
                if ( 'none' === $style ) {
                        return 'bizzi-quotes-none';
                }
                $position = ( isset( $atts['quote_position'] ) && 'inline' === $atts['quote_position'] ) ? 'inline' : 'above';
                return 'bizzi-quotes bizzi-q-' . $style . ' bizzi-quotes-' . $position;
        }

        /** Carousel arrow icon as inline SVG (inherits the button's text colour and font size). */
        public static function arrow_icon( $style, $direction ) {
                $paths = array(
                        'chevron' => '<path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>',
                        'arrow'   => '<path d="M19 12H5M11 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>',
                        'caret'   => '<path d="M16 5v14L6 12z" fill="currentColor"/>',
                        'double'  => '<path d="M12 5l-7 7 7 7M19 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>',
                );
                $path = isset( $paths[ $style ] ) ? $paths[ $style ] : $paths['chevron'];
                $flip = 'next' === $direction ? ' style="transform:scaleX(-1)"' : '';
                return '<svg class="bizzi-arrow-icon" viewBox="0 0 24 24" width="1em" height="1em" aria-hidden="true" focusable="false"' . $flip . '>' . $path . '</svg>';
        }

        public function render_stars( $rating, $color = '#FFB800' ) {
                $rating = absint( $rating );
                $output = '<span class="bizzi-stars" style="color:' . esc_attr( $color ) . ';">';
                for ( $i = 1; $i <= 5; $i++ ) {
                        if ( $i <= $rating ) {
                                $output .= '<span class="bizzi-star bizzi-star-filled">★</span>';
                        } else {
                                $output .= '<span class="bizzi-star bizzi-star-empty">☆</span>';
                        }
                }
                $output .= '</span>';
                return $output;
        }

        public function get_source_icon( $source ) {
                $icons = array(
                        'google'      => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>',
                        'facebook'    => '<svg width="16" height="16" viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
                        'woocommerce' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="#96588A"><path d="M2.227 4C.9 4 0 5.012 0 6.402v8.236c0 1.39.9 2.402 2.227 2.402h5.248l2.022 2.96L11.497 17h10.276C23.1 17 24 15.988 24 14.598V6.402C24 5.012 23.1 4 21.773 4H2.227z"/></svg>',
                        'manual'      => '<svg width="16" height="16" viewBox="0 0 24 24" fill="#6C63FF"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>',
                );
                return isset( $icons[ $source ] ) ? $icons[ $source ] : '';
        }

        public function truncate_text( $text, $max_length = 200 ) {
                $text = wp_strip_all_tags( $text );
                if ( strlen( $text ) <= $max_length ) {
                        return esc_html( $text );
                }
                $truncated = substr( $text, 0, $max_length );
                $truncated = substr( $truncated, 0, strrpos( $truncated, ' ' ) );
                return esc_html( $truncated ) . '<span class="bizzi-read-more">… <a href="#" class="bizzi-read-more-link">' . esc_html__( 'Read more', 'bizzi-reviews' ) . '</a></span>';
        }
}
