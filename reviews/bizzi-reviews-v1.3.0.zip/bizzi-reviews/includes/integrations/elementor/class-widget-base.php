<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

use Elementor\Controls_Manager;

/**
 * Shared helpers for the Bizzi Reviews Elementor widgets: the Style tab controls,
 * settings-to-attribute mapping and the editor placeholder.
 */
abstract class Bizzi_Reviews_Elementor_Widget_Base extends \Elementor\Widget_Base {

        public function get_categories() {
                return array( 'bizzi-reviews' );
        }

        public function get_style_depends() {
                return array( 'bizzi-reviews-frontend' );
        }

        public function get_script_depends() {
                return array( 'bizzi-reviews-frontend', 'bizzi-reviews-elementor' );
        }

        public function get_custom_help_url() {
                return BIZZI_REVIEWS_SITE_URL . '/help/elementor';
        }

        /** @return Bizzi_Reviews_Shortcodes|null */
        protected function renderer() {
                $plugin = Bizzi_Reviews::instance();
                return $plugin ? $plugin->get_shortcodes() : null;
        }

        protected function is_edit_mode() {
                return class_exists( '\Elementor\Plugin' )
                        && isset( \Elementor\Plugin::$instance->editor )
                        && \Elementor\Plugin::$instance->editor->is_edit_mode();
        }

        /** The review sources that are switched on (Google, Manual, plus any Pro sources). */
        protected function source_options() {
                $options = array( '' => __( 'All sources', 'bizzi-reviews' ) );
                $plugin  = Bizzi_Reviews::instance();
                if ( $plugin && $plugin->get_sync() ) {
                        foreach ( $plugin->get_sync()->get_sources() as $slug => $source ) {
                                $options[ $slug ] = $source->get_name() ? $source->get_name() : ucfirst( $slug );
                        }
                }
                return $options;
        }

        /** Colour, card and typography controls shared by every widget. */
        protected function register_style_controls( $args = array() ) {
                $args = wp_parse_args( $args, array( 'card' => true, 'text_selector' => '.bizzi-review-content' ) );

                $this->start_controls_section( 'section_style_colours', array(
                        'label' => __( 'Colours', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_STYLE,
                ) );
                $this->add_control( 'style_note', array(
                        'type'            => Controls_Manager::RAW_HTML,
                        'raw'             => esc_html__( 'Leave a colour empty to use your site-wide styling from Bizzi Reviews › Settings.', 'bizzi-reviews' ),
                        'content_classes' => 'elementor-descriptor',
                ) );
                $colours = array(
                        'primary_color'    => __( 'Accent colour', 'bizzi-reviews' ),
                        'text_color'       => __( 'Text colour', 'bizzi-reviews' ),
                        'background_color' => __( 'Card background', 'bizzi-reviews' ),
                        'star_color'       => __( 'Star colour', 'bizzi-reviews' ),
                );
                foreach ( $colours as $key => $label ) {
                        $this->add_control( $key, array(
                                'label'   => $label,
                                'type'    => Controls_Manager::COLOR,
                                'default' => '',
                        ) );
                }
                $this->end_controls_section();

                if ( $args['card'] ) {
                        $this->start_controls_section( 'section_style_card', array(
                                'label' => __( 'Card', 'bizzi-reviews' ),
                                'tab'   => Controls_Manager::TAB_STYLE,
                        ) );
                        $this->add_control( 'card_border_radius', array(
                                'label'       => __( 'Corner radius (px)', 'bizzi-reviews' ),
                                'type'        => Controls_Manager::NUMBER,
                                'min'         => 0,
                                'max'         => 40,
                                'placeholder' => __( 'Site default', 'bizzi-reviews' ),
                        ) );
                        $this->add_control( 'card_padding', array(
                                'label'   => __( 'Padding (px)', 'bizzi-reviews' ),
                                'type'    => Controls_Manager::NUMBER,
                                'min'     => 0,
                                'max'     => 80,
                                'default' => 24,
                        ) );
                        $this->add_control( 'card_shadow', array(
                                'label'        => __( 'Shadow', 'bizzi-reviews' ),
                                'type'         => Controls_Manager::SWITCHER,
                                'return_value' => 'yes',
                                'default'      => 'yes',
                        ) );
                        $this->end_controls_section();
                }

                $this->start_controls_section( 'section_style_typography', array(
                        'label' => __( 'Typography', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_STYLE,
                ) );
                $this->add_control( 'font_family', array(
                        'label'     => __( 'Font family', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::FONT,
                        'default'   => '',
                        'selectors' => array(
                                '{{WRAPPER}} .bizzi-reviews-root, {{WRAPPER}} .bizzi-combined-rating' => 'font-family: "{{VALUE}}", sans-serif !important;',
                        ),
                ) );
                if ( $args['text_selector'] ) {
                        $this->add_responsive_control( 'font_size', array(
                                'label'      => __( 'Review text size', 'bizzi-reviews' ),
                                'type'       => Controls_Manager::SLIDER,
                                'size_units' => array( 'px', 'em', 'rem' ),
                                'range'      => array( 'px' => array( 'min' => 10, 'max' => 32 ) ),
                                'selectors'  => array(
                                        '{{WRAPPER}} ' . $args['text_selector'] => 'font-size: {{SIZE}}{{UNIT}};',
                                ),
                        ) );
                }
                $this->end_controls_section();
        }

        /** Speech mark choice (Content tab) and its styling (Style tab), shared by the review widgets. */
        protected function register_quote_controls( $default_style = 'none' ) {
                $has_quotes = array( 'quote_style!' => 'none' );
                $root       = '{{WRAPPER}} .bizzi-reviews-root';

                $this->start_controls_section( 'section_quotes', array(
                        'label' => __( 'Speech marks', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_CONTENT,
                ) );
                $this->add_control( 'quote_style', array(
                        'label'   => __( 'Speech marks', 'bizzi-reviews' ),
                        'type'    => Controls_Manager::SELECT,
                        'options' => Bizzi_Reviews_Widgets::quote_styles(),
                        'default' => $default_style,
                ) );
                $this->add_control( 'quote_position', array(
                        'label'     => __( 'Placement', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::SELECT,
                        'options'   => array(
                                'above'  => __( 'Large mark above the text', 'bizzi-reviews' ),
                                'inline' => __( 'Around the text (opening and closing)', 'bizzi-reviews' ),
                        ),
                        'default'   => 'above',
                        'condition' => $has_quotes,
                ) );
                $this->end_controls_section();

                $this->start_controls_section( 'section_style_quotes', array(
                        'label'     => __( 'Speech marks', 'bizzi-reviews' ),
                        'tab'       => Controls_Manager::TAB_STYLE,
                        'condition' => $has_quotes,
                ) );
                $this->add_control( 'quote_color', array(
                        'label'     => __( 'Colour', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $root => '--bizzi-q-color: {{VALUE}};' ),
                ) );
                $this->add_responsive_control( 'quote_size', array(
                        'label'      => __( 'Size', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px', 'em' ),
                        'range'      => array(
                                'px' => array( 'min' => 10, 'max' => 160 ),
                                'em' => array( 'min' => 0.5, 'max' => 8, 'step' => 0.1 ),
                        ),
                        'selectors'  => array( $root => '--bizzi-q-size: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_control( 'quote_opacity', array(
                        'label'     => __( 'Opacity', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::SLIDER,
                        'range'     => array( 'px' => array( 'min' => 0.05, 'max' => 1, 'step' => 0.05 ) ),
                        'selectors' => array( $root => '--bizzi-q-opacity: {{SIZE}};' ),
                ) );
                $this->add_control( 'quote_font', array(
                        'label'     => __( 'Font', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::FONT,
                        'default'   => '',
                        'selectors' => array( $root => '--bizzi-q-font: "{{VALUE}}", Georgia, serif;' ),
                ) );
                $this->add_responsive_control( 'quote_align', array(
                        'label'     => __( 'Alignment', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::CHOOSE,
                        'options'   => array(
                                'left'   => array( 'title' => __( 'Left', 'bizzi-reviews' ), 'icon' => 'eicon-text-align-left' ),
                                'center' => array( 'title' => __( 'Centre', 'bizzi-reviews' ), 'icon' => 'eicon-text-align-center' ),
                                'right'  => array( 'title' => __( 'Right', 'bizzi-reviews' ), 'icon' => 'eicon-text-align-right' ),
                        ),
                        'selectors' => array( $root => '--bizzi-q-align: {{VALUE}};' ),
                        'condition' => array( 'quote_position' => 'above' ),
                ) );
                $this->add_responsive_control( 'quote_gap', array(
                        'label'      => __( 'Space below the mark', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => -40, 'max' => 60 ) ),
                        'selectors'  => array( $root => '--bizzi-q-gap: {{SIZE}}{{UNIT}};' ),
                        'condition'  => array( 'quote_position' => 'above' ),
                ) );
                $this->end_controls_section();
        }

        /** Speech mark settings as shortcode-style attributes. */
        protected function quote_atts( $settings ) {
                $style = isset( $settings['quote_style'] ) ? sanitize_key( $settings['quote_style'] ) : 'none';
                if ( ! array_key_exists( $style, Bizzi_Reviews_Widgets::quote_styles() ) ) {
                        $style = 'none';
                }
                return array(
                        'quote_style'    => $style,
                        'quote_position' => ( isset( $settings['quote_position'] ) && 'inline' === $settings['quote_position'] ) ? 'inline' : 'above',
                );
        }

        /** Show / hide switchers shared by the review widgets. */
        protected function register_display_controls( $condition = array() ) {
                $toggles = array(
                        'show_rating' => __( 'Show stars', 'bizzi-reviews' ),
                        'show_text'   => __( 'Show review text', 'bizzi-reviews' ),
                        'show_name'   => __( 'Show name', 'bizzi-reviews' ),
                        'show_avatar' => __( 'Show photo', 'bizzi-reviews' ),
                        'show_date'   => __( 'Show date', 'bizzi-reviews' ),
                        'show_source' => __( 'Show source', 'bizzi-reviews' ),
                );
                foreach ( $toggles as $key => $label ) {
                        $control = array(
                                'label'        => $label,
                                'type'         => Controls_Manager::SWITCHER,
                                'return_value' => 'yes',
                                'default'      => 'yes',
                        );
                        if ( $condition ) {
                                $control['condition'] = $condition;
                        }
                        $this->add_control( $key, $control );
                }
        }

        /** Converts the shared Elementor settings into shortcode-style attributes. */
        protected function style_atts( $settings ) {
                $atts = array();
                foreach ( array( 'primary_color', 'text_color', 'background_color', 'star_color' ) as $key ) {
                        if ( ! empty( $settings[ $key ] ) && is_string( $settings[ $key ] ) ) {
                                $atts[ $key ] = $settings[ $key ];
                        }
                }
                if ( isset( $settings['card_border_radius'] ) && '' !== $settings['card_border_radius'] && null !== $settings['card_border_radius'] ) {
                        $atts['card_border_radius'] = (string) max( 0, min( 40, (int) $settings['card_border_radius'] ) );
                }
                if ( isset( $settings['card_padding'] ) && '' !== $settings['card_padding'] && null !== $settings['card_padding'] ) {
                        $atts['card_padding'] = (string) max( 0, min( 80, (int) $settings['card_padding'] ) );
                }
                if ( array_key_exists( 'card_shadow', $settings ) ) {
                        $atts['card_shadow'] = 'yes' === $settings['card_shadow'] ? 'true' : 'false';
                }
                foreach ( array( 'show_rating', 'show_text', 'show_name', 'show_avatar', 'show_date', 'show_source' ) as $key ) {
                        if ( array_key_exists( $key, $settings ) ) {
                                $atts[ $key ] = 'yes' === $settings[ $key ] ? 'true' : 'false';
                        }
                }
                return $atts;
        }

        /** Prints the widget HTML, or a helpful note inside the editor when there is nothing to show. */
        protected function output( $html, $empty_message ) {
                $is_empty = '' === trim( (string) $html ) || false !== strpos( (string) $html, 'bizzi-no-reviews' );
                if ( $is_empty && $this->is_edit_mode() ) {
                        echo '<div class="bizzi-el-placeholder" style="padding:24px;border:2px dashed #ffb000;border-radius:12px;background:linear-gradient(180deg,#fff4dc 0%,#ffffff 100%);color:#000;text-align:center;font-family:inherit;">'
                                . '<strong style="display:block;margin-bottom:6px;">' . esc_html__( 'Bizzi Reviews', 'bizzi-reviews' ) . '</strong>'
                                . esc_html( $empty_message ) . ' '
                                . '<a href="' . esc_url( admin_url( 'admin.php?page=bizzi-reviews-list' ) ) . '" target="_blank" rel="noopener" style="color:#000;font-weight:600;text-decoration:underline;">' . esc_html__( 'Manage reviews', 'bizzi-reviews' ) . '</a>'
                                . '</div>';
                        return;
                }
                // The HTML comes from the plugin's own templates, which escape every value.
                echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
}
