<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

use Elementor\Controls_Manager;

/** Floating rating badge. Only registered when Bizzi Reviews Pro provides the badge layout. */
class Bizzi_Reviews_Elementor_Badge_Widget extends Bizzi_Reviews_Elementor_Widget_Base {

        public function get_name() {
                return 'bizzi-rating-badge';
        }

        public function get_title() {
                return __( 'Bizzi Rating Badge', 'bizzi-reviews' );
        }

        public function get_icon() {
                return 'eicon-star bizzi-el-icon';
        }

        public function get_keywords() {
                return array( 'badge', 'floating', 'rating', 'stars', 'bizzi' );
        }

        public function get_style_depends() {
                return array( 'bizzi-reviews-frontend', 'bizzi-reviews-badge' );
        }

        protected function register_controls() {
                $this->start_controls_section( 'section_badge', array(
                        'label' => __( 'Badge', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_CONTENT,
                ) );
                $this->add_control( 'position', array(
                        'label'   => __( 'Position on screen', 'bizzi-reviews' ),
                        'type'    => Controls_Manager::SELECT,
                        'options' => array(
                                'inline'       => __( 'Inline (where you place the widget)', 'bizzi-reviews' ),
                                'bottom-right' => __( 'Bottom right', 'bizzi-reviews' ),
                                'bottom-left'  => __( 'Bottom left', 'bizzi-reviews' ),
                                'top-right'    => __( 'Top right', 'bizzi-reviews' ),
                                'top-left'     => __( 'Top left', 'bizzi-reviews' ),
                        ),
                        'default' => 'bottom-right',
                ) );
                $this->add_control( 'dismissible', array(
                        'label'        => __( 'Visitors can close it', 'bizzi-reviews' ),
                        'type'         => Controls_Manager::SWITCHER,
                        'return_value' => 'yes',
                        'default'      => 'yes',
                ) );
                $this->add_control( 'link', array(
                        'label'       => __( 'Link (optional)', 'bizzi-reviews' ),
                        'type'        => Controls_Manager::URL,
                        'placeholder' => 'https://',
                        'options'     => false,
                ) );
                $this->end_controls_section();

                $this->register_style_controls( array( 'card' => false, 'text_selector' => '' ) );
        }

        protected function render() {
                $renderer = $this->renderer();
                if ( ! $renderer ) {
                        return;
                }
                $s    = $this->get_settings_for_display();
                $atts = array_merge( array(
                        'position'    => isset( $s['position'] ) ? sanitize_key( $s['position'] ) : 'bottom-right',
                        'dismissible' => ( isset( $s['dismissible'] ) && 'yes' === $s['dismissible'] ) ? 'true' : 'false',
                        'link'        => ! empty( $s['link']['url'] ) ? esc_url_raw( $s['link']['url'] ) : '',
                ), $this->style_atts( $s ) );
                $this->output(
                        $renderer->render_badge( $atts ),
                        __( 'The floating badge appears here once you have approved reviews.', 'bizzi-reviews' )
                );
        }
}
