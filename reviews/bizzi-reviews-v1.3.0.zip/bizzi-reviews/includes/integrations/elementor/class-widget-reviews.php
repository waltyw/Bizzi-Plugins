<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

use Elementor\Controls_Manager;

/** Bizzi Reviews: carousel (free) plus grid, list and wall when Bizzi Reviews Pro is active. */
class Bizzi_Reviews_Elementor_Reviews_Widget extends Bizzi_Reviews_Elementor_Widget_Base {

        public function get_name() {
                return 'bizzi-reviews';
        }

        public function get_title() {
                return __( 'Bizzi Reviews', 'bizzi-reviews' );
        }

        public function get_icon() {
                return 'eicon-review bizzi-el-icon';
        }

        public function get_keywords() {
                return array( 'reviews', 'testimonials', 'google', 'carousel', 'slider', 'rating', 'stars', 'bizzi' );
        }

        public function get_style_depends() {
                $handles = array( 'bizzi-reviews-frontend', 'bizzi-reviews-carousel' );
                foreach ( array( 'grid', 'wall' ) as $layout ) {
                        if ( wp_style_is( 'bizzi-reviews-' . $layout, 'registered' ) ) {
                                $handles[] = 'bizzi-reviews-' . $layout;
                        }
                }
                return $handles;
        }

        public function get_script_depends() {
                $handles = array( 'bizzi-reviews-frontend', 'bizzi-reviews-carousel' );
                if ( wp_script_is( 'bizzi-reviews-wall', 'registered' ) ) {
                        $handles[] = 'bizzi-reviews-wall';
                }
                $handles[] = 'bizzi-reviews-elementor';
                return $handles;
        }

        /** Layouts available right now. The badge has its own widget, and single reviews have theirs. */
        protected function layout_options() {
                $labels  = array(
                        'carousel' => __( 'Carousel', 'bizzi-reviews' ),
                        'grid'     => __( 'Grid', 'bizzi-reviews' ),
                        'list'     => __( 'List', 'bizzi-reviews' ),
                        'wall'     => __( 'Wall', 'bizzi-reviews' ),
                );
                $options = array();
                foreach ( Bizzi_Reviews_Widgets::layouts() as $layout ) {
                        if ( in_array( $layout, array( 'badge', 'single' ), true ) ) {
                                continue;
                        }
                        $options[ $layout ] = isset( $labels[ $layout ] ) ? $labels[ $layout ] : ucfirst( $layout );
                }
                return $options ? $options : array( 'carousel' => $labels['carousel'] );
        }

        protected function register_controls() {
                $layouts     = $this->layout_options();
                $has_columns = array_values( array_intersect( array_keys( $layouts ), array( 'carousel', 'grid', 'wall' ) ) );

                $this->start_controls_section( 'section_layout', array(
                        'label' => __( 'Layout', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_CONTENT,
                ) );
                $this->add_control( 'layout', array(
                        'label'   => __( 'Layout', 'bizzi-reviews' ),
                        'type'    => Controls_Manager::SELECT,
                        'options' => $layouts,
                        'default' => 'carousel',
                ) );
                if ( ! defined( 'BIZZI_REVIEWS_PRO_VERSION' ) ) {
                        $this->add_control( 'pro_note', array(
                                'type'            => Controls_Manager::RAW_HTML,
                                'raw'             => sprintf(
                                        /* translators: %s: link to Bizzi Reviews Pro */
                                        esc_html__( 'Want grid, list, wall and floating badge layouts? %s', 'bizzi-reviews' ),
                                        '<a href="' . esc_url( BIZZI_REVIEWS_SITE_URL . '/#pricing' ) . '" target="_blank" rel="noopener" style="color:#ffb000;font-weight:600;">' . esc_html__( 'Get Bizzi Reviews Pro', 'bizzi-reviews' ) . '</a>'
                                ),
                                'content_classes' => 'elementor-descriptor',
                        ) );
                }
                $this->add_responsive_control( 'columns', array(
                        'label'          => __( 'Cards per row', 'bizzi-reviews' ),
                        'type'           => Controls_Manager::SELECT,
                        'options'        => array( '1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5', '6' => '6' ),
                        'default'        => '3',
                        'tablet_default' => '2',
                        'mobile_default' => '1',
                        'condition'      => array( 'layout' => $has_columns ? $has_columns : array( 'carousel' ) ),
                ) );
                if ( isset( $layouts['grid'] ) ) {
                        $this->add_control( 'masonry', array(
                                'label'        => __( 'Masonry (cards keep their own height)', 'bizzi-reviews' ),
                                'type'         => Controls_Manager::SWITCHER,
                                'return_value' => 'yes',
                                'default'      => '',
                                'condition'    => array( 'layout' => 'grid' ),
                        ) );
                }
                $this->add_control( 'autoplay', array(
                        'label'        => __( 'Autoplay', 'bizzi-reviews' ),
                        'type'         => Controls_Manager::SWITCHER,
                        'return_value' => 'yes',
                        'default'      => 'yes',
                        'condition'    => array( 'layout' => 'carousel' ),
                ) );
                $this->add_control( 'speed', array(
                        'label'     => __( 'Seconds per slide', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::NUMBER,
                        'min'       => 1,
                        'max'       => 30,
                        'default'   => 5,
                        'condition' => array( 'layout' => 'carousel', 'autoplay' => 'yes' ),
                ) );
                $this->end_controls_section();

                $this->start_controls_section( 'section_query', array(
                        'label' => __( 'Reviews', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_CONTENT,
                ) );
                $this->add_control( 'source', array(
                        'label'   => __( 'Source', 'bizzi-reviews' ),
                        'type'    => Controls_Manager::SELECT,
                        'options' => $this->source_options(),
                        'default' => '',
                ) );
                $this->add_control( 'limit', array(
                        'label'   => __( 'Number of reviews', 'bizzi-reviews' ),
                        'type'    => Controls_Manager::NUMBER,
                        'min'     => 1,
                        'max'     => 100,
                        'default' => 10,
                ) );
                $this->add_control( 'min_rating', array(
                        'label'   => __( 'Minimum stars', 'bizzi-reviews' ),
                        'type'    => Controls_Manager::SELECT,
                        'options' => array(
                                '0' => __( 'Any rating', 'bizzi-reviews' ),
                                '5' => __( '5 stars only', 'bizzi-reviews' ),
                                '4' => __( '4 stars and up', 'bizzi-reviews' ),
                                '3' => __( '3 stars and up', 'bizzi-reviews' ),
                                '2' => __( '2 stars and up', 'bizzi-reviews' ),
                        ),
                        'default' => '0',
                ) );
                $this->add_control( 'date_range', array(
                        'label'   => __( 'Date range', 'bizzi-reviews' ),
                        'type'    => Controls_Manager::SELECT,
                        'options' => array(
                                ''         => __( 'All time', 'bizzi-reviews' ),
                                'last_30'  => __( 'Last 30 days', 'bizzi-reviews' ),
                                'last_90'  => __( 'Last 90 days', 'bizzi-reviews' ),
                                'last_12m' => __( 'Last 12 months', 'bizzi-reviews' ),
                                'last_2y'  => __( 'Last 2 years', 'bizzi-reviews' ),
                        ),
                        'default' => '',
                ) );
                $this->add_control( 'keyword', array(
                        'label'       => __( 'Only reviews containing', 'bizzi-reviews' ),
                        'type'        => Controls_Manager::TEXT,
                        'placeholder' => __( 'e.g. friendly', 'bizzi-reviews' ),
                        'default'     => '',
                ) );
                $this->end_controls_section();

                $this->start_controls_section( 'section_display', array(
                        'label' => __( 'Card content', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_CONTENT,
                ) );
                $this->register_display_controls();
                $this->add_control( 'max_text_length', array(
                        'label'   => __( 'Shorten text after (characters)', 'bizzi-reviews' ),
                        'type'    => Controls_Manager::NUMBER,
                        'min'     => 50,
                        'max'     => 2000,
                        'default' => 200,
                        'condition' => array( 'show_text' => 'yes' ),
                ) );
                $this->end_controls_section();

                $this->register_navigation_controls();
                $this->register_quote_controls( 'none' );
                $this->register_style_controls();
                $this->register_navigation_style_controls();
        }

        /** Carousel arrows and dots: on/off, icon and position (Content tab). */
        protected function register_navigation_controls() {
                $this->start_controls_section( 'section_navigation', array(
                        'label'     => __( 'Arrows & dots', 'bizzi-reviews' ),
                        'tab'       => Controls_Manager::TAB_CONTENT,
                        'condition' => array( 'layout' => 'carousel' ),
                ) );
                $this->add_control( 'show_arrows', array(
                        'label'        => __( 'Show arrows', 'bizzi-reviews' ),
                        'type'         => Controls_Manager::SWITCHER,
                        'return_value' => 'yes',
                        'default'      => 'yes',
                ) );
                $this->add_control( 'arrow_style', array(
                        'label'     => __( 'Arrow icon', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::SELECT,
                        'options'   => array(
                                'chevron' => __( 'Chevron', 'bizzi-reviews' ),
                                'arrow'   => __( 'Arrow', 'bizzi-reviews' ),
                                'caret'   => __( 'Triangle', 'bizzi-reviews' ),
                                'double'  => __( 'Double chevron', 'bizzi-reviews' ),
                        ),
                        'default'   => 'chevron',
                        'condition' => array( 'show_arrows' => 'yes' ),
                ) );
                $this->add_control( 'arrow_position', array(
                        'label'     => __( 'Arrow position', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::SELECT,
                        'options'   => array(
                                'inside'  => __( 'Over the cards (sides)', 'bizzi-reviews' ),
                                'outside' => __( 'Beside the cards', 'bizzi-reviews' ),
                                'below'   => __( 'Below, either side of the dots', 'bizzi-reviews' ),
                                'top'     => __( 'Top right, above the cards', 'bizzi-reviews' ),
                        ),
                        'default'   => 'inside',
                        'condition' => array( 'show_arrows' => 'yes' ),
                ) );
                $this->add_control( 'show_dots', array(
                        'label'        => __( 'Show dots', 'bizzi-reviews' ),
                        'type'         => Controls_Manager::SWITCHER,
                        'return_value' => 'yes',
                        'default'      => 'yes',
                        'separator'    => 'before',
                ) );
                $this->end_controls_section();
        }

        /** Arrow and dot styling (Style tab). */
        protected function register_navigation_style_controls() {
                $wrap   = '{{WRAPPER}} .bizzi-carousel-wrap';
                $arrows = '{{WRAPPER}} .bizzi-carousel-prev, {{WRAPPER}} .bizzi-carousel-next';
                $hover  = '{{WRAPPER}} .bizzi-carousel-prev:hover, {{WRAPPER}} .bizzi-carousel-next:hover, {{WRAPPER}} .bizzi-carousel-prev:focus-visible, {{WRAPPER}} .bizzi-carousel-next:focus-visible';

                $this->start_controls_section( 'section_style_arrows', array(
                        'label'     => __( 'Arrows', 'bizzi-reviews' ),
                        'tab'       => Controls_Manager::TAB_STYLE,
                        'condition' => array( 'layout' => 'carousel', 'show_arrows' => 'yes' ),
                ) );
                $this->add_responsive_control( 'arrow_size', array(
                        'label'      => __( 'Button size', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 20, 'max' => 90 ) ),
                        'selectors'  => array( $wrap => '--bizzi-arrow-size: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( 'arrow_icon_size', array(
                        'label'      => __( 'Icon size', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 8, 'max' => 60 ) ),
                        'selectors'  => array( $arrows => 'font-size: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( 'arrow_radius', array(
                        'label'      => __( 'Roundness', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( '%', 'px' ),
                        'range'      => array( '%' => array( 'min' => 0, 'max' => 50 ), 'px' => array( 'min' => 0, 'max' => 45 ) ),
                        'selectors'  => array( $arrows => 'border-radius: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( 'arrow_offset', array(
                        'label'       => __( 'Distance from edge', 'bizzi-reviews' ),
                        'description' => __( 'Beside the cards: the gap between arrows and cards.', 'bizzi-reviews' ),
                        'type'        => Controls_Manager::SLIDER,
                        'size_units'  => array( 'px' ),
                        'range'       => array( 'px' => array( 'min' => -60, 'max' => 100 ) ),
                        'selectors'   => array( $wrap => '--bizzi-arrow-offset: {{SIZE}}{{UNIT}};' ),
                        'condition'   => array( 'arrow_position!' => 'below' ),
                ) );
                $this->add_responsive_control( 'arrow_vertical', array(
                        'label'       => __( 'Vertical position (%)', 'bizzi-reviews' ),
                        'description' => __( '0 = top of the cards, 50 = middle, 100 = bottom.', 'bizzi-reviews' ),
                        'type'        => Controls_Manager::SLIDER,
                        'range'       => array( 'px' => array( 'min' => 0, 'max' => 100 ) ),
                        'selectors'   => array( $wrap => '--bizzi-arrow-top-n: calc({{SIZE}} / 100);' ),
                        'condition'   => array( 'arrow_position' => array( 'inside', 'outside' ) ),
                ) );

                $this->start_controls_tabs( 'arrow_tabs' );
                $this->start_controls_tab( 'arrow_tab_normal', array( 'label' => __( 'Normal', 'bizzi-reviews' ) ) );
                $this->add_control( 'arrow_color', array(
                        'label'     => __( 'Icon colour', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $arrows => 'color: {{VALUE}};' ),
                ) );
                $this->add_control( 'arrow_bg', array(
                        'label'     => __( 'Background', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $arrows => 'background-color: {{VALUE}};' ),
                ) );
                $this->add_control( 'arrow_opacity', array(
                        'label'     => __( 'Opacity', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::SLIDER,
                        'range'     => array( 'px' => array( 'min' => 0.1, 'max' => 1, 'step' => 0.05 ) ),
                        'selectors' => array( $arrows => 'opacity: {{SIZE}};' ),
                ) );
                $this->end_controls_tab();
                $this->start_controls_tab( 'arrow_tab_hover', array( 'label' => __( 'Hover', 'bizzi-reviews' ) ) );
                $this->add_control( 'arrow_color_hover', array(
                        'label'     => __( 'Icon colour', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $hover => 'color: {{VALUE}};' ),
                ) );
                $this->add_control( 'arrow_bg_hover', array(
                        'label'     => __( 'Background', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $hover => 'background-color: {{VALUE}};' ),
                ) );
                $this->add_control( 'arrow_border_hover', array(
                        'label'     => __( 'Border colour', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $hover => 'border-color: {{VALUE}};' ),
                ) );
                $this->add_control( 'arrow_opacity_hover', array(
                        'label'     => __( 'Opacity', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::SLIDER,
                        'range'     => array( 'px' => array( 'min' => 0.1, 'max' => 1, 'step' => 0.05 ) ),
                        'selectors' => array( $hover => 'opacity: {{SIZE}};' ),
                ) );
                $this->end_controls_tab();
                $this->end_controls_tabs();

                $this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
                        'name'      => 'arrow_border',
                        'selector'  => $arrows,
                        'separator' => 'before',
                ) );
                $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
                        'name'     => 'arrow_shadow',
                        'selector' => $arrows,
                ) );
                $this->end_controls_section();

                $this->start_controls_section( 'section_style_dots', array(
                        'label'     => __( 'Dots', 'bizzi-reviews' ),
                        'tab'       => Controls_Manager::TAB_STYLE,
                        'condition' => array( 'layout' => 'carousel', 'show_dots' => 'yes' ),
                ) );
                $this->add_responsive_control( 'dots_align', array(
                        'label'     => __( 'Alignment', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::CHOOSE,
                        'options'   => array(
                                'flex-start' => array( 'title' => __( 'Left', 'bizzi-reviews' ), 'icon' => 'eicon-h-align-left' ),
                                'center'     => array( 'title' => __( 'Centre', 'bizzi-reviews' ), 'icon' => 'eicon-h-align-center' ),
                                'flex-end'   => array( 'title' => __( 'Right', 'bizzi-reviews' ), 'icon' => 'eicon-h-align-right' ),
                        ),
                        'selectors' => array( $wrap => '--bizzi-dots-justify: {{VALUE}};' ),
                ) );
                $this->add_responsive_control( 'dots_space', array(
                        'label'      => __( 'Space above dots', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
                        'selectors'  => array( $wrap => '--bizzi-dots-space: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( 'dot_size', array(
                        'label'      => __( 'Dot size', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 4, 'max' => 30 ) ),
                        'selectors'  => array( $wrap => '--bizzi-dot-size: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( 'dot_active_width', array(
                        'label'       => __( 'Active dot width', 'bizzi-reviews' ),
                        'description' => __( 'Make it wider than the dot size for a pill shape.', 'bizzi-reviews' ),
                        'type'        => Controls_Manager::SLIDER,
                        'size_units'  => array( 'px' ),
                        'range'       => array( 'px' => array( 'min' => 4, 'max' => 60 ) ),
                        'selectors'   => array( $wrap => '--bizzi-dot-active-w: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( 'dot_gap', array(
                        'label'      => __( 'Space between dots', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
                        'selectors'  => array( $wrap => '--bizzi-dot-gap: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_control( 'dot_color', array(
                        'label'     => __( 'Dot colour', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $wrap => '--bizzi-dot-color: {{VALUE}};' ),
                ) );
                $this->add_control( 'dot_active_color', array(
                        'label'     => __( 'Active dot colour', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $wrap => '--bizzi-dot-active: {{VALUE}};' ),
                ) );
                $this->end_controls_section();
        }

        protected function render() {
                $renderer = $this->renderer();
                if ( ! $renderer ) {
                        return;
                }
                $s       = $this->get_settings_for_display();
                $layouts = $this->layout_options();
                $layout  = isset( $s['layout'], $layouts[ $s['layout'] ] ) ? $s['layout'] : 'carousel';

                $atts = array_merge( array(
                        'layout'          => $layout,
                        'source'          => isset( $s['source'] ) ? sanitize_text_field( $s['source'] ) : '',
                        'limit'           => ! empty( $s['limit'] ) ? max( 1, min( 100, absint( $s['limit'] ) ) ) : 10,
                        'min_rating'      => isset( $s['min_rating'] ) ? absint( $s['min_rating'] ) : 0,
                        'date_range'      => isset( $s['date_range'] ) ? sanitize_key( $s['date_range'] ) : '',
                        'keyword'         => isset( $s['keyword'] ) ? sanitize_text_field( $s['keyword'] ) : '',
                        'columns'         => ! empty( $s['columns'] ) ? absint( $s['columns'] ) : 3,
                        'columns_tablet'  => ! empty( $s['columns_tablet'] ) ? absint( $s['columns_tablet'] ) : 2,
                        'columns_mobile'  => ! empty( $s['columns_mobile'] ) ? absint( $s['columns_mobile'] ) : 1,
                        'masonry'         => ( isset( $s['masonry'] ) && 'yes' === $s['masonry'] ) ? 'true' : 'false',
                        'autoplay'        => ( isset( $s['autoplay'] ) && 'yes' === $s['autoplay'] ) ? 'true' : 'false',
                        'speed'           => ! empty( $s['speed'] ) ? max( 1, min( 30, absint( $s['speed'] ) ) ) : 5,
                        'max_text_length' => ! empty( $s['max_text_length'] ) ? max( 50, absint( $s['max_text_length'] ) ) : 200,
                        'arrows'          => ( ! isset( $s['show_arrows'] ) || 'yes' === $s['show_arrows'] ) ? 'true' : 'false',
                        'dots'            => ( ! isset( $s['show_dots'] ) || 'yes' === $s['show_dots'] ) ? 'true' : 'false',
                        'arrow_style'     => isset( $s['arrow_style'] ) ? sanitize_key( $s['arrow_style'] ) : 'chevron',
                        'arrow_position'  => isset( $s['arrow_position'] ) ? sanitize_key( $s['arrow_position'] ) : 'inside',
                ), $this->style_atts( $s ), $this->quote_atts( $s ) );

                $this->output(
                        $renderer->render_reviews( $atts ),
                        __( 'No approved reviews match these settings yet. Add or approve reviews, or loosen the filters.', 'bizzi-reviews' )
                );
        }
}
