<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

/**
 * Registers the Bizzi Reviews widgets with Elementor.
 * Every hook here is an Elementor hook, so nothing runs unless Elementor is active.
 */
class Bizzi_Reviews_Elementor {

        public function init() {
                add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );
                add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
                // Make sure the widget scripts and styles exist inside the Elementor editor preview as well.
                add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_assets' ) );
                add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_assets' ) );
                add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'editor_styles' ) );
        }

        public function register_assets() {
                $plugin = Bizzi_Reviews::instance();
                if ( $plugin && ! wp_script_is( 'bizzi-reviews-elementor', 'registered' ) ) {
                        $plugin->register_frontend_assets();
                }
        }

        public function register_category( $elements_manager ) {
                $elements_manager->add_category( 'bizzi-reviews', array(
                        'title' => __( 'Bizzi Reviews', 'bizzi-reviews' ),
                        'icon'  => 'eicon-rating',
                ) );
        }

        public function register_widgets( $widgets_manager ) {
                if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
                        return;
                }
                $dir = BIZZI_REVIEWS_PATH . 'includes/integrations/elementor/';
                require_once $dir . 'class-widget-base.php';
                require_once $dir . 'class-widget-reviews.php';
                require_once $dir . 'class-widget-single.php';
                require_once $dir . 'class-widget-combined.php';

                $widgets_manager->register( new Bizzi_Reviews_Elementor_Reviews_Widget() );
                $widgets_manager->register( new Bizzi_Reviews_Elementor_Single_Widget() );
                $widgets_manager->register( new Bizzi_Reviews_Elementor_Combined_Widget() );

                // The floating rating badge comes with Bizzi Reviews Pro.
                if ( in_array( 'badge', Bizzi_Reviews_Widgets::layouts(), true ) ) {
                        require_once $dir . 'class-widget-badge.php';
                        $widgets_manager->register( new Bizzi_Reviews_Elementor_Badge_Widget() );
                }
        }

        /** Brand colour for the widget icons in the Elementor panel. */
        public function editor_styles() {
                wp_add_inline_style( 'elementor-editor', '.elementor-element .icon .bizzi-el-icon{color:#ffb000;}' );
        }
}
