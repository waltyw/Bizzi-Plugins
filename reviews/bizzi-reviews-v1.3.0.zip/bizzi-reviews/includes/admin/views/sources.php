<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="bizzi-admin-wrap">
<div class="bizzi-admin-header"><h1><?php esc_html_e( 'Sources & API Configuration', 'bizzi-reviews' ); ?></h1></div>
<div class="bizzi-sources-grid">
<div class="bizzi-card bizzi-source-card">
<h3><span style="color:#4285F4;">●</span> Google Business</h3>
<form class="bizzi-source-form" data-source="google">
<div class="bizzi-form-group"><label>Place ID</label><input type="text" name="place_id" value="<?php echo esc_attr( get_option( 'bizzi_reviews_google_place_id', '' ) ); ?>" class="bizzi-input" /></div>
<div class="bizzi-form-group"><label>API Key</label><input type="password" name="api_key" placeholder="••••••••" class="bizzi-input" /></div>
<div class="bizzi-btn-group"><button type="submit" class="bizzi-btn bizzi-btn-primary">Save</button><button type="button" class="bizzi-btn bizzi-test-conn" data-source="google">Test Connection</button><button type="button" class="bizzi-btn bizzi-sync-btn" data-source="google">Sync Now</button></div>
<div class="bizzi-conn-status"></div>
</form></div>
<?php
/** Add-ons (e.g. Bizzi Reviews Pro) print extra source cards here. */
do_action( 'bizzi_reviews_source_cards' );
?>
<div class="bizzi-card bizzi-source-card">
<h3><span style="color:#6C63FF;">●</span> Manual Reviews</h3>
<p><?php esc_html_e( 'Add reviews manually from the Add Review page.', 'bizzi-reviews' ); ?></p>
<a href="<?php echo esc_url( admin_url( 'admin.php?page=bizzi-reviews-add' ) ); ?>" class="bizzi-btn bizzi-btn-primary"><?php esc_html_e( 'Add Review', 'bizzi-reviews' ); ?></a>
</div>
</div></div>
