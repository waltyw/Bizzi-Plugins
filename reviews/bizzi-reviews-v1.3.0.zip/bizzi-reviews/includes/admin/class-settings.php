<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

class Bizzi_Reviews_Settings {

        public function init() {
                add_action( 'wp_ajax_bizzi_save_settings', array( $this, 'ajax_save' ) );
        }

        public static function get_defaults() {
                return array(
                        'auto_approve'            => 'all',
                        'auto_approve_min_rating' => 4,
                        'reviews_per_page'        => 20,
                        'date_format'             => 'relative',
                        'schema_output'           => 'yes',
                        'business_name'           => '',
                        'business_type'           => 'LocalBusiness',
                        'default_primary_color'          => '#6C63FF',
                        'default_star_color'             => '#FFB800',
                        'default_text_color'             => '#333333',
                        'default_background_color'       => '#ffffff',
                        'default_badge_background_color' => '#1A1A2E',
                        'default_badge_text_color'       => '#ffffff',
                        'default_card_border_radius'     => 12,
                        'default_card_shadow'            => 'true',
                        'default_font_family'            => 'inherit',
                        'default_layout'          => 'carousel',
                        'default_columns'         => 3,
                );
        }

        public function ajax_save() {
                check_ajax_referer( 'bizzi_reviews_nonce', 'nonce' );
                if ( ! current_user_can( 'manage_options' ) ) {
                        wp_send_json_error( array( 'message' => 'Unauthorized' ) );
                }

                $settings = get_option( 'bizzi_reviews_settings', self::get_defaults() );

                $fields = array(
                        'auto_approve', 'auto_approve_min_rating', 'reviews_per_page',
                        'date_format', 'schema_output', 'business_name', 'business_type',
                        'default_layout', 'default_columns',
                );
                $color_fields = array(
                        'default_primary_color', 'default_star_color', 'default_text_color', 'default_background_color',
                        'default_badge_background_color', 'default_badge_text_color',
                );
                $defaults = self::get_defaults();

                $choices = array(
                        'auto_approve'   => array( 'all', 'min_rating', 'manual' ),
                        'date_format'    => array( 'relative', 'absolute' ),
                        'schema_output'  => array( 'yes', 'no' ),
                        'business_type'  => Bizzi_Reviews_Schema::allowed_business_types(),
                        'default_layout' => Bizzi_Reviews_Widgets::layouts(),
                );
                $numbers = array(
                        'auto_approve_min_rating' => array( 1, 5 ),
                        'reviews_per_page'        => array( 1, 100 ),
                        'default_columns'         => array( 1, 6 ),
                );
                foreach ( $fields as $field ) {
                        if ( ! isset( $_POST[ $field ] ) ) {
                                continue;
                        }
                        $value = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
                        if ( isset( $choices[ $field ] ) ) {
                                if ( in_array( $value, $choices[ $field ], true ) ) {
                                        $settings[ $field ] = $value;
                                }
                        } elseif ( isset( $numbers[ $field ] ) ) {
                                $settings[ $field ] = max( $numbers[ $field ][0], min( $numbers[ $field ][1], absint( $value ) ) );
                        } else {
                                $settings[ $field ] = substr( $value, 0, 200 );
                        }
                }
                foreach ( $color_fields as $field ) {
                        if ( isset( $_POST[ $field ] ) ) {
                                $settings[ $field ] = Bizzi_Reviews_Widgets::sanitize_color( sanitize_text_field( wp_unslash( $_POST[ $field ] ) ), $defaults[ $field ] );
                        }
                }
                if ( isset( $_POST['default_card_border_radius'] ) ) {
                        $settings['default_card_border_radius'] = min( 40, absint( $_POST['default_card_border_radius'] ) );
                }
                if ( isset( $_POST['default_font_family'] ) ) {
                        $settings['default_font_family'] = Bizzi_Reviews_Widgets::sanitize_font( sanitize_text_field( wp_unslash( $_POST['default_font_family'] ) ) );
                }
                // Unchecked checkboxes are not posted, so the shadow toggle is read explicitly.
                $settings['default_card_shadow'] = isset( $_POST['default_card_shadow'] ) ? 'true' : 'false';

                update_option( 'bizzi_reviews_settings', $settings );
                wp_send_json_success();
        }
}
