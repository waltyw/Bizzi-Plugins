<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Bizzi_Reviews_Sync {

	private $db;
	private $moderation;
	private $cache;
	private $sources = array();

	public function __construct() {
		$this->db         = new Bizzi_Reviews_Database();
		$this->moderation = new Bizzi_Reviews_Moderation();
		$this->cache      = new Bizzi_Reviews_Cache();
	}

	public function init() {
		add_action( 'bizzi_reviews_daily_sync', array( $this, 'sync_all' ) );
		add_action( 'wp_ajax_bizzi_sync_source', array( $this, 'ajax_sync_source' ) );
		add_action( 'wp_ajax_bizzi_sync_all', array( $this, 'ajax_sync_all' ) );
	}

	public function register_source( $source ) {
		if ( $source instanceof Bizzi_Review_Source_Base ) {
			$this->sources[ $source->get_slug() ] = $source;
		}
	}

	public function sync_all() {
		$log = array();
		foreach ( $this->sources as $slug => $source ) {
			$log[ $slug ] = $this->sync_source( $slug );
		}
		update_option( 'bizzi_reviews_sync_log', $log );
		$this->cache->flush();
		return $log;
	}

	public function sync_source( $slug ) {
		if ( ! isset( $this->sources[ $slug ] ) ) {
			return array( 'status' => 'error', 'message' => 'Unknown source' );
		}

		$source = $this->sources[ $slug ];

		if ( ! $source->is_configured() ) {
			return array( 'status' => 'error', 'message' => 'Source not configured' );
		}

		try {
			$reviews = $source->fetch_reviews();
			$imported = 0;
			$skipped  = 0;

			foreach ( $reviews as $review_data ) {
				$source_id = isset( $review_data['source_id'] ) ? $review_data['source_id'] : '';

				if ( ! empty( $source_id ) && $this->db->review_exists( $slug, $source_id ) ) {
					$skipped++;
					continue;
				}

				$rating = isset( $review_data['rating'] ) ? absint( $review_data['rating'] ) : 5;
				$status = $this->moderation->determine_status( $rating );

				$this->db->insert_review( array(
					'source'         => sanitize_text_field( $slug ),
					'source_id'      => sanitize_text_field( $source_id ),
					'author_name'    => sanitize_text_field( isset( $review_data['author_name'] ) ? $review_data['author_name'] : '' ),
					'author_image'   => esc_url_raw( isset( $review_data['author_image'] ) ? $review_data['author_image'] : '' ),
					'rating'         => $rating,
					'content'        => wp_kses_post( isset( $review_data['content'] ) ? $review_data['content'] : '' ),
					'date_published' => sanitize_text_field( isset( $review_data['date_published'] ) ? $review_data['date_published'] : current_time( 'mysql' ) ),
					'date_synced'    => current_time( 'mysql' ),
					'status'         => $status,
					'metadata'       => wp_json_encode( isset( $review_data['metadata'] ) ? $review_data['metadata'] : array() ),
				) );

				$imported++;
			}

			$this->cache->flush();

			return array(
				'status'   => 'success',
				'imported' => $imported,
				'skipped'  => $skipped,
				'time'     => current_time( 'mysql' ),
			);

		} catch ( Exception $e ) {
			return array(
				'status'  => 'error',
				'message' => $e->getMessage(),
			);
		}
	}

	public function ajax_sync_source() {
		check_ajax_referer( 'bizzi_reviews_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized' ) );
		}

		$source = isset( $_POST['source'] ) ? sanitize_text_field( wp_unslash( $_POST['source'] ) ) : '';

		if ( empty( $source ) ) {
			wp_send_json_error( array( 'message' => 'No source specified' ) );
		}

		$result = $this->sync_source( $source );
		wp_send_json_success( $result );
	}

	public function ajax_sync_all() {
		check_ajax_referer( 'bizzi_reviews_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized' ) );
		}

		$result = $this->sync_all();
		wp_send_json_success( $result );
	}

	public function get_sources() {
		return $this->sources;
	}

	public function get_sync_log() {
		return get_option( 'bizzi_reviews_sync_log', array() );
	}
}
