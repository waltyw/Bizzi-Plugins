<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Bizzi_Reviews_Cache {

	private $prefix = 'bizzi_reviews_';
	private $expiration = 3600;

	public function get( $key ) {
		$cached = get_transient( $this->prefix . $key );
		return $cached !== false ? $cached : null;
	}

	public function set( $key, $data, $expiration = null ) {
		$exp = $expiration !== null ? $expiration : $this->expiration;
		set_transient( $this->prefix . $key, $data, $exp );
	}

	public function delete( $key ) {
		delete_transient( $this->prefix . $key );
	}

	public function flush() {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				'_transient_' . $this->prefix . '%',
				'_transient_timeout_' . $this->prefix . '%'
			)
		);
	}

	public function get_or_set( $key, $callback, $expiration = null ) {
		$cached = $this->get( $key );
		if ( $cached !== null ) {
			return $cached;
		}
		$data = call_user_func( $callback );
		$this->set( $key, $data, $expiration );
		return $data;
	}
}
