<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Bizzi_Core {

	protected $plugin_slug = '';
	protected $version     = '';
	protected $plugin_path = '';
	protected $plugin_url  = '';

	public function __construct( $slug = '', $version = '', $path = '', $url = '' ) {
		$this->plugin_slug = $slug;
		$this->version     = $version;
		$this->plugin_path = $path;
		$this->plugin_url  = $url;
	}

	public function register_admin_menu( $page_title, $menu_title, $capability, $menu_slug, $callback, $icon = '', $position = null ) {
		add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $callback, $icon, $position );
	}

	public function register_admin_submenu( $parent_slug, $page_title, $menu_title, $capability, $menu_slug, $callback ) {
		add_submenu_page( $parent_slug, $page_title, $menu_title, $capability, $menu_slug, $callback );
	}

	public function enqueue_style( $handle, $src, $deps = array(), $ver = null, $media = 'all' ) {
		$version = $ver ? $ver : $this->version;
		wp_enqueue_style( $this->plugin_slug . '-' . $handle, $this->plugin_url . $src, $deps, $version, $media );
	}

	public function enqueue_script( $handle, $src, $deps = array(), $ver = null, $in_footer = true ) {
		$version = $ver ? $ver : $this->version;
		wp_enqueue_script( $this->plugin_slug . '-' . $handle, $this->plugin_url . $src, $deps, $version, $in_footer );
	}

	public function register_ajax( $action, $callback, $nopriv = false ) {
		add_action( 'wp_ajax_' . $action, $callback );
		if ( $nopriv ) {
			add_action( 'wp_ajax_nopriv_' . $action, $callback );
		}
	}

	public function add_admin_notice( $message, $type = 'info', $dismissible = true ) {
		add_action( 'admin_notices', function () use ( $message, $type, $dismissible ) {
			$classes = 'notice notice-' . esc_attr( $type );
			if ( $dismissible ) {
				$classes .= ' is-dismissible';
			}
			printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $classes ), wp_kses_post( $message ) );
		} );
	}

	public function get_setting( $key, $default = '' ) {
		$settings = get_option( $this->plugin_slug . '_settings', array() );
		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
	}

	public function update_setting( $key, $value ) {
		$settings = get_option( $this->plugin_slug . '_settings', array() );
		$settings[ $key ] = $value;
		update_option( $this->plugin_slug . '_settings', $settings );
	}

	private function crypto_key() {
		return hash( 'sha256', wp_salt( 'auth' ), true );
	}

	/**
	 * Encrypts secrets (API keys, tokens) before they are stored in the options table.
	 * Format: "v2:" + base64( 16-byte random IV + AES-256-CBC ciphertext ).
	 */
	public function encrypt_value( $value ) {
		if ( empty( $value ) ) {
			return '';
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return base64_encode( $value ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Fallback when OpenSSL is unavailable.
		}
		$iv     = random_bytes( 16 );
		$cipher = openssl_encrypt( $value, 'AES-256-CBC', $this->crypto_key(), OPENSSL_RAW_DATA, $iv );
		return 'v2:' . base64_encode( $iv . $cipher ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	public function decrypt_value( $value ) {
		if ( empty( $value ) ) {
			return '';
		}
		if ( ! function_exists( 'openssl_decrypt' ) ) {
			return base64_decode( $value ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		}
		if ( 0 === strpos( $value, 'v2:' ) ) {
			$raw = base64_decode( substr( $value, 3 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			if ( false === $raw || strlen( $raw ) <= 16 ) {
				return '';
			}
			$plain = openssl_decrypt( substr( $raw, 16 ), 'AES-256-CBC', $this->crypto_key(), OPENSSL_RAW_DATA, substr( $raw, 0, 16 ) );
			return false !== $plain ? $plain : '';
		}
		// Legacy (v1.0.x) format: static IV. Re-saved in the new format on next update.
		$key       = wp_salt( 'auth' );
		$iv        = substr( md5( $key ), 0, 16 );
		$decrypted = openssl_decrypt( base64_decode( $value ), 'AES-256-CBC', $key, 0, $iv ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		return false !== $decrypted ? $decrypted : '';
	}
}
