<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

class Bizzi_Reviews_Schema {

        private $db;
        private $output = false;

        public function __construct() {
                $this->db = new Bizzi_Reviews_Database();
        }

        public function init() {
                $settings = get_option( 'bizzi_reviews_settings', array() );
                if ( ! empty( $settings['schema_output'] ) && $settings['schema_output'] === 'yes' ) {
                        add_action( 'wp_head', array( $this, 'output_schema' ) );
                }
        }

        public static function allowed_business_types() {
                return array( 'LocalBusiness', 'Organization', 'Store', 'Restaurant', 'ProfessionalService', 'HomeAndConstructionBusiness', 'HealthAndBeautyBusiness', 'AutomotiveBusiness', 'LodgingBusiness', 'MedicalBusiness', 'LegalService', 'FinancialService', 'SportsActivityLocation', 'EducationalOrganization' );
        }

        public function mark_for_output() {
                $this->output = true;
        }

        public function output_schema() {
                if ( ! $this->output ) {
                        return;
                }

                $reviews  = $this->db->get_reviews( array( 'status' => 'approved', 'limit' => 100 ) );
                $settings = get_option( 'bizzi_reviews_settings', array() );

                if ( empty( $reviews ) ) {
                        return;
                }

                $total    = count( $reviews );
                $sum      = 0;
                $review_schemas = array();

                foreach ( $reviews as $review ) {
                        $sum += absint( $review->rating );
                        $review_schemas[] = array(
                                '@type'         => 'Review',
                                'author'        => array(
                                        '@type' => 'Person',
                                        'name'  => wp_strip_all_tags( $review->author_name ),
                                ),
                                'datePublished' => gmdate( 'Y-m-d', strtotime( $review->date_published ) ? strtotime( $review->date_published ) : time() ),
                                'reviewBody'    => wp_strip_all_tags( $review->content ),
                                'reviewRating'  => array(
                                        '@type'      => 'Rating',
                                        'ratingValue' => absint( $review->rating ),
                                        'bestRating'  => 5,
                                ),
                        );
                }

                $avg_rating = $total > 0 ? round( $sum / $total, 1 ) : 0;

                $schema = array(
                        '@context'        => 'https://schema.org',
                        '@type'           => 'LocalBusiness',
                        'name'            => ! empty( $settings['business_name'] ) ? wp_strip_all_tags( $settings['business_name'] ) : get_bloginfo( 'name' ),
                        'aggregateRating' => array(
                                '@type'       => 'AggregateRating',
                                'ratingValue' => $avg_rating,
                                'reviewCount' => $total,
                                'bestRating'  => 5,
                        ),
                        'review'          => $review_schemas,
                );

                if ( ! empty( $settings['business_type'] ) && in_array( $settings['business_type'], self::allowed_business_types(), true ) ) {
                        $schema['@type'] = $settings['business_type'];
                }

                if ( class_exists( 'WooCommerce' ) ) {
                        $product_schema = array(
                                '@context'        => 'https://schema.org',
                                '@type'           => 'Product',
                                'name'            => ! empty( $settings['business_name'] ) ? wp_strip_all_tags( $settings['business_name'] ) : get_bloginfo( 'name' ),
                                'aggregateRating' => array(
                                        '@type'       => 'AggregateRating',
                                        'ratingValue' => $avg_rating,
                                        'reviewCount' => $total,
                                        'bestRating'  => 5,
                                ),
                        );
                        echo '<script type="application/ld+json">' . wp_json_encode( $product_schema, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded with JSON_HEX_TAG.
                }

                echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded with JSON_HEX_TAG.
        }
}
