<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;

/** Your overall star rating and review count across every source. */
class Bizzi_Reviews_Elementor_Combined_Widget extends Bizzi_Reviews_Elementor_Widget_Base {

        const ROOT = '{{WRAPPER}} .bizzi-combined-rating';

        public function get_name() {
                return 'bizzi-combined-rating';
        }

        public function get_title() {
                return __( 'Bizzi Combined Rating', 'bizzi-reviews' );
        }

        public function get_icon() {
                return 'eicon-rating bizzi-el-icon';
        }

        public function get_keywords() {
                return array( 'rating', 'stars', 'score', 'average', 'reviews', 'bizzi' );
        }

        /** Every part of the widget that can be switched on or off: setting => label. */
        private function parts() {
                return array(
                        'show_score'        => __( 'Average score', 'bizzi-reviews' ),
                        'show_stars'        => __( 'Stars', 'bizzi-reviews' ),
                        'show_count'        => __( '"Based on X reviews"', 'bizzi-reviews' ),
                        'show_sources'      => __( 'Per-source breakdown', 'bizzi-reviews' ),
                        'show_source_name'  => __( 'Source name', 'bizzi-reviews' ),
                        'show_source_score' => __( 'Source score', 'bizzi-reviews' ),
                        'show_source_star'  => __( 'Source star icon', 'bizzi-reviews' ),
                        'show_source_count' => __( 'Source review count', 'bizzi-reviews' ),
                );
        }

        protected function register_controls() {
                $this->start_controls_section( 'section_info', array(
                        'label' => __( 'Combined rating', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_CONTENT,
                ) );
                $this->add_control( 'info', array(
                        'type'            => Controls_Manager::RAW_HTML,
                        'raw'             => esc_html__( 'Shows your average star rating and total number of approved reviews from all sources. It updates automatically. Switch each part on or off below.', 'bizzi-reviews' ),
                        'content_classes' => 'elementor-descriptor',
                ) );
                foreach ( $this->parts() as $key => $label ) {
                        $is_source_part = 0 === strpos( $key, 'show_source_' );
                        $this->add_control( $key, array(
                                'label'        => $label,
                                'type'         => Controls_Manager::SWITCHER,
                                'return_value' => 'yes',
                                'default'      => 'yes',
                                'separator'    => 'show_source_name' === $key ? 'before' : 'none',
                                'condition'    => $is_source_part ? array( 'show_sources' => 'yes' ) : array(),
                        ) );
                }
                $this->end_controls_section();

                $this->register_style_controls( array( 'text_selector' => '' ) );

                $this->register_box_section();

                $this->register_region( 'score', __( 'Average score', 'bizzi-reviews' ), '.bizzi-combined-score', array(
                        'condition' => array( 'show_score' => 'yes' ),
                        'size'      => array( 'score_size', 48, 160 ),
                        'weight'    => 'score_weight',
                ) );
                $this->register_region( 'stars', __( 'Stars', 'bizzi-reviews' ), '.bizzi-combined-stars', array(
                        'condition'      => array( 'show_stars' => 'yes' ),
                        'size'           => array( 'stars_size', 24, 100 ),
                        'letter_spacing' => true,
                        'margin_id'      => 'stars_spacing',
                ) );
                $this->register_region( 'count', __( '"Based on" text', 'bizzi-reviews' ), '.bizzi-combined-count', array(
                        'condition' => array( 'show_count' => 'yes' ),
                        'size'      => array( 'count_size', 14, 60 ),
                        'opacity'   => 0.7,
                ) );
                $this->register_sources_section();
                $this->register_region( 'source_name', __( 'Source name', 'bizzi-reviews' ), '.bizzi-combined-source-name', array(
                        'condition' => array( 'show_sources' => 'yes', 'show_source_name' => 'yes' ),
                        'size'      => array( 'source_name_size', 16, 60 ),
                        'transform' => true,
                ) );
                $this->register_region( 'source_score', __( 'Source score', 'bizzi-reviews' ), '.bizzi-combined-source-score', array(
                        'condition'  => array( 'show_sources' => 'yes' ),
                        'size'       => array( 'source_score_size', 20, 80 ),
                        'star_color' => true,
                ) );
                $this->register_region( 'source_count', __( 'Source review count', 'bizzi-reviews' ), '.bizzi-combined-source-count', array(
                        'condition' => array( 'show_sources' => 'yes', 'show_source_count' => 'yes' ),
                        'size'      => array( 'source_count_size', 12, 60 ),
                        'opacity'   => 0.6,
                ) );
        }

        /** Whole widget box: alignment and padding. */
        private function register_box_section() {
                $this->start_controls_section( 'section_style_combined_text', array(
                        'label' => __( 'Layout', 'bizzi-reviews' ),
                        'tab'   => Controls_Manager::TAB_STYLE,
                ) );
                $this->add_responsive_control( 'combined_align', array(
                        'label'     => __( 'Alignment', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::CHOOSE,
                        'options'   => array(
                                'left'   => array( 'title' => __( 'Left', 'bizzi-reviews' ), 'icon' => 'eicon-text-align-left' ),
                                'center' => array( 'title' => __( 'Centre', 'bizzi-reviews' ), 'icon' => 'eicon-text-align-center' ),
                                'right'  => array( 'title' => __( 'Right', 'bizzi-reviews' ), 'icon' => 'eicon-text-align-right' ),
                        ),
                        'selectors_dictionary' => array(
                                'left'   => 'text-align:left;--bizzi-c-justify:flex-start;',
                                'center' => 'text-align:center;--bizzi-c-justify:center;',
                                'right'  => 'text-align:right;--bizzi-c-justify:flex-end;',
                        ),
                        'selectors' => array( self::ROOT => '{{VALUE}}' ),
                ) );
                $this->add_responsive_control( 'combined_padding', array(
                        'label'      => __( 'Padding', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => array( 'px', 'em', '%' ),
                        'selectors'  => array( self::ROOT => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
                ) );
                $this->add_group_control( Group_Control_Background::get_type(), array(
                        'name'     => 'combined_background',
                        'label'    => __( 'Background', 'bizzi-reviews' ),
                        'types'    => array( 'classic', 'gradient' ),
                        'selector' => self::ROOT,
                ) );
                $this->add_control( 'combined_text_color', array(
                        'label'     => __( 'Default text colour', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( self::ROOT => 'color: {{VALUE}};' ),
                ) );
                $this->add_group_control( Group_Control_Typography::get_type(), array(
                        'name'     => 'combined_typography',
                        'label'    => __( 'Default font style', 'bizzi-reviews' ),
                        'selector' => self::ROOT,
                        'exclude'  => array( 'font_size' ),
                ) );
                $this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'combined_border', 'selector' => self::ROOT ) );
                $this->add_group_control( Group_Control_Box_Shadow::get_type(), array( 'name' => 'combined_shadow', 'selector' => self::ROOT ) );
                $this->end_controls_section();
        }

        /** Breakdown row plus each source box. */
        private function register_sources_section() {
                $this->start_controls_section( 'section_style_sources', array(
                        'label'     => __( 'Source boxes', 'bizzi-reviews' ),
                        'tab'       => Controls_Manager::TAB_STYLE,
                        'condition' => array( 'show_sources' => 'yes' ),
                ) );
                $row = self::ROOT . ' .bizzi-combined-sources';
                $box = self::ROOT . ' .bizzi-combined-source';
                $this->add_responsive_control( 'sources_gap', array(
                        'label'      => __( 'Gap between sources', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
                        'selectors'  => array( $row => 'gap: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( 'sources_space', array(
                        'label'      => __( 'Space above', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
                        'selectors'  => array( $row => 'margin-top: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_control( 'sources_row_bg', array(
                        'label'     => __( 'Row background', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $row => 'background-color: {{VALUE}};' ),
                ) );
                $this->add_responsive_control( 'sources_row_padding', array(
                        'label'      => __( 'Row padding', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => array( 'px', 'em' ),
                        'selectors'  => array( $row => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
                ) );
                $this->add_control( 'source_box_heading', array(
                        'label'     => __( 'Each source box', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::HEADING,
                        'separator' => 'before',
                ) );
                $this->add_control( 'source_box_bg', array(
                        'label'     => __( 'Background', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $box => 'background-color: {{VALUE}};' ),
                ) );
                $this->add_responsive_control( 'source_box_padding', array(
                        'label'      => __( 'Padding', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => array( 'px', 'em' ),
                        'selectors'  => array( $box => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( 'source_box_min_width', array(
                        'label'      => __( 'Minimum width', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px', '%' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 400 ) ),
                        'selectors'  => array( $box => 'min-width: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( 'source_box_radius', array(
                        'label'      => __( 'Corner radius', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 50 ) ),
                        'selectors'  => array( $box => 'border-radius: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_control( 'source_box_color', array(
                        'label'     => __( 'Text colour (all source text)', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $box => 'color: {{VALUE}};' ),
                ) );
                $this->add_group_control( Group_Control_Typography::get_type(), array(
                        'name'     => 'source_box_typography',
                        'label'    => __( 'Font style (all source text)', 'bizzi-reviews' ),
                        'selector' => $box,
                        'exclude'  => array( 'font_size' ),
                ) );
                $this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'source_box_border', 'selector' => $box ) );
                $this->add_group_control( Group_Control_Box_Shadow::get_type(), array( 'name' => 'source_box_shadow', 'selector' => $box ) );
                $this->end_controls_section();
        }

        /**
         * One Style section per region: text/number colour, size, weight, background, padding, corners, spacing.
         * Existing control IDs (score_size, stars_size…) are kept so saved pages keep their settings.
         */
        private function register_region( $id, $label, $class, $opts ) {
                $sel = self::ROOT . ' ' . $class;
                $this->start_controls_section( 'section_style_' . $id, array(
                        'label'     => $label,
                        'tab'       => Controls_Manager::TAB_STYLE,
                        'condition' => $opts['condition'],
                ) );
                $this->add_control( $id . '_color', array(
                        'label'     => 'stars' === $id ? __( 'Star colour', 'bizzi-reviews' ) : __( 'Text / number colour', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => array( $sel => 'color: {{VALUE}};' ),
                ) );
                if ( ! empty( $opts['star_color'] ) ) {
                        $this->add_control( $id . '_star_color', array(
                                'label'     => __( 'Star icon colour', 'bizzi-reviews' ),
                                'type'      => Controls_Manager::COLOR,
                                'condition' => array( 'show_source_star' => 'yes' ),
                                'selectors' => array( $sel . ' .bizzi-combined-source-star' => 'color: {{VALUE}};' ),
                        ) );
                }
                list( $size_id, $placeholder, $max ) = $opts['size'];
                $this->add_responsive_control( $size_id, array(
                        'label'       => __( 'Size', 'bizzi-reviews' ),
                        'type'        => Controls_Manager::SLIDER,
                        'size_units'  => array( 'px', 'em', 'rem' ),
                        'range'       => array( 'px' => array( 'min' => 8, 'max' => $max ), 'em' => array( 'min' => 0.5, 'max' => 10, 'step' => 0.1 ), 'rem' => array( 'min' => 0.5, 'max' => 10, 'step' => 0.1 ) ),
                        'placeholder' => $placeholder,
                        'selectors'   => array( $sel => 'font-size: {{SIZE}}{{UNIT}};' ),
                ) );
                if ( 'stars' !== $id ) {
                        // Font family, style (italic), weight, letter case, decoration, line height, letter/word spacing.
                        $this->add_group_control( Group_Control_Typography::get_type(), array(
                                'name'     => $id . '_typography',
                                'label'    => __( 'Font style', 'bizzi-reviews' ),
                                'selector' => $sel,
                                'exclude'  => array( 'font_size' ),
                        ) );
                }
                if ( ! empty( $opts['letter_spacing'] ) ) {
                        $this->add_responsive_control( $id . '_letter_spacing', array(
                                'label'      => __( 'Space between stars', 'bizzi-reviews' ),
                                'type'       => Controls_Manager::SLIDER,
                                'size_units' => array( 'px' ),
                                'range'      => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
                                'selectors'  => array( $sel => 'letter-spacing: {{SIZE}}{{UNIT}};' ),
                        ) );
                }
                if ( isset( $opts['opacity'] ) ) {
                        $this->add_control( $id . '_opacity', array(
                                'label'       => __( 'Opacity', 'bizzi-reviews' ),
                                'type'        => Controls_Manager::SLIDER,
                                'range'       => array( 'px' => array( 'min' => 0.1, 'max' => 1, 'step' => 0.05 ) ),
                                'placeholder' => $opts['opacity'],
                                'selectors'   => array( $sel => 'opacity: {{SIZE}};' ),
                        ) );
                }
                $this->add_control( $id . '_bg', array(
                        'label'     => __( 'Background', 'bizzi-reviews' ),
                        'type'      => Controls_Manager::COLOR,
                        'separator' => 'before',
                        'selectors' => array( $sel => 'background-color: {{VALUE}};' ),
                ) );
                $this->add_responsive_control( $id . '_padding', array(
                        'label'      => __( 'Padding', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::DIMENSIONS,
                        'size_units' => array( 'px', 'em' ),
                        'selectors'  => array( $sel => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( $id . '_radius', array(
                        'label'      => __( 'Corner radius', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 50 ) ),
                        'selectors'  => array( $sel => 'border-radius: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->add_responsive_control( isset( $opts['margin_id'] ) ? $opts['margin_id'] : $id . '_spacing', array(
                        'label'      => __( 'Space above & below', 'bizzi-reviews' ),
                        'type'       => Controls_Manager::SLIDER,
                        'size_units' => array( 'px' ),
                        'range'      => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
                        'selectors'  => array( $sel => 'margin-top: {{SIZE}}{{UNIT}}; margin-bottom: {{SIZE}}{{UNIT}};' ),
                ) );
                $this->end_controls_section();
        }

        protected function render() {
                $renderer = $this->renderer();
                if ( ! $renderer ) {
                        return;
                }
                $settings = $this->get_settings_for_display();
                $atts     = $this->style_atts( $settings );
                unset( $atts['card_padding'], $atts['card_shadow'] );
                foreach ( array_keys( $this->parts() ) as $key ) {
                        $atts[ $key ] = ( isset( $settings[ $key ] ) && 'yes' !== $settings[ $key ] ) ? 'false' : 'true';
                }
                $this->output(
                        $renderer->render_combined( $atts ),
                        __( 'Your combined rating appears here once you have approved reviews.', 'bizzi-reviews' )
                );
        }
}
